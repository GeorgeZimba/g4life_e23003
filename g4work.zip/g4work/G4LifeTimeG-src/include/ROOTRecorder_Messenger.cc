#include  "ROOTRecorder_Messenger.hh"
#include <sstream>

#include "G4UIdirectory.hh"
#include "G4UIcommand.hh"
#include "G4UIparameter.hh"
#include "G4UIcmdWithAString.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ROOTRecorder_Messenger::ROOTRecorder_Messenger(ROOTRecorder* R):Recorder(R)
{
 
  RecorderDir = new G4UIdirectory("/Recorder/");
  RecorderDir->SetGuidance("histograms control");

  FileCmd = new G4UIcmdWithAString("/Recorder/OutputFile",this);
  FileCmd->SetGuidance("Set name for output ROOT  file");
  FileCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  STSGCmd = new G4UIcmdWithoutParameter("/Recorder/SaveSeGAToTree",this);
  STSGCmd->SetGuidance("Save SeGA events to Root teee");
  STSGCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  STGGCmd = new G4UIcmdWithoutParameter("/Recorder/SaveGretinaToTree",this);
  STGGCmd->SetGuidance("Save SeGA events to Root teee");
  STGGCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  STICmd = new G4UIcmdWithoutParameter("/Recorder/SaveIonsToTree",this);
  STICmd->SetGuidance("Save Ions events to Root teee");
  STICmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  SHSGCmd = new G4UIcmdWithoutParameter("/Recorder/CreateSeGAHistos",this);
  SHSGCmd->SetGuidance("Create Gamma rays Histogram sets for Core and Rings ");
  SHSGCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  SHGGCmd = new G4UIcmdWithoutParameter("/Recorder/CreateGretinaHistos",this);
  SHGGCmd->SetGuidance("Create Gamma rays Histogram sets for Core and Rings ");
  SHGGCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 
  
  SHGSCmd = new G4UIcmdWithoutParameter("/Recorder/CreateGammaSegHistos",this);
  SHGSCmd->SetGuidance("Create Gamma rays Histogram sets for Segments");
  SHGSCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  SHICmd = new G4UIcmdWithoutParameter("/Recorder/CreateIonsHistos",this);
  SHICmd->SetGuidance("Create Histogram sets for Ions");
  SHICmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  //AR New in v4.3 -> To get Cascade Analysis Histograms
  CASCCmd = new G4UIcmdWithoutParameter("/Recorder/CascadeHistos",this);
  CASCCmd->SetGuidance("Create Histogram sets for Cascade Analysis");
  CASCCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 
  
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

ROOTRecorder_Messenger::~ROOTRecorder_Messenger()
{
  delete FileCmd;
  delete STSGCmd;
  delete STGGCmd;
  delete SHSGCmd;
  delete SHGGCmd;
  delete SHGSCmd;
  delete STICmd;
  delete SHICmd;
  //AR New in v4.3 -> To get Cascade Analysis Histograms
  delete CASCCmd;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ROOTRecorder_Messenger::SetNewValue(G4UIcommand* command,G4String newValues)
{
  if (command == FileCmd){
	 Recorder->SetFileName(newValues);
  }
  if (command == STICmd){
	 Recorder->SetFillTreeS800(true);
  }
  if (command == STSGCmd){
	 Recorder->SetFillTreeSeGA(true);
  } 
  if (command == STGGCmd){
	 Recorder->SetFillTreeGretina(true);
  }
  if (command == SHICmd){
	 Recorder->SetFillHistosS800(true);
  }
  if (command == SHSGCmd){
	 Recorder->SetFillHistosSeGA(true);
  }
  if (command == SHGGCmd){
	 Recorder->SetFillHistosGretina(true);
  }
  if (command == SHGSCmd){
	 Recorder->SetFillHistosSeGASeg(true);
  }
  //AR New in v4.3 -> To get Cascade Analysis Histograms
  if (command == CASCCmd){
	 Recorder->SetFillHistosCascade(true);
  }
}
