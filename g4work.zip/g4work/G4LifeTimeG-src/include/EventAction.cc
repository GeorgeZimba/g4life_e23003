#include "EventAction.hh"

 
EventAction::EventAction(Analysis* A):Ana(A)
{ 

}


EventAction::~EventAction()
{
  ;
}

void EventAction::BeginOfEventAction(const G4Event* evt)
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
	G4cout<<"+++++ Begin of event "<<evt->GetEventID()<<G4endl;
#endif
	Ana->BeginOfEvent(evt);
}



void EventAction::EndOfEventAction(const G4Event* evt)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
  G4cout<<"+++++ End of event "<<evt->GetEventID()<<G4endl;
#endif 
   
  G4HCofThisEvent * HCE = evt->GetHCofThisEvent();
  
  if(HCE) {
	 Ana->EndOfEvent(evt);
  }
}

