#include "ROOTRecorder.hh"
#include "ROOTRecorder_Messenger.hh"
#include "Analysis_Messenger.hh"

using namespace std;

ROOTRecorder::ROOTRecorder(Analysis* A)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__ << G4endl;
#endif
	outTreeName = "sample.root";
	Ana = A;
	Recorder_Messenger  = new ROOTRecorder_Messenger(this);
	FillHistosSeGA = false;
	FillHistosSeGASeg = false;
	FillHistosS800 = false;
	FillHistosGretina = false;
	//AR New in v4.3 -> To add Histos for Rob's Cascade Analysis
	FillHistosCascade = false;

	FillTreeSeGA = false;
	FillTreeS800 = false;
	FillTreeGretina = false;
}


ROOTRecorder::~ROOTRecorder()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__ << G4endl;
#endif
  delete Recorder_Messenger;
}


void ROOTRecorder::OpenOutputTree()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__ << G4endl;
#endif
  
  	outTree = new TFile(outTreeName.c_str(),"recreate");

	if(!outTree)
    {
    	G4cout << "\nCould not open " << outTreeName <<endl;
      exit(-1);
    }
	outTree->mkdir("Histos");
	
     parT = new TTree("inputs","Read-in Inputs to the simulation");		  	  	
	
	outT = new TTree("G4_Data","G4Tree");
	if(!outT)
	  {
		 G4cout << "\nCould not create Raw Data Tree in " << outTreeName << G4endl;
		 exit(-1);
	  }
}

void ROOTRecorder::CloseOutputTree()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__ << G4endl;

  G4cout << "Writing outTree " << outTreeName << G4endl;
#endif

   parT->Fill();
   outTree->Write();
  
   if(outTree->IsOpen())
     {
#ifdef DEBUG
		 G4cout << "Deleting outTree : " << G4endl;
#endif
		 delete outT;
		 delete parT;		 
#ifdef DEBUG
		 G4cout << "Closing file : " << outTreeName <<endl;
#endif
		 outTree->Close();
		 delete outTree;
	  }
	else
     {
		 G4cout << "File was not opened " << outTreeName << G4endl;
		 exit(-1);
    }
}

void ROOTRecorder::FillHistograms()
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
	
	if(FillHistosSeGA){
	  for(int i = 0 ; i < Ana->DetM; i++){
		 
	    if(Ana->RingNr[i] == 1){
	      DetEDC_R1->Fill(Ana->DetEDC[i]);
	      DetE_R1->Fill(Ana->DetE[i]);
	      if(Ana->SegMul[i] == 1) DetEDC_R1_M1->Fill(Ana->DetEDC[i]);

			  
	    }
	    if(Ana->RingNr[i] == 2){
	      DetEDC_R2->Fill(Ana->DetEDC[i]);
	      DetE_R2->Fill(Ana->DetE[i]);
	      if(Ana->SegMul[i] == 1) DetEDC_R2_M1->Fill(Ana->DetEDC[i]);
	    }
	    CoreEDC[Ana->ExtDetNr[i]]->Fill(Ana->DetEDC[i]);
		 
	    // 
	    //	 CoreEDC511[Ana->ExtDetNr[i]]->Fill(Ana->DetEDC511[i]);
		 
	    // Segments /!\ not implemented for other puposes than largest energy deposit segment ... 
	    if(FillHistosSeGASeg){
	      SegE[Ana->ExtDetNr[i]][Ana->MaxSegNr[i]]->Fill(Ana->DetE[i]);
	      SegEDC[Ana->ExtDetNr[i]][Ana->MaxSegNr[i]]->Fill(Ana->DetEDC[i]);
	      SegAng[Ana->ExtDetNr[i]][Ana->MaxSegNr[i]]->Fill(Ana->CosThetaCMTrue[i]);			  
	    }
		 
	  }
	}
	
	if(FillHistosGretina){

	  //AR New in v4.3 -> Filling Histos for Rob's Cascade Analysis
	  if(FillHistosCascade){
	    
	    for(unsigned int i=0;i<Ana->CascadeZ.size();i++){
	      CascadeZ->Fill(Ana->CascadeZ[i]);
	      CascadeZ_largeRange->Fill(Ana->CascadeZ[i]);
	    }
	    
	    //Rob Elder 2018-02-15.  Making more histos for the new gates and the new data structure (2d vector) for CorrectedE.  
	    for(unsigned int i=0;i<Ana->CorrectedE.size();i++){
	      for(unsigned int j=0;j<Ana->CorrectedE[i].size();j++){
	    	CorrectedE->Fill(Ana->CorrectedE[i][j]);
	    	CascadeZ_vs_CorrectedE->Fill(Ana->CorrectedE[i][j],Ana->CascadeZ[i]);
	    	if(Ana->DetM_G==2){
	    	  CascadeZ_vs_CorrectedE_mult2->Fill(Ana->CorrectedE[i][j],Ana->CascadeZ[i]);
	    	}
	      
	      }
	    }
	    //Rob Elder 2018-02-15.  Filling histo for Charlie's sphere AB method.
	    //Rob Elder 2018-03-16.  Adding g-g 2d matrix for AB energies
	    for(unsigned int i=0;i<Ana->AddbackEdcModeSphere.size();i++){
	      DetEDC_ABsph->Fill(Ana->AddbackEdcModeSphere.at(i));
	      DetE_ABsph->Fill(Ana->AddbackEModeSphere.at(i));
	      for(unsigned int j=i+1;j<Ana->AddbackEdcModeSphere.size();j++){
	    	DetEDC_AB_vs_DetEDC_AB->Fill(Ana->AddbackEdcModeSphere[i],Ana->AddbackEdcModeSphere[j]);
	      }
	      //Rob Elder 2018-09-14.  Filling my new histogram that describe the "span" of every gamma-ray
	      Span_vs_DetE_AB->Fill(Ana->AddbackEModeSphere[i],Ana->ABsphereRad[i]);
	      ComptAngDiff_vs_DetE_AB->Fill(Ana->AddbackEModeSphere[i],Ana->ABcomptAngDiff[i]);
	    }
	  
	    for(unsigned int i=0;i<Ana->CorrectedE_AB.size();i++){
	      CascadeZ_AB->Fill(Ana->CascadeZ_AB[i]);
	      CascadeZ_AB_largeRange->Fill(Ana->CascadeZ_AB[i]);
	      for(unsigned int j=0;j<Ana->CorrectedE_AB[i].size();j++){
	    	CorrectedE_AB->Fill(Ana->CorrectedE_AB[i][j]);
	    	CascadeZ_vs_CorrectedE_AB->Fill(Ana->CorrectedE_AB[i][j],Ana->CascadeZ_AB[i]);
	    	if(Ana->AddbackEModeSphere.size()==2){
	    	  CascadeZ_vs_CorrectedE_AB_mult2->Fill(Ana->CorrectedE_AB[i][j],Ana->CascadeZ_AB[i]);
		}	      
	      }
	    }
	    
	    //I also made a gamma-gamma spectrum.  
	    for(int i=0;i<Ana->DetM_G;i++){
	      for(int j=i+1;j<Ana->DetM_G;j++){
	    	DetEDC_G_vs_DetEDC_G->Fill(Ana->DetEDC_G[i],Ana->DetEDC_G[j]);
	      }
	    }
	  }
	  
	  for(int i = 0 ; i < Ana->DetM_G; i++){
		 DetE_G->Fill(Ana->DetE_G[i]);
		 DetEDC_G->Fill(Ana->DetEDC_G[i]);
		 
		 //TM added in v4.2 for Charlie's addback
		 Background->Fill(Ana->DetE_Background_G[i]);
		 BackgroundDC->Fill(Ana->DetEDC_Background_G[i]);
		 Theta_G_vs_DetE_G->Fill(Ana->DetE_G[i],Ana->Theta_G[i]);
		 Theta_G_vs_DetE_Background_G->Fill(Ana->DetE_Background_G[i],Ana->Theta_G[i]); //CRL333
		 Theta_G_vs_DetEDC_G->Fill(Ana->DetEDC_G[i],Ana->Theta_G[i]);
		 if(Ana->Depth_G[i]>=15){ //AR New in v4.3
		   Theta_G_vs_DetEDC_G_dcut->Fill(Ana->DetEDC_G[i],Ana->Theta_G[i]);
		 }
		 Theta_G_vs_DetEDC_Background_G->Fill(Ana->DetEDC_Background_G[i],Ana->Theta_G[i]); //CRL333		 
		 Depth_G_vs_DetE_G->Fill(Ana->DetE_G[i],Ana->Depth_G[i]); //AR New in v4.3
		 Depth_G_vs_DetEDC_G->Fill(Ana->DetEDC_G[i],Ana->Depth_G[i]); //AR New in v4.3
		 DetEDC_vs_Mult->Fill(Ana->DetEDC_G[i],Ana->DetM_G);		 
		 if(Ana->DetM_G==1){	Theta_G_vs_DetEDC_GMult1->Fill(Ana->DetEDC_G[i],Ana->Theta_G[i]);}
		 ////////////
	  }
	  		  
	  if(Ana->AddbackEdc>0){
	    DetAddback->Fill(Ana->AddbackEdc);//CRL333 Fill graphs for Addback Energy and Addback vs Angle
	    Theta_G_vs_Addback->Fill(Ana->AddbackEdc,Ana->Theta_G[Ana->highenmult]);
	  }

	  //if(Ana->AddbackEdcMode1>0){
	  //	DetAddbackMode1->Fill(Ana->AddbackEdcMode1);//CRL333 Fill graphs for Addback Energy and Addback vs Angle
  	  //	Theta_G_vs_AddbackMode1->Fill(Ana->AddbackEdcMode1,Ana->Theta_G[Ana->highenmult]);
          //}

	  if(Ana->AddbackEdcModeSphere.size()>0){
	    unsigned int i =0;
	    while(i<Ana->AddbackEdcModeSphere.size()){
	      DetAddbackModeSphere->Fill(Ana->AddbackEdcModeSphere.at(i));
	      DetAddbackModeSphere_vs_ReactionZ->Fill(Ana->AddbackEdcModeSphere.at(i),Ana->ion_ev[REACTION_FLAG].z);
	      Theta_G_vs_AddbackModeSphere->Fill(Ana->AddbackEdcModeSphere.at(i),Ana->AddbackAngleModeSphere.at(i));
	      Detadd_vs_Mult->Fill(Ana->AddbackEdcModeSphere.at(i),Ana->AddbackMult.at(i));
	      if(Ana->AddbackAngleModeSphere.at(i)<40){
		DetAddbackModeSphereVsMult->Fill(Ana->AddbackEdcModeSphere.at(i),Ana->AddbackMult.at(i));}
	      i++;}
	      }

	  TotalE_G->Fill(Ana->TotalE_G);
	  TotalE_G_vs_Theta_G->Fill(Ana->TotalE_G,Ana->Theta_G[Ana->highenmult]);
	}

	// Any Other Histograms ...
	if(FillHistosS800){
	  S800_DTA->Fill(Ana->d_ta);
	  S800_YTA->Fill(Ana->y_ta);
	  S800_Theta->Fill(Ana->theta_ta);
	  S800_Phi->Fill(Ana->phi_ta);
	  S800_ATA->Fill(Ana->a_ta);
	  S800_BTA->Fill(Ana->b_ta);
	  S800_Beta->Fill(Ana->beta_ta);
	}
}

void ROOTRecorder::CreateHistograms() 
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
	if(FillHistosSeGA){
	 
	  DetE_R1 = new TH1F("DetE_R1","DetE_R1",2000,0,4000);
	  //	  outT->Branch("DetE_R1","TH1F",&DetE_R1,128000,0);
	  
	  DetE_R2 = new TH1F("DetE_R2","DetE_R2",2000,0,4000);
	  //	  outT->Branch("./Histos/DetE_R2","TH1F",&DetE_R2,128000,0);
	  
	  DetEDC_R1 = new TH1F("DetEDC_R1","DetEDC_R1",2000,0,4000);
	  //	  outT->Branch("DetEDC_R1","TH1F",&DetEDC_R1,128000,0);
	  
	  DetEDC_R2 = new TH1F("DetEDC_R2","DetEDC_R2",2000,0,4000);
	  //	  outT->Branch("DetEDC_R2","TH1F",&DetEDC_R2,128000,0);

	  DetEDC_R1_M1 = new TH1F("DetEDC_R1_M1","DetEDC_R1_M1",2000,0,4000);
	  //	  outT->Branch("DetEDC_R1","TH1F",&DetEDC_R1,128000,0);
	  
	  DetEDC_R2_M1 = new TH1F("DetEDC_R2_M1","DetEDC_R2_M1",2000,0,4000);
	  //	  outT->Branch("DetEDC_R2","TH1F",&DetEDC_R2,128000,0);

	  for(G4int i = 0; i< 24 ; i++){
		 CoreEDC[i] = new TH1F(Form("CoreEDC_%02d",i),Form("CoreEDC_%02d",i),2000,0,4000);
		 //
		 //		 CoreEDC511[i] = new TH1F(Form("CoreEDC511_%02d",i),Form("CoreEDC511_%02d",i),2000,0,4000);
		 // Segments
		 if(FillHistosSeGASeg){
			for(int j = 0 ; j < 32; j++){
			  SegE[i][j]  = new TH1F(Form("SegE_%02d_%02d",i,j),Form("SegE_%02d_%02d",i,j),2000,0,4000);
			  SegEDC[i][j]  = new TH1F(Form("SegEDC_%02d_%02d",i,j),Form("SegECD_%02d_%02d",i,j),2000,0,4000);
			  SegAng[i][j]  = new TH1F(Form("SegA_%02d_%02d",i,j),Form("SegA_%02d_%02d",i,j),200,-1,1);
			}
		 }
	  }

	}

	// Gretina Histos, changed for v4.2 for sphere addback
	if(FillHistosGretina){
	  DetE_G = new TH1F("DetE_G","DetE_G",4000,0,4000);
	  DetEDC_G = new TH1F("DetEDC_G","DetEDC_G",4000,0,4000);
	  Background=new TH1F("Background","Background",4000,0,4000);
	  BackgroundDC=new TH1F("BackgroundDC","BackgroundDC",4000,0,4000);
	  Theta_G_vs_DetE_G = new TH2F("Theta_G_vs_DetE_G","Theta_G_vs_DetE_G",4000,0,4000,360,0,180);
	  Theta_G_vs_DetE_Background_G = new TH2F("Theta_G_vs_DetE_Background_G","Theta_G_vs_DetE_Background_G",4000,0,4000,360,0,180); //CRL333
	  Theta_G_vs_DetEDC_G = new TH2F("Theta_G_vs_DetEDC_G","Theta_G_vs_DetEDC_G",4000,0,4000,360,0,180);
	  Theta_G_vs_DetEDC_G_dcut = new TH2F("Theta_G_vs_DetEDC_G_dcut","Theta_G_vs_DetEDC_G_dcut",4000,0,4000,360,0,180);
	  Depth_G_vs_DetE_G = new TH2F("Depth_G_vs_DetE_G","Depth_G_vs_DetE_G",4000,0,4000,220,-10,100); //AR New in v4.3
	  Depth_G_vs_DetEDC_G = new TH2F("Depth_G_vs_DetEDC_G","Depth_G_vs_DetEDC_G",4000,0,4000,220,-10,100); //AR New in v4.3
	  Theta_G_vs_DetEDC_Background_G = new TH2F("Theta_G_vs_DetEDC_Background_G","Theta_G_vs_DetEDC_Background_G",4000,0,4000,360,0,180); //CRL333
	  Theta_G_vs_DetEDC_GMult1 = new TH2F("Theta_G_vs_DetEDC_GMult1","Theta_G_vs_DetEDC_GMult1",4000,0,4000,360,0,180);
	  //Theta_G_vs_AddbackMode1 = new TH2F("Theta_G_vs_AddbackMode1","Theta_G_vs_AddbackMode1",4000,0,4000,360,0,180);
	  Theta_G_vs_AddbackModeSphere = new TH2F("Theta_G_vs_AddbackModeSphere","Theta_G_vs_AddbackModeSphere",4000,0,4000,360,0,180);
	  TotalE_G = new TH1F("TotalE_G","Add Back Energy",4000,0,4000);
	  TotalE_G_vs_Theta_G=new TH2F("Theta_G_vs_TotalE_G","Theta_G_vs_TotalE_G",4000,0,4000,360,0,180);
	   
	  DetEDC_vs_Mult = new TH2F("DetEDC_vs_Mult","DetEDC_vs_Mult",4000,0,4000,10,0,10);

	  //DetAddbackMode1=new TH1F("DetAddbackMode1","DetAddbackMode1",4000,0,4000);
	  DetAddbackModeSphere=new TH1F("DetAddbackModeSphere","DetAddbackModeSphere",4000,0,4000);
  	  DetAddbackModeSphere_vs_ReactionZ=new TH2F("DetAddbackModeSphere_vs_ReactionZ","DetAddbackModeSphere_vs_ReactionZ",4000,0,4000,1000,-500,500);
 	  DetAddbackModeSphereVsMult=new TH2F("DetAddbackModeSphereVsMult","DetAddbackModeSphereVsMult",4000,0,4000,10,0,10);

	  Detadd_vs_Mult = new TH2F("Detadd_vs_Mult","Detadd_vs_Mult",4000,0,4000,10,0,10);

	  //AR New in v4.3 -> Creating Histos for Rob's Cascade Analysis
	  if(FillHistosCascade){
	    CascadeZ = new TH1F("CascadeZ","CascadeZ",2000,0,2000);
	    CascadeZ_largeRange = new TH1F("CascadeZ_largeRange","CascadeZ_largeRange",4000,-2000,2000); //Rob Elder 2018-12-03
	    CascadeZ_AB_largeRange = new TH1F("CascadeZ_AB_largeRange","CascadeZ_AB_largeRange",4000,-2000,2000); //Rob Elder 2018-12-03
	    CorrectedE = new TH1F("CorrectedE","CorrectedE",4000,0,4000);
	    DetEDC_G_vs_DetEDC_G = new TH2F("DetEDC_G_vs_DetEDC_G","DetEDC_G_vs_DetEDC_G",1000,0,4000,1000,0,4000);
	    CascadeZ_vs_CorrectedE = new TH2F("CascadeZ_vs_CorrectedE","CascadeZ_vs_CorrectedE",1000,0,4000,1000,0,2000);
	    CascadeZ_vs_CorrectedE_mult2 = new TH2F("CascadeZ_vs_CorrectedE_mult2","CascadeZ_vs_CorrectedE_mult2",1000,0,4000,1000,0,2000);
	    DetEDC_ABsph=new TH1F("DetEDC_ABsph","DetEDC_ABsph",4000,0,4000);
	    DetE_ABsph=new TH1F("DetE_ABsph","DetE_ABsph",4000,0,4000);
	    CascadeZ_AB = new TH1F("CascadeZ_AB","CascadeZ_AB",2000,0,2000);
	    CorrectedE_AB = new TH1F("CorrectedE_AB","CorrectedE_AB",4000,0,4000);
	    CascadeZ_vs_CorrectedE_AB = new TH2F("CascadeZ_vs_CorrectedE_AB","CascadeZ_vs_CorrectedE_AB",1000,0,4000,1000,0,2000);
	    CascadeZ_vs_CorrectedE_AB_mult2 = new TH2F("CascadeZ_vs_CorrectedE_AB_mult2","CascadeZ_vs_CorrectedE_AB_mult2",1000,0,4000,1000,0,2000);
	    DetEDC_AB_vs_DetEDC_AB = new TH2F("DetEDC_AB_vs_DetEDC_AB","DetEDC_AB_vs_DetEDC_AB",1000,0,4000,1000,0,4000);
	    //Rob Elder 2018-09-14.  Adding histograms to observe the (simulated) properties that I use as criteria for my gates.
	    //I don't actually use "span" as a criteria without sphere AB because the unusual shape of crystal AB overlaid with
	    //a spherical "span" is strange.  
	    Span_vs_DetE_AB = new TH2F("Span_vs_DetE_AB","Span_vs_DetE_AB",2000,0,4000,200,0,200);
	    ComptAngDiff_vs_DetE_AB = new TH2F("ComptAngDiff_vs_DetE_AB","ComptAngDiff_vs_DetE_AB",2000,0,4000,200,0,3.2);
	  }
	  
	}

	// S800 histograms
	if(FillHistosS800){
	  S800_DTA  = new TH1F("S800_DTA","S800_DTA",200,-10,10);
	  //	  outT->Branch("S800_DTA","TH1F",&S800_DTA,128000,0);

	  S800_YTA  = new TH1F("S800_YTA","S800_YTA",100,-50,50);
	  //	  outT->Branch("S800_YTA","TH1F",&S800_YTA,128000,0);
	  
	  S800_Theta  = new TH1F("S800_Theta","S800_Theta",100,0,100);
	  //	  outT->Branch("S800_Theta","TH1F",&S800_Theta,128000,0);
	  
	  S800_Phi  = new TH1F("S800_Phi","S800_Phi (mrad)",2000,0,2000);
	  //	  outT->Branch("S800_Phi","TH1F",&S800_Phi,128000,0);
	  
	  S800_ATA  = new TH1F("S800_ATA","S800_ATA",200,-100,100);
	  //	  outT->Branch("S800_ATA","TH1F",&S800_ATA,128000,0);
	  
	  S800_BTA  = new TH1F("S800_BTA","S800_BTA (mrad)",200,-100,100);
	  //	  outT->Branch("S800_BTA","TH1F",&S800_BTA,128000,0); 
	  S800_Beta  = new TH1F("S800_Beta","S800_Beta ",200,0.2,0.4);
	  //	  outT->Branch("S800_BTA","TH1F",&S800_BTA,128000,0);
 	}
}
void ROOTRecorder::WriteHistograms() 
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif

}


void ROOTRecorder::FillTree()
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
	if(FillTreeSeGA || FillTreeS800 || FillTreeGretina){
	  outT->Fill();
	}
}


void ROOTRecorder::outAttach()
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif

	if(FillTreeS800){
	  // Ions 
	  outT->Branch("gun",&Ana->ion_ev[GUN_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  outT->Branch("reaction",&Ana->ion_ev[REACTION_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  // 	  outT->Branch("decayold",&Ana->ion_ev[DECAY_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  outT->Branch("target_face",&Ana->ion_ev[TARGET_FACE_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  outT->Branch("target_back",&Ana->ion_ev[TARGET_BACK_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  outT->Branch("degrader_face",&Ana->ion_ev[DEGRADER_FACE_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  outT->Branch("degrader_back",&Ana->ion_ev[DEGRADER_BACK_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  outT->Branch("stopper_face",&Ana->ion_ev[STOPPER_FACE_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");
	  outT->Branch("stopper_back",&Ana->ion_ev[STOPPER_BACK_FLAG],"beta/D:theta/D:phi/D:time/D:labtime/D:globaltime/D:KE/D:x/D:y/D:z/D");

	  // Decay Control variables
	  outT->Branch("DecayM",&Ana->DecayM,"DecayM/I");
	  outT->Branch("Decay.LevelID",Ana->ion_dec.LevelID,"Decay.LevelID[DecayM]/I"); 
	  outT->Branch("Decay.LevelE",Ana->ion_dec.LevelE,"Decay.LevelE[DecayM]/D"); 
	  outT->Branch("Decay.beta",Ana->ion_dec.beta,"Decay.beta[DecayM]/D"); 
	  outT->Branch("Decay.theta",Ana->ion_dec.theta,"Decay.phi[DecayM]/D"); 
	  outT->Branch("Decay.phi",Ana->ion_dec.phi,"Decay.phi[DecayM]/D"); 
	  outT->Branch("Decay.time",Ana->ion_dec.time,"Decay.time[DecayM]/D"); 
	  outT->Branch("Decay.labtime",Ana->ion_dec.labtime,"Decay.labtime[DecayM]/D"); 
	  outT->Branch("Decay.globaltime",Ana->ion_dec.globaltime,"Decay.globaltime[DecayM]/D"); 
	  outT->Branch("Decay.KE",Ana->ion_dec.KE,"Decay.KE[DecayM]/D"); 
	  outT->Branch("Decay.x",Ana->ion_dec.y,"Decay.x[DecayM]/D"); 
	  outT->Branch("Decay.y",Ana->ion_dec.x,"Decay.y[DecayM]/D"); 
	  outT->Branch("Decay.z",Ana->ion_dec.z,"Decay.z[DecayM]/D"); 

	}
	if(FillTreeSeGA )	{
	  // Gamma Rays 
	  outT->Branch("DetM",&Ana->DetM,"DetM/I");
	  outT->Branch("RingNr",Ana->RingNr,"RingNr[DetM]/I");
	  outT->Branch("DetNr",Ana->DetNr,"DetNr[DetM]/I");
	  outT->Branch("DetE",Ana->DetE,"DetE[DetM]/D");
	  // Doppler Corrected energy
	  outT->Branch("DetEDC",Ana->DetEDC,"DetEDC[DetM]/D");
	  
	  // Segments
	  outT->Branch("MaxSegNr",Ana->MaxSegNr,"MaxSegNr[DetM]/I");
	  outT->Branch("SegTheta",Ana->SegTheta,"SegTheta[DetM]/D");
	  outT->Branch("SegPhi",Ana->SegPhi,"SegPhi[DetM]/D");
	  outT->Branch("CosThetaCM",Ana->CosThetaCM,"CosThetaCM[DetM]/D");
	  
	  outT->Branch("dR",Ana->dR,"dR[DetM]/D");
	  outT->Branch("dTheta",Ana->dTheta,"dTheta[DetM]/D");
	  outT->Branch("dPhi",Ana->dPhi,"dPhi[DetM]/D");
	  outT->Branch("R",Ana->R,"R[DetM]/D");
	  outT->Branch("Theta",Ana->Theta,"Theta[DetM]/D");
	  outT->Branch("Phi",Ana->Phi,"Phi[DetM]/D");
	  
	  outT->Branch("dX",Ana->dX,"dX[DetM]/D");
	  outT->Branch("dY",Ana->dY,"dY[DetM]/D");
	  outT->Branch("dZ",Ana->dZ,"dZ[DetM]/D");
	  
	// outT->Branch("MaxSegX",Ana->MaxSegX,"MaxSegA[DetM]/D");
	// outT->Branch("MaxSegY",Ana->MaxSegZ,"MaxSegA[DetM]/D");
	// outT->Branch("MaxSegZ",Ana->MaxSegY,"MaxSegA[DetM]/D");
	  outT->Branch("SegM",&Ana->SegM,"SegM/I");
	  outT->Branch("SegNr",Ana->SegNr,"SegNr[SegM]/I");
	  outT->Branch("SegS",Ana->SegS,"SegS[SegM]/I");
	  outT->Branch("SegQ",Ana->SegQ,"SegQ[SegM]/I");
	  outT->Branch("SegDetPtr",Ana->SegDetPtr,"SegDetPtr[SegM]/I");
	  
	  // Decay information 
	  // 	outT->Branch("DecayTheta",Ana->SegThetha,"DecayTheta[DetM]/D");
	  // 	outT->Branch("DecayPhi",Ana->SegPhi,"DecayPhi[DetM]/D");
	  
	  
	  outT->Branch("track_N",&Ana->track_N,"track_N/I");
	  outT->Branch("track_D",Ana->track_D,"track_D[track_N]/I");
	  outT->Branch("track_R",Ana->track_R,"track_R[track_N]/I");
	  outT->Branch("track_S",Ana->track_S,"track_S[track_N]/I");
	  outT->Branch("track_Q",Ana->track_Q,"track_Q[track_N]/I");
	  outT->Branch("track_x",Ana->track_x,"track_x[track_N]/D");
	  outT->Branch("track_y",Ana->track_y,"track_y[track_N]/D");
	  outT->Branch("track_z",Ana->track_z,"track_z[track_N]/D");
	  outT->Branch("track_E",Ana->track_E,"track_E[track_N]/D"); 
	}

	// Gretina Data
	if(FillTreeGretina ){
	  outT->Branch("DetM_G",&Ana->DetM_G,"DetM_G/I");
	  outT->Branch("DetClNr_G",Ana->DetClNr_G,"DetClNr_G[DetM_G]/I");
	  outT->Branch("DetNr_G",Ana->DetNr_G,"DetNr_G[DetM_G]/I");
	  outT->Branch("DetE_G",Ana->DetE_G,"DetE_G[DetM_G]/D");
	  outT->Branch("DetEDC_G",Ana->DetEDC_G,"DetEDC_G[DetM_G]/D");
	  outT->Branch("TotalE_G",&Ana->TotalE_G,"TotalE_G/D");
	  outT->Branch("R_G",Ana->R_G,"R_G[DetM_G]/D");
	  outT->Branch("Theta_G",Ana->Theta_G,"Theta_G[DetM_G]/D");
	  outT->Branch("Phi_G",Ana->Phi_G,"Phi_G[DetM_G]/D");
	  outT->Branch("dR_G",Ana->dR_G,"dR_G[DetM_G]/D");
	  outT->Branch("dTheta_G",Ana->dTheta_G,"dTheta_G[DetM_G]/D");
	  outT->Branch("dPhi_G",Ana->dPhi_G,"dPhi_G[DetM_G]/D");
	  outT->Branch("Depth_G",Ana->Depth_G,"Depth_G[DetM_G]/D");
	  outT->Branch("X_G",Ana->X_G,"X_G[DetM_G]/D");
	  outT->Branch("Y_G",Ana->Y_G,"Y_G[DetM_G]/D");
	  outT->Branch("Z_G",Ana->Z_G,"Z_G[DetM_G]/D");
	}
	
	parT->Branch("NumOfGams",&Ana->NumOfStates,"NumOfGams/I");
	//--- Units of keV
	parT->Branch("StateE",Ana->StateEnergies,"StateE[NumOfGams]/D");	
	parT->Branch("GammaE",Ana->GammaEnergies,"GammaE[NumOfGams]/D");
	//--- Units of ps				
	parT->Branch("GammaTau",Ana->GammaTau,"GammaTau[NumOfGams]/D");		
	parT->Branch("GammaFrac",Ana->GammaFrac,"GammaFrac[NumOfGams]/D");		
	
	//--- Length all in units of mm
	parT->Branch("Rt",&Ana->RatioTarget,"Rt/D");
	parT->Branch("Rd",&Ana->RatioDegrader,"Rd/D");	
	parT->Branch("TarThick",&Ana->TargetThickness,"TarThick/D");		
	parT->Branch("DegThick",&Ana->DegraderThickness,"DegThick/D");		
	parT->Branch("StopThick",&Ana->StopperThickness,"StopThick/D");			 		    
	parT->Branch("d1",&Ana->Distance1,"d1/D");
	parT->Branch("d2",&Ana->Distance2,"d2/D");
		
}

void ROOTRecorder::Init()
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif

}


void ROOTRecorder::SetFileName(const G4String name) 
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
  outTreeName = name;
}

void ROOTRecorder::BeginOfRun() 
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif

	OpenOutputTree();
	Init();
	if(FillTreeSeGA || FillTreeS800|| FillTreeGretina){
	  outAttach();
	}

	if(FillHistosSeGA || FillHistosS800 || FillHistosGretina){
	  CreateHistograms();
	}
}

void ROOTRecorder::EndOfRun() 
{
#ifdef DEBUG
	G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
	if(FillHistosSeGA || FillHistosS800 || FillHistosGretina){
	  WriteHistograms();
	}
	CloseOutputTree();
}


void ROOTRecorder::SetFillHistosSeGA(G4bool b){
  FillHistosSeGA = b; 

  G4cout<<"----> RootRecorder : Save SeGA Histograms : " ;
  if (FillHistosSeGA) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  }

}

void ROOTRecorder::SetFillHistosGretina(G4bool b){
  FillHistosGretina = b; 

  G4cout<<"----> RootRecorder : Save Gretina Histograms : " ;
  if (FillHistosGretina) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  }

}

void ROOTRecorder::SetFillHistosSeGASeg(G4bool b){
  FillHistosSeGASeg = b; 

  G4cout<<"----> RootRecorder : Save SeGA Segments Histograms : " ;
  if (FillHistosSeGASeg) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  }

}

void ROOTRecorder::SetFillHistosS800(G4bool b){
  FillHistosS800 = b; 
  G4cout<<"----> RootRecorder : Save S800 Histograms : " ;
  if (FillHistosS800) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  }
}

void ROOTRecorder::SetFillTreeSeGA(G4bool b){
  FillTreeSeGA = b;
  G4cout<<"----> RootRecorder : Save SeGA parameters in Tree  : " ;
  if (FillTreeSeGA) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  } 
}

void ROOTRecorder::SetFillTreeS800(G4bool b){
  
  FillTreeS800 = b; 
  G4cout<<"----> RootRecorder : Save S800 parameters in Tree  : " ;
  if (FillTreeS800) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  } 
}

void ROOTRecorder::SetFillTreeGretina(G4bool b){
  
  FillTreeGretina = b; 
  G4cout<<"----> RootRecorder : Save Gretina parameters in Tree  : " ;
  if (FillTreeGretina) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  } 
}

//AR New in v4.3 -> For Rob's Cascade Analysis
void ROOTRecorder::SetFillHistosCascade(G4bool b){
  FillHistosCascade = b; 
  G4cout<<"----> RootRecorder : Save Cascade Analysis Histograms : " ;
  if (FillHistosCascade) {
	 G4cout << "\t YES" << G4endl;
  }
  else{
	 G4cout << "\t NO" << G4endl;
  }
}
