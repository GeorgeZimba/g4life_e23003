#include "TrackerGammaSD.hh"
#include "G4HCofThisEvent.hh"
#include "G4Step.hh"
#include "G4ThreeVector.hh"
#include "G4SDManager.hh"
#include "G4ios.hh"
#include "G4UnitsTable.hh"
#include "G4VTouchable.hh"
#include <string.h>
#include <stdio.h>



TrackerGammaSD::TrackerGammaSD(G4String name)
 :G4VSensitiveDetector(name)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  G4String HCname;
  collectionName.insert(HCname="gammaCollection");
}


TrackerGammaSD::~TrackerGammaSD(){ 
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 

}


void TrackerGammaSD::Initialize(G4HCofThisEvent*)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  gammaCollection = new TrackerGammaHitsCollection
	 (SensitiveDetectorName,collectionName[0]); 
 
}




G4bool TrackerGammaSD::ProcessHits(G4Step* aStep,G4TouchableHistory*)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  
  G4double DE = aStep->GetPreStepPoint()->GetKineticEnergy() - aStep->GetPostStepPoint()->GetKineticEnergy();
  if(DE < 0.001*eV) return false;
  
  G4double edep = aStep->GetTotalEnergyDeposit();
  
  string name=aStep->GetPostStepPoint()->GetTouchable()->GetVolume()->GetName(); 
  G4int number;
  G4int ring;
#ifdef DEBUG
  G4cout << "Edep : " << edep << " Delta : "<<  DE <<  " Name " << name << " Part " << aStep->GetTrack()->GetDefinition()->GetParticleName()<<  G4endl;
#endif


  istringstream in;
  in.str(name.substr(5,10));
  in>>number;
  ring=(int)(number/1000.);
  number-=ring*1000;

  if(name.substr(0,4)=="SeGA")
    {
      TrackerGammaHit* newHit = new TrackerGammaHit();

      newHit->SetTrackID  (aStep->GetTrack()->GetTrackID());

      newHit->SetParticleID(aStep->GetTrack()->GetDefinition()->GetParticleName());
      newHit->SetParentTrackID(aStep->GetTrack()->GetParentID());
      newHit->SetDetNumb(number);
      newHit->SetRingID(ring);
      newHit->SetSliceNbi(aStep->GetPreStepPoint()->GetTouchable()->GetReplicaNumber());
      newHit->SetQuartNbi(aStep->GetPreStepPoint()->GetTouchable()->GetReplicaNumber(1));
      newHit->SetSliceNbf(aStep->GetPostStepPoint()->GetTouchable()->GetReplicaNumber());
      newHit->SetQuartNbf(aStep->GetPostStepPoint()->GetTouchable()->GetReplicaNumber(1));
      newHit->SetEdep(edep);
      newHit->SetPos(aStep->GetPostStepPoint()->GetPosition());
      gammaCollection->insert( newHit );
      newHit->Draw();
		if(verboseLevel>0) newHit->Print();

      return true;
    }
  else
    {
      
#ifdef DEBUG
 		G4cout << "E="<<G4BestUnit(edep,"Energy")<<G4endl;
  		G4cout << "Particle : " << aStep->GetTrack()->GetDefinition()->GetParticleName()<<G4endl;
  		G4cout <<" Volume : " << name <<G4endl;
 		G4cout <<"Event ignored" <<G4endl;
  		getc(stdin);
#endif
		return false;
    }


}




void TrackerGammaSD::EndOfEvent(G4HCofThisEvent* HCE)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 

#ifdef DEBUG
  G4int NbHits = gammaCollection->entries();
  if (NbHits>0) 
	 { 
	    
	   G4cout << "\n-------->Hits Collection: in this event they are " << NbHits 
				 << " hits for gamma tracking: " << G4endl;
	   for (i=0;i<NbHits;i++) (*gammaCollection)[i]->Print();
	 }
#endif 

  static G4int HCID = -1;
  if(HCID<0)
	 { HCID = G4SDManager::GetSDMpointer()->GetCollectionID(collectionName[0]); }
  HCE->AddHitsCollection( HCID, gammaCollection ); 
}





