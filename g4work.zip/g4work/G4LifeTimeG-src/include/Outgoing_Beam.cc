#include "Outgoing_Beam.hh"
#include "GammaDecayChannel.hh"
#include "G4DecayTable.hh"
#include "G4Decay.hh"
#include "G4ProcessManager.hh"
//#define DEBUG 1
G4Decay Outgoing_Beam::decay;

Outgoing_Beam::Outgoing_Beam()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  DZ=0;
  DA=0;

  TarEx1=511.5*keV;
  TarEx2=500.0*keV;
  TFrac=0.;
  CFrac=1.;
  betaDopp=0.33;
  posDopp.setX(0.);
  posDopp.setY(0.);
  posDopp.setZ(0.);
  dp_cent=0.*MeV;
  dp_sigma=100.*MeV;
  dp_frac=1.;
  dp_centR= Outgoing_Beam::Getdp();
  dp_sigmaR= Outgoing_Beam::GetdpFWHM();
  dp_fracR= Outgoing_Beam::Getdpf();

  
  reacted=false;
  twopi=8.*atan(1.);

  NS=1;SL=0;
  SetUpEnergyStates();

  NQ=1;SQ=0;
  SetUpChargeStates();

 
  beamIn = NULL;

 
}

Outgoing_Beam::~Outgoing_Beam()
{
  ;
}

void Outgoing_Beam::defaultIncomingIon(Incoming_Beam *bi)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  if (bi == NULL) {
    return;
  }
  beamIn = bi;
}

//---------------------------------------------------------
void Outgoing_Beam::ScanInitialConditions(const G4Track & aTrack)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
 
  dirIn=aTrack.GetMomentumDirection();
  posIn=aTrack.GetPosition();
  pIn=aTrack.GetMomentum();
  KEIn=aTrack.GetDynamicParticle()->GetKineticEnergy();
  Ain=aTrack.GetDynamicParticle()->GetDefinition()->GetAtomicMass();
  Zin=aTrack.GetDynamicParticle()->GetDefinition()->GetAtomicNumber();
  tauIn=aTrack.GetProperTime();
  ReactionFlag=-1;
  if(aTrack.GetVolume()->GetLogicalVolume()->GetName()=="target_log")
    ReactionFlag=0;
  if(aTrack.GetVolume()->GetLogicalVolume()->GetName()=="degrader_log")
    ReactionFlag=1;
  if(aTrack.GetVolume()->GetLogicalVolume()->GetName()=="stopper_log")
    ReactionFlag=2;
}

//---------------------------------------------------------
G4ThreeVector Outgoing_Beam::ReactionPosition()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
 
  posOut=posIn;
  posOut.setZ(posIn.getZ()+eps);
  //G4cout<<"Raction took place at "<<G4BestUnit(posOut.getZ(),"Length")<<G4endl;

  return posOut;

}
//---------------------------------------------------------
G4DynamicParticle* Outgoing_Beam::ReactionProduct()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  int id;
  vector<G4ParticleDefinition*>::iterator sPos = NewIon.begin();
  

  id=LevelMap[(G4int)(1000.*G4UniformRand())];



  for(G4int i=0; i<id; i++)
    sPos++;

  // Note 06/10/2011 Possibility to bias AD cannot be used here
  G4DynamicParticle* aReactionProduct =new G4DynamicParticle(*sPos,GetOutgoingMomentum());

  //  aReactionProduct->SetProperTime(tauIn);
  // G4cout<<" Proper time set to "<<aReactionProduct->GetProperTime()<<G4endl;

  return aReactionProduct;
}
//---------------------------------------------------------
G4DynamicParticle* Outgoing_Beam::ProjectileGS()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  vector<G4ParticleDefinition*>::iterator sPos = NewIon.begin();
  G4DynamicParticle* aReactionProduct =new G4DynamicParticle(*sPos,GetOutgoingMomentum());

  //  aReactionProduct->SetProperTime(tauIn);
  // G4cout<<" Proper time set to "<<aReactionProduct->GetProperTime()<<G4endl;

  return aReactionProduct;
}
//---------------------------------------------------------
G4DynamicParticle* Outgoing_Beam::TargetExcitation()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  
  particleTable = G4ParticleTable::GetParticleTable();
  
  
  G4DynamicParticle* aReactionProduct =new G4DynamicParticle(particleTable->FindParticle("gamma"),TargetAngularDistribution(),GetTargetExcitation());
  
  
  return aReactionProduct;
}
//---------------------------------------------------------
G4double Outgoing_Beam::GetTargetExcitation()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  if(G4UniformRand()<CFrac) 
    return TarEx1;
  else
    return TarEx2;	
}
//---------------------------------------------------------
G4ThreeVector Outgoing_Beam::TargetAngularDistribution()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  
  return G4RandomDirection();
}

//---------------------------------------------------------
G4ThreeVector Outgoing_Beam::GetOutgoingMomentum()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

//TM added 6/25/2018, trying to account for reaction momentum distribution			
  if(ReactionFlag==1)
    { // Knockout kinematics KS 1/12/2009
      G4ThreeVector ppOut,dp;
      G4double dpp;
      // set outgoing residue momentum as fraction of incoming momentum
      // according to mass split. With this we assume no change in velocity
      // due to reaction mechanism

      ppOut=dp_fracR*pIn * (float(Ain+DA) / float(Ain)); //

      // Now try to account for reaction momentum spread
      // centroid and FWHM width of a gaussian CM momentum distribution given
      if (dp_sigmaR > 0.0) {
	dpp=fabs(CLHEP::RandGauss::shoot(dp_centR,dp_sigmaR));
	dp=G4RandomDirection();
	if(dpp != 0) dp.setMag(dpp);
	ppOut -= dp;
      }

      return ppOut;
    }
////
    
  // Knockout kinematics KS 1/12/2009
  G4ThreeVector ppOut,dp;
  G4double dpp;
  // set outgoing residue momentum as fraction of incoming momentum
  // according to mass split. With this we assume no change in velocity
  // due to reaction mechanism
  
  ppOut=dp_frac*pIn * (float(Ain+DA) / float(Ain)); // 
 
  // Now try to account for reaction momentum spread
  // centroid and FWHM width of a gaussian CM momentum distribution given  
  if (dp_sigma > 0.0) {
    dpp=fabs(CLHEP::RandGauss::shoot(dp_cent,dp_sigma));    
    dp=G4RandomDirection();
	 if(dpp != 0) dp.setMag(dpp);
	 ppOut -= dp;
  }
  
  return ppOut;

}


//---------------------------------------------------------
void Outgoing_Beam::Report()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
 

  G4cout<<"----> Delta Z for the outgoing beam set to  "<<DZ<< G4endl;
  G4cout<<"----> Delta A for the outgoing beam set to  "<<DA<< G4endl;
  G4cout<<"----> Beta for the outgoing beam set to "<<betaDopp<<G4endl; 
  G4cout<<"----> X position for the outgoing beam Doppler corrections set to "<<posDopp.getX()<<G4endl; 
  G4cout<<"----> Y position for the outgoing beam Doppler corrections set to "<<posDopp.getY()<<G4endl; 
  G4cout<<"----> Z position for the outgoing beam Doppler corrections set to "<<posDopp.getZ()<<G4endl;
  G4cout<<"----> Number of charge states "<<NQ<<G4endl;
  vector<Charge_State*>::iterator itPos = Q.begin();
  for(; itPos < Q.end(); itPos++) 
	 {
		G4cout<<"----> Charge state "     <<(*itPos)->GetCharge()<<G4endl;
		G4cout<<"   => UnReactedFraction "<<(*itPos)->GetUnReactedFraction()<<G4endl;
		G4cout<<"   =>   ReactedFraction "<<(*itPos)->GetReactedFraction()<<G4endl;
		if((*itPos)->GetUseSetKEu())
		  {
			 G4cout<<"   =>              KE/A "<<(*itPos)->GetSetKEu()/MeV<<" MeV"<<G4endl; 
			 G4cout<<"   =>                KE "<<(*itPos)->GetSetKE()/MeV<<" MeV"<<G4endl;
		  }
		else
		  G4cout<<"   =>                KE "<<(*itPos)->GetSetKE()/MeV<<" MeV"<<G4endl;
	 }
  CalcQUR();
  CalcQR();
  ReportEnergyStates();
  //
  ReportBackgroundStates();
}


//---------------------------------------------------------
void Outgoing_Beam::setDA(G4int da)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  DA=da;
  G4cout<<"----> Delta A for the outgoing beam set to  "<<DA<< G4endl; 
}
//---------------------------------------------------------
void Outgoing_Beam::setDZ(G4int dz)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  DZ=dz;
  G4cout<<"----> Delta Z for the outgoing beam set to  "<<DZ<< G4endl;
  
}

//---------------------------------------------------------
void Outgoing_Beam::setTarEx1(G4double ex)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  TarEx1=ex;
  
  G4cout<<"----> Target excitation energy 1 set to "<< G4BestUnit(TarEx1,"Energy")<<G4endl;

}
//---------------------------------------------------------
void Outgoing_Beam::setTarEx2(G4double ex)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  TarEx2=ex;
  
  G4cout<<"----> Target excitation energy 2 set to "<< G4BestUnit(TarEx2,"Energy")<<G4endl;

}
//---------------------------------------------------------
void Outgoing_Beam::setTFrac(G4double ex)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  TFrac=ex;
  if(TFrac>1) TFrac=1.;
  if(TFrac<0) TFrac=0.;

  
  G4cout<<"----> Fraction of target excitations set to "<<TFrac<<G4endl;

}
//---------------------------------------------------------
void Outgoing_Beam::setCFrac(G4double ex)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  CFrac=ex;
  if(CFrac>1) CFrac=1.;
  if(CFrac<0) CFrac=0.;

  
  G4cout<<"----> Fraction of target excitation energy 1 to energy 2 set to "<<CFrac<<G4endl;

}

//---------------------------------------------------------
void Outgoing_Beam::setDoppbeta(G4double b)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  betaDopp=b;

  G4cout<<"----> Beta for the outgoing beam beam Doppler corrections set to "<<betaDopp<<G4endl; 
}
//---------------------------------------------------------
void Outgoing_Beam::setDoppZ(G4double z)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  posDopp.setZ(z);

  G4cout<<"----> Z position for the outgoing beam Doppler corrections set to "<<posDopp.getZ()<<G4endl; 
}
//---------------------------------------------------------
void Outgoing_Beam::setDoppY(G4double y)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  posDopp.setY(y);

  G4cout<<"----> Y position for the outgoing beam Doppler corrections set to "<<posDopp.getY()<<G4endl; 
}

//---------------------------------------------------------
void Outgoing_Beam::setDoppX(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  posDopp.setX(x);

  G4cout<<"----> X position for the outgoing beam Doppler corrections set to "<<posDopp.getX()<<G4endl; 
}
//---------------------------------------------------------
void Outgoing_Beam::SetUpChargeStates()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  vector<Charge_State*>::iterator itPos = Q.begin();
  // clear all elements from the array
  for(; itPos < Q.end(); itPos++)
    delete *itPos;    // free the element from memory
  // finally, clear all elements from the array
  Q.clear();

  for(G4int i=0;i<NQ;i++) 
    Q.push_back(new Charge_State);


}
//---------------------------------------------------------
void Outgoing_Beam::SetQCharge(G4int q)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SQ>=0&&SQ<NQ)
    {
      vector<Charge_State*>::iterator itPos = Q.begin();

      for(G4int i=0;i<SQ;i++) itPos++;
      (*itPos)->SetCharge(q);
    }
  else
    G4cout<<" Number of defined charge states ="<<NQ<<" is too small"<<G4endl;
}

//---------------------------------------------------------
void Outgoing_Beam::SetQUnReactedFraction(G4double f)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SQ>=0&&SQ<NQ)
    {
      vector<Charge_State*>::iterator itPos = Q.begin();

      for(G4int i=0;i<SQ;i++) itPos++;
      (*itPos)->SetUnReactedFraction(f);
      CalcQUR();
    }
  else
    G4cout<<" Number of defined charge states ="<<NQ<<" is too small"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::SetQReactedFraction(G4double f)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SQ>=0&&SQ<NQ)
    {
      vector<Charge_State*>::iterator itPos = Q.begin();

      for(G4int i=0;i<SQ;i++) itPos++;
      (*itPos)->SetReactedFraction(f);
      CalcQR();
    }
  else
    G4cout<<" Number of defined charge states ="<<NQ<<" is too small"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::SetQKEu(G4double e)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  G4int A;
  
  A=beamIn->getA()+DA;
  if(SQ>=0&&SQ<NQ)
    {
      vector<Charge_State*>::iterator itPos = Q.begin();
  
      for(G4int i=0;i<SQ;i++) itPos++;
      (*itPos)->SetKEu(e,A);
      CalcQR();
      CalcQUR();
    }
  else
    G4cout<<" Number of defined charge states ="<<NQ<<" is too small"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::SetQKE(G4double e)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SQ>=0&&SQ<NQ)
    {
      vector<Charge_State*>::iterator itPos = Q.begin();

      for(G4int i=0;i<SQ;i++) itPos++;
      (*itPos)->SetKE(e);
      CalcQR();
      CalcQUR();
    }
  else
    G4cout<<" Number of defined charge states ="<<NQ<<" is too small"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::CalcQR()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  G4double sum;
  vector<Charge_State*>::iterator itPos = Q.begin();

  sum=0.;
  for(; itPos < Q.end(); itPos++)
    sum+=(*itPos)->GetReactedFraction();
  //  G4cout<<" Sum = "<<sum<<G4endl;
  itPos = Q.begin();
  G4int ind=0,i,max,n=0;
  for(; itPos < Q.end(); itPos++)
    { 
  
      max=(G4int)(1000.*(*itPos)->GetReactedFraction()/sum);
      //      G4cout<<" Sum = "<<sum<<" Max = "<<max<<" n "<<n<<G4endl;
      for(i=0;i<max;i++) 
		  {
			 QR[ind]=(*itPos)->GetSetKE();
			 QRI[ind]=n;
			 ind++;
		  }
      n++;
    }

}
//---------------------------------------------------------
void Outgoing_Beam::CalcQUR()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  G4double sum;
  vector<Charge_State*>::iterator itPos = Q.begin();

  sum=0.;
  for(; itPos < Q.end(); itPos++)
    sum+=(*itPos)->GetUnReactedFraction();

  itPos = Q.begin();
  G4int ind=0,i,max,n=0;
  for(; itPos < Q.end(); itPos++)
    { 
      max=(G4int)(1000.*(*itPos)->GetUnReactedFraction()/sum);
      //      G4cout<<" Sum = "<<sum<<" Max = "<<max<<" n "<<n<<" ind "<<ind<<G4endl;
      for(i=0;i<max;i++) 
		  {
			 QUR[ind]=(*itPos)->GetSetKE();
			 QURI[ind]=n;
			 ind++;
		  }
      n++;
    }
}
//---------------------------------------------------------
G4double Outgoing_Beam::GetURsetKE()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  G4int i;

  i=(G4int)(1000.*G4UniformRand());
  Index=QURI[i];
  return QUR[i];
}
//---------------------------------------------------------
G4double Outgoing_Beam::GetRsetKE()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  G4int i;

  i=(G4int)(1000.*G4UniformRand());
  Index=QRI[i];
  return QR[i];
}
//---------------------------------------------------------
void Outgoing_Beam::SetdpFWHM(G4double z)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  if(z == 0) {
	 G4cerr << "\t\033[1m\033[31m------------------------------------------------------------  \033[0m" << G4endl;
	 G4cerr << "\t\033[1m\033[31m ERROR in the macro file : \033[0m" << G4endl;
	 G4cerr << "\t\033[1m\033[31m------------------------------------------------------------ \033[0m" << G4endl;
	 G4cerr << "\t FWHM for momentum distribution of the knocked-out nucleon should be greater that zero " << G4endl;
	 G4cerr << "\t Use the command /BeamOut/dpFWHM  XXX  MeV where XXX stands for the width!" << G4endl;
	 exit(-1);
  }

  dp_sigma=z/2.35482;
  G4cout<<"----> FWHM for momentum distribution of the knocked-out nucleon set to "<<dp_sigma*2.35482/MeV<<" MeV/c"<<G4endl; 

}
//---------------------------------------------------------
//TM added 6/25/2018
void Outgoing_Beam::SetdpFWHMR(G4double z)
{
  #ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
  #endif

  dp_sigmaR=z/2.35482;
  
  
  G4cout<<"----> FWHM for momentum distribution on the degrader of the knocked-out nucleon on degrader set to "<<dp_sigmaR*2.35482/MeV<<" MeV/c"<<G4endl;
}

//---------------------------------------------------------
void Outgoing_Beam::Setdp(G4double z)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  dp_cent=z;

  G4cout<<"----> Centroid for the momentum distribution of the knocked-out nucleon set to "<<dp_cent/MeV<<" MeV/c"<<G4endl; 

}
//---------------------------------------------------------
//TM added 6/25/2018
void Outgoing_Beam::SetdpR(G4double z)
{
  #ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
  #endif

  dp_centR=z;
  

  G4cout<<"----> Centroid for the momentum distribution on the degrader of the knocked-out nucleon set to "<<dp_centR/MeV<<" MeV/c"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::Setdpf(G4double z)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  dp_frac=z;

  G4cout<<"----> Outgoing beam velocity set to "<<dp_frac<<" of the incoming beam velocity"<<G4endl; 

}
//---------------------------------------------------------
//TM added 6/25/2018
void Outgoing_Beam::SetdpfR(G4double z)
{
  #ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
  #endif

  dp_fracR=z;
  
  G4cout<<"----> Outgoing beam velocity on degrader set to "<<dp_fracR<<" of the incoming beam velocity"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::SetUpEnergyStates()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  vector<Energy_Level*>::iterator itPos = State.begin();
  // clear all elements from the array
  for(; itPos < State.end(); itPos++)
    delete *itPos;    // free the element from memory
  // finally, clear all elements from the array
  State.clear();

  for(G4int i=0;i<NS;i++) 
    State.push_back(new Energy_Level);

}
//---------------------------------------------------------
void Outgoing_Beam::SetStateEx(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SL>=0&&SL<NS)
    {
      vector<Energy_Level*>::iterator itPos = State.begin();

      for(G4int i=0;i<SL;i++) itPos++;
      (*itPos)->SetEx(x);
    }
  else{
    G4cout<<" Number of defined energy states ="<<NS<<" is too small"<<G4endl;
	 exit(EXIT_FAILURE);
  }
  
}
//---------------------------------------------------------
void Outgoing_Beam::SetStateEg(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SL>=0&&SL<NS)
    {
      vector<Energy_Level*>::iterator itPos = State.begin();

      for(G4int i=0;i<SL;i++) itPos++;
      (*itPos)->SetEg(x);
    }
  else{
    G4cout<<" Number of defined energy states ="<<NS<<" is too small"<<G4endl; 
	 exit(EXIT_FAILURE);
  }
  
}
//---------------------------------------------------------
void Outgoing_Beam::SetStateTau(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SL>=0&&SL<NS)
    {
      vector<Energy_Level*>::iterator itPos = State.begin();

      for(G4int i=0;i<SL;i++) itPos++;
		  (*itPos)->SetTau(x);
		
    }
  else{
    G4cout<<" Number of defined energy states ="<<NS<<" is too small"<<G4endl;
	 exit(EXIT_FAILURE);
  }
}
//---------------------------------------------------------
void Outgoing_Beam::SetStateFrac(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SL>=0&&SL<NS)
    {
      vector<Energy_Level*>::iterator itPos = State.begin();

      for(G4int i=0;i<SL;i++) itPos++;
      (*itPos)->SetFrac(x);
    }
  else
    G4cout<<" Number of defined energy states ="<<NS<<" is too small"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::ReportEnergyStates()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  vector<Energy_Level*>::iterator itPos = State.begin();

  for(; itPos < State.end(); itPos++)
    (*itPos)->Report();
}
/*----------------------------------------------------------------*/
void Outgoing_Beam::setDecayProperties()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  G4int ind=0,id=0;
  G4int Zi,Ai;

  //  printf(" Setting Decay Properties\n");
  if (beamIn == NULL) {
    G4cerr << "Can not set decay properties as incoming beam has not been set" << G4endl;
    exit(EXIT_FAILURE);
  }
  Zin = beamIn->getZ();
  Ain = beamIn->getA();
  Zi=Zin+DZ;
  Ai=Ain+DA;

  memset(LevelMap,0,sizeof(LevelMap));
 

  vector<G4ParticleDefinition*>::iterator sPos = NewIon.begin();
  NewIon.clear();

 
  NewIon.push_back(G4ParticleTable::GetParticleTable()->GetIon(Zi,Ai,0.*MeV));
  vector<Energy_Level*>::iterator itPos = State.begin();

  for(; itPos < State.end(); itPos++){
	 NewIon.push_back(G4ParticleTable::GetParticleTable()->GetIon(Zi,Ai,(*itPos)->GetEx()));
	 
  }

  itPos=State.begin();
  sPos=NewIon.begin();

  id=1;
  for(; itPos < State.end(); itPos++)
    {						
		sPos++; // Skip Ground state AL ---> Shhold be changed very messy coding
      if ((*sPos) == NULL) 
		  {
			 G4cerr << "Could not find outgoing ion in particle table "
					  << Zi << " " << Ai << G4endl;
			 exit(EXIT_FAILURE);
		  }
#ifdef DEBUG
		G4cout << "\n--------------------------------------------------------------------- \n Constructing decay properties for Z=" ;
		G4cout << Zi  << " A=" << Ai << " with excitation " << (*itPos)->GetEx()/keV  ;
		G4cout << " keV\n----------------------------------------------------------------------" << G4endl;
#endif
		
      if((*itPos)->GetEg()!=0)
		  {
			 G4DecayTable *DecTab = (*sPos)->GetDecayTable(); 
			 if (DecTab == NULL)	
				{
				  DecTab = new G4DecayTable();
				  GammaDecayChannel *GamDec = new GammaDecayChannel(-1,*sPos,1,(*itPos)->GetEg(),(*itPos)->GetEx()-(*itPos)->GetEg());
				  GamDec->SetHLThreshold(1e-15*second);
				  DecTab->Insert(GamDec);	      
				  (*sPos)->SetDecayTable(DecTab);
				}
			 
#ifdef DEBUG
			 G4cout << "------------>>>>> Dump Decay Table " << G4endl ;
			 DecTab->DumpInfo();
#endif
			 (*sPos)->SetPDGStable(false);
			 (*sPos)->SetPDGLifeTime((*itPos)->GetTau());
			 

#ifdef DEBUG
			 G4cout << "Lifetime " << (*itPos)->GetTau()/ns << " nsec" << endl ;
			 // make sure that the ion has the decay process in its manager
			 cout << "------------>>>>>> Dump Table " << endl << endl;
			 (*sPos)->DumpTable();
#endif

			 G4ProcessManager *pm = (*sPos)->GetProcessManager();
			 if (pm == NULL) 
				{
				  G4cerr << "Could not find process manager for outgoing ion." << G4endl;
				  exit(EXIT_FAILURE);
				}
			 //	 if (pm->GetProcessActivation(&decay) == false) 
			 {
				
				//				G4cout << "--------------Addprocess-------------" << endl ;
				pm->AddProcess(&decay,0,-1,5);
			 }
			 
#ifdef DEBUG
			 G4cout << "Lifetime " << (*itPos)->GetTau()/ns << " nsec" << endl ;
				
			 pm->DumpInfo();
#endif
		  }
      else {
		  (*sPos)->SetPDGStable(true);
		}
                    	  
 
      for(G4int i=0; i<(G4int)rint(10.*(*itPos)->GetFrac());i++)
		  {
			 if(ind<1000)
				{
				  LevelMap[ind]=id;
				  ind++;
				}
			 else
				{
				  printf(" Error in the setup of decay properties\n");
				  printf(" Direct feeding fractions add up to more then 100%%\n");
				  printf(" Fix your settings\n Aborting now\n");
				  exit(-1);
				}
		  }
   
      id++;
    }


//    for(int i=0;i<100;i++)
//       {
//         printf(" %3d   ",i);
//         for(int j=0;j<10;j++) printf(" %2d ",LevelMap[i*10+j]);
//         printf("\n");
//       }
//    getc(stdin);
}
////////////// BACKGROUND //////////////////
void Outgoing_Beam::SetUpBackgroundStates()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  vector<EnergyBackground_Level*>::iterator itPos = Background.begin();
  // clear all elements from the array
  for(; itPos < Background.end(); itPos++)
    delete *itPos;    // free the element from memory
  // finally, clear all elements from the array
  Background.clear();

  for(G4int i=0;i<NSb;i++) 
    Background.push_back(new EnergyBackground_Level);

}
//---------------------------------------------------------
void Outgoing_Beam::SetBackgroundEx(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SLb>=0&&SLb<NSb)
    {
      vector<EnergyBackground_Level*>::iterator itPos = Background.begin();

      for(G4int i=0;i<SLb;i++) itPos++;
      (*itPos)->SetExb(x);
    }
  else{
    G4cout<<" Number of defined energy background ="<<NSb<<" is too small"<<G4endl;
	 exit(EXIT_FAILURE);
  }
  
}
//---------------------------------------------------------
void Outgoing_Beam::SetBackgroundEg(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SLb>=0&&SLb<NSb)
    {
      vector<EnergyBackground_Level*>::iterator itPos = Background.begin();

      for(G4int i=0;i<SLb;i++) itPos++;
      (*itPos)->SetEb(x);
    }
  else{
    G4cout<<" Number of defined energy background ="<<NSb<<" is too small"<<G4endl; 
	 exit(EXIT_FAILURE);
  }
  
}

//---------------------------------------------------------
void Outgoing_Beam::SetBackgroundFrac(G4double x)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  if(SLb>=0&&SLb<NSb)
    {
      vector<EnergyBackground_Level*>::iterator itPos = Background.begin();

      for(G4int i=0;i<SLb;i++) itPos++;
      (*itPos)->SetFracb(x);
    }
  else
    G4cout<<" Number of defined energy background ="<<NSb<<" is too small"<<G4endl;
}
//---------------------------------------------------------
void Outgoing_Beam::ReportBackgroundStates()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  vector<EnergyBackground_Level*>::iterator itPos = Background.begin();

  for(; itPos < Background.end(); itPos++)
    (*itPos)->ReportBackground();
}
/*----------------------------------------------------------------*/
