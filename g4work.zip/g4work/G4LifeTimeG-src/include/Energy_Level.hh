#ifndef Energy_Level_h
#define Energy_Level_h 1

#include "globals.hh"
#include "G4UnitsTable.hh"

class Energy_Level
{
public:
  Energy_Level();
  ~Energy_Level();
  void  SetEx(G4double x){Ex=x;}
  void  SetEg(G4double x){Eg=x;}
  void  SetTau(G4double x){tau=x;}
  void  SetFrac(G4double x){frac=x;}
  void  Report();
  G4double GetEx(){return Ex;}
  G4double GetEg(){return Eg;}
  G4double GetTau(){return tau;}
  G4double GetFrac(){return frac;}

private:
  G4double Ex;
  G4double Eg;
  G4double tau;
  G4double frac;
 
};
#endif


           
