#ifndef Plunger_H
#define Plunger_H 1

#include "G4RunManager.hh"
#include "G4Material.hh"
#include "Materials.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"
#include "G4UnitsTable.hh"
#include "G4UserLimits.hh"

class Plunger
{
public:

  G4LogicalVolume *expHall_log;

  Plunger(G4LogicalVolume*,Materials*,G4int,G4bool);
  ~Plunger();
  
  void Construct();
  void SetDegX(G4double);
  void SetDegY(G4double);
  void SetDegZ(G4double);
  void SetNstepDeg(G4int);
  void SetDegMaterial(G4String);
  void ScaleDegDensity(G4double);
  void SetTarX(G4double);
  void SetTarY(G4double);
  void SetTarZ(G4double);
  void SetNstepTar(G4int);
  void SetTarMaterial(G4String);
  void ScaleTarDensity(G4double);
  void SetStoX(G4double);
  void SetStoY(G4double);
  void SetStoZ(G4double);
  void SetNstepSto(G4int);
  void SetStoMaterial(G4String);
  void ScaleStoDensity(G4double);
  void SetRatio(G4double);
  void SetRatio2(G4double);
  void SetPosZ(G4double);
  void SetSeparation(G4double);
  void SetSeparation2(G4double);
  void Report();
  G4LogicalVolume* GetDegraderLog(){return Degrader_log;}
  G4Box* GetDegrader(){return aDegrader;}
  G4VPhysicalVolume* GetDegraderPlacement(){return Degrader_phys;}

  G4LogicalVolume* GetTargetLog(){return Target_log;}
  G4Box* GetTarget(){return aTarget;}
  G4VPhysicalVolume* GetTargetPlacement(){return Target_phys;}

  G4LogicalVolume* GetStopperLog(){return Stopper_log;}
  G4Box* GetStopper(){return aStopper;}
  G4VPhysicalVolume* GetStopperPlacement(){return Stopper_phys;}

  void setTargetReactionDepth(G4double);
  void setDegraderReactionDepth(G4double);
  void setStopperReactionDepth(G4double);
  G4double GetRRatio(){return RR;}
  G4double GetRRatio2(){return RR2;}
  
  inline G4double GetRatioT()                { return Ratio; }
  inline G4double GetRatioD()                { return Ratio2; }  
  
  inline G4double GetTargetThickness()       { return    Target_thickness; }
  inline G4double GetDegraderThickness()     { return    Degrader_thickness; }
  inline G4double GetStopperThickness()      { return    Stopper_thickness; }    
  inline G4double GetTarScaleDensity()       { return    TargetScaleDensity; }
  inline G4double GetDegScaleDensity()       { return    DegraderScaleDensity; }
  inline G4double GetStopScaleDensity()      { return    StopperScaleDensity; }    
  inline G4double GetDistance1()             { return    D; }
  inline G4double GetDistance2()             { return    D2; }  

  //! Sets Plunger type
  void SetPlungerType(G4int n) {PlungerType = n;};
  //! Sets Plunger type
  G4int GetPlungerType() {return PlungerType;};

  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  void SetAddShield(G4bool);
  void SetShMaterial(G4String);
  void SetShPos(G4double);
  void SetShRmin(G4double);
  void SetShRmax(G4double);
  void SetShLen(G4double);

 
private:
  
  // dimensions
  G4double Degrader_side_x;
  G4double Degrader_side_y;
  G4double Degrader_thickness;
  G4int NstepDeg;

  G4double Target_side_x;
  G4double Target_side_y;
  G4double Target_thickness;
  G4int NstepTar;

  G4double Stopper_side_x;
  G4double Stopper_side_y;
  G4double Stopper_thickness;
  G4int NstepSto;

  //materials
  Materials* materials;
  G4Material* DegraderMaterial;
  G4Material* TargetMaterial;
  G4Material* StopperMaterial;
  G4Material* Shield_material; //AR v4.3

  //default position
  G4RotationMatrix NoRot;
  G4ThreeVector *Pos;
  G4double      D;
  G4double      D2;
  G4double      sep;    

  //the stuff
  G4Box* aDegrader;
  G4Box* aTarget;
  G4Box* aStopper;   

  //logical volume
  G4LogicalVolume* Degrader_log;
  G4LogicalVolume* Target_log;
  G4LogicalVolume* Stopper_log;
  G4LogicalVolume* Shield_log; //AR v4.3
  
  //physical volume
  G4VPhysicalVolume* Degrader_phys;
  G4VPhysicalVolume* Target_phys;
  G4VPhysicalVolume* Stopper_phys;
  G4VPhysicalVolume* Shield_phys; //AR v4.3

  //tubs AR v4.3
  G4Tubs* aShieldCy;
  
  //reaction stuff
  G4double Ratio;
  G4double RR;
  G4double Ratio2;
  G4double RR2;
  G4UserLimits *degrader_limits;
  G4UserLimits *target_limits;
  G4UserLimits *stopper_limits;

  //! Plunger Type
  G4int PlungerType;
  
  G4double     TargetScaleDensity;
  G4double     DegraderScaleDensity;
  G4double     StopperScaleDensity;
  G4double     StripperScaleDensity;

  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  G4bool Shield_Flag;
  G4double Shield_start;
  G4double Shield_rmin;
  G4double Shield_rmax;
  G4double Shield_len;
  G4ThreeVector *Shield_pos;
};

#endif

