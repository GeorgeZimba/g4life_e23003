#ifndef Gretina_Array_Messenger_h
#define Gretina_Array_Messenger_h 1

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWith3Vector.hh"
#include "G4UIcmdWithAnInteger.hh"
#include "G4UIcmdWithABool.hh"

#include "Gretina_Array.hh"


class Gretina_Array_Messenger: public G4UImessenger
{

public: 
  Gretina_Array_Messenger(Gretina_Array*);
  ~Gretina_Array_Messenger();

private:
  Gretina_Array*        myTarget;
    
private:
  G4UIcmdWithAString*        SetSolidCmd;
  G4UIcmdWithAString*        SetAngleCmd;
  G4UIcmdWithAString*        SetWallsCmd;
  G4UIcmdWithAString*        SetClustCmd;
  G4UIcmdWithAString*        DetMatCmd;
  G4UIcmdWithAString*        WalMatCmd;
  G4UIcmdWithAString*        RotateArrayCmd;
  G4UIcmdWithADouble*        RotatePrismaCmd;
  G4UIcmdWith3Vector*        TranslateArrayCmd;
  G4UIcmdWithABool*          EnableCylCmd;
  G4UIcmdWithABool*          DisableCylCmd;
  G4UIcmdWithABool*          DontDrawReadOutCmd;
  G4UIcmdWithABool*          DrawReadOutCmd;
  G4UIcmdWithABool*          EnableCapsulesCmd;
  G4UIcmdWithABool*          DisableCapsulesCmd;                      
  G4UIcmdWithAnInteger*      SetStepCmd;
  G4UIcmdWithoutParameter*   cryostatCmd;



////////////////////////////////////////////////////////////////////////////////////
//                  Public methods for the messenger                              //
////////////////////////////////////////////////////////////////////////////////////


public:
  void SetNewValue(G4UIcommand*, G4String);





};





#endif
