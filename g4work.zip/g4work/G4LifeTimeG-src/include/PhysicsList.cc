#include "PhysicsList.hh"

PhysicsList::PhysicsList()
{
  BeamOut = NULL;
}

PhysicsList::PhysicsList(Outgoing_Beam* BO):BeamOut(BO)
{;}

PhysicsList::~PhysicsList()
{;}

void PhysicsList::ConstructParticle()
{
  // In this method, static member functions should be called
  // for all particles which you want to use.
  // This ensures that objects of these particle types will be
  // created in the program. 

  G4Gamma::GammaDefinition();
  G4Electron::ElectronDefinition();
  G4Positron::PositronDefinition();

  //  ions
  G4IonConstructor iConstructor;
  iConstructor.ConstructParticle();

  
  
}

void PhysicsList::ConstructProcess()
{
  // Define transportation process

  AddTransportation();
  ConstructEM();
}

void PhysicsList::ConstructEM()
{
  theParticleIterator->reset();
  
  
  while( (*theParticleIterator)() ){
	 
    G4ParticleDefinition* particle = theParticleIterator->value();
    G4ProcessManager* pmanager = particle->GetProcessManager();
    G4String particleName = particle->GetParticleName();
 

    //  G4cout<<"++++ Particle name ="<<particleName<<G4endl;
    if (particleName == "gamma") {
		// Standard EM 
      pmanager->AddDiscreteProcess(new G4PhotoElectricEffect());
      pmanager->AddDiscreteProcess(new G4ComptonScattering());
      pmanager->AddDiscreteProcess(new G4GammaConversion());
		// Variation for Low Energy Processes
//      	pmanager->AddDiscreteProcess(new G4LowEnergyRayleigh());
//      	pmanager->AddDiscreteProcess(new G4LowEnergyPhotoElectric);
//      	pmanager->AddDiscreteProcess(new G4LowEnergyCompton);
//      	pmanager->AddDiscreteProcess(new G4LowEnergyGammaConversion);
		// Variation for Low Energy Penelope
// 		pmanager->AddDiscreteProcess(new G4PenelopeCompton);
// 		pmanager->AddDiscreteProcess(new G4PenelopeGammaConversion);
// 		pmanager->AddDiscreteProcess(new G4PenelopePhotoElectric);
// 		pmanager->AddDiscreteProcess(new G4PenelopeRayleigh); 		

/*               //--- High precision gammaray interation physics.  This physics was used for e12015 C17 analysis. Important for low energies.
   		//--- from G4examples advanced gammaray_telescope/src/GammaRayTelEMlowePhysics.cc
		pmanager = G4Gamma::Gamma()->GetProcessManager();
		
		G4RayleighScattering *theRayleigh = new G4RayleighScattering();
		theRayleigh->SetModel( new G4LivermoreRayleighModel() );
		
		G4PhotoElectricEffect *thePhotoElectricEffect = new G4PhotoElectricEffect();
		thePhotoElectricEffect->SetModel( new G4LivermorePhotoElectricModel() );
		
		G4ComptonScattering *theComptonScattering = new G4ComptonScattering();
		theComptonScattering->SetModel( new G4LivermoreComptonModel() );
		
		G4GammaConversion *theGammaConversion = new G4GammaConversion();
		theGammaConversion->SetModel( new G4LivermoreGammaConversionModel() );
		
		pmanager->AddDiscreteProcess( theRayleigh );
		pmanager->AddDiscreteProcess( thePhotoElectricEffect );
		pmanager->AddDiscreteProcess( theComptonScattering );
		pmanager->AddDiscreteProcess( theGammaConversion );	*/	
		
    }
    else if (particleName == "e-") {
		pmanager->AddProcess(new G4eMultipleScattering,-1,1,1);
		pmanager->AddProcess(new G4eIonisation,       -1,2,2);
		pmanager->AddProcess(new G4eBremsstrahlung,   -1,3,3);     
    }
    else if (particleName == "e+") {

		pmanager->AddProcess(new G4eMultipleScattering,-1,1,1);
		pmanager->AddProcess(new G4eIonisation,       -1,2,2);
		pmanager->AddProcess(new G4eBremsstrahlung,   -1,3,3);     
		pmanager->AddProcess(new G4eplusAnnihilation,  0,-1,4); 
    }
    else if(particleName == "GenericIon") 
		{
		  G4hMultipleScattering* aMultipleScattering = new G4hMultipleScattering();
		  pmanager->AddProcess(aMultipleScattering,-1,1,1);
		  G4ionIonisation* aIon = new G4ionIonisation();
		  G4IonParametrisedLossModel* ionModel = new G4IonParametrisedLossModel();
  		  aIon ->SetEmModel(ionModel);
		  pmanager->AddProcess(aIon,        -1,2, 2);
		  pmanager->AddProcess(new G4StepLimiter,        -1,-1, 4);
		  pmanager->AddProcess(new Reaction(BeamOut),    -1,-1, 3);
		  pmanager->AddProcess(new G4Decay,    -1,-1, 5);
		
    }
  }

}
 

void PhysicsList::SetCuts()
{
  // uppress error messages even in case e/gamma/proton do not exist            
  G4int temp = GetVerboseLevel();                                                
  SetVerboseLevel(0);                                                           
  //  " G4VUserPhysicsList::SetCutsWithDefault" method sets 
  //   the default cut value for all particle types 
  SetCutsWithDefault();   

  // Retrieve verbose level
  SetVerboseLevel(temp);  
}

