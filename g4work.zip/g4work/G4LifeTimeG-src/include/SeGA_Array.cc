#include "SeGA_Array.hh"


SeGA_Array::SeGA_Array(G4LogicalVolume* experimentalHall_log)
{
  expHall_log=experimentalHall_log;
  GeomFileName = "./Geometry/SeGA_Barrel.dat";
}

SeGA_Array::~SeGA_Array()
{
}
//--------------------------------------------------------------------
void SeGA_Array::Construct(G4String FileName)
{
  G4int i;
  GeomFileName = FileName;

  vector<SeGA_Ring*>::iterator itPos = the_Plunger_SeGA.begin();
  // clear all elements from the array
  for(; itPos < the_Plunger_SeGA.end(); itPos++)
    delete *itPos;    // free the element from memory
  // finally, clear all elements from the array
  the_Plunger_SeGA.clear();

  for(i=0;i<2;i++) the_Plunger_SeGA.push_back(new SeGA_Ring(expHall_log));     

  itPos = the_Plunger_SeGA.begin();
  (*itPos)->Construct(1,GeomFileName);
  
  itPos++;
  (*itPos)->Construct(2,GeomFileName);
  


}
//--------------------------------------------------------------------
void SeGA_Array::MakeSensitive(TrackerGammaSD* TrackerGamma)
{

 vector<SeGA_Ring*>::iterator itPos = the_Plunger_SeGA.begin();

 for(;itPos<the_Plunger_SeGA.end();itPos++)  
   (*itPos)->MakeSensitive(TrackerGamma);

}
//--------------------------------------------------------------------
void SeGA_Array::DopplerOn()
{

 vector<SeGA_Ring*>::iterator itPos = the_Plunger_SeGA.begin();

 for(;itPos<the_Plunger_SeGA.end();itPos++)  
   (*itPos)->DopplerOn();

}
//--------------------------------------------------------------------
void SeGA_Array::DopplerOff()
{

 vector<SeGA_Ring*>::iterator itPos = the_Plunger_SeGA.begin();

 for(;itPos<the_Plunger_SeGA.end();itPos++)  
   (*itPos)->DopplerOff();

}
//--------------------------------------------------------------------
void SeGA_Array::CalcSegCenters(G4ThreeVector DoppPos)
{

 vector<SeGA_Ring*>::iterator itPos = the_Plunger_SeGA.begin();

 for(;itPos<the_Plunger_SeGA.end();itPos++)  
   (*itPos)->CalcSegCenters(DoppPos);

}
//--------------------------------------------------------------------
SeGA_Ring* SeGA_Array::GetRing(G4int ring)

{

 vector<SeGA_Ring*>::iterator itPos = the_Plunger_SeGA.begin();

 return (*(itPos+ring-1));

}
//--------------------------------------------------------------------
void SeGA_Array::ReportSegments()
{

 vector<SeGA_Ring*>::iterator itPos = the_Plunger_SeGA.begin();

 for(;itPos<the_Plunger_SeGA.end();itPos++)  
   {
     G4cout<<" Ring # "<<(*itPos)->GetRingID()<<G4endl;
     (*itPos)->ReportSegments();
   }

}
//--------------------------------------------------------------------
void SeGA_Array::Report()
{

}
