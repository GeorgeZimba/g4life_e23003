#include "TrackerGammaHit.hh"
#include "G4UnitsTable.hh"
#include "G4VVisManager.hh"
#include "G4Circle.hh"
#include "G4Colour.hh"
#include "G4VisAttributes.hh"

G4Allocator<TrackerGammaHit> TrackerGammaHitAllocator;


TrackerGammaHit::TrackerGammaHit() {}



TrackerGammaHit::~TrackerGammaHit() {}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

TrackerGammaHit::TrackerGammaHit(const TrackerGammaHit& right)
  : G4VHit()
{
  trackID   = right.trackID;
  ptrackID   = right.ptrackID;
  particleID= right.particleID;
  sliceNbi  = right.sliceNbi;
  quartNbi  = right.quartNbi;
  sliceNbf  = right.sliceNbf;
  quartNbf  = right.quartNbf;
  edep      = right.edep;
  pos       = right.pos;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

const TrackerGammaHit& TrackerGammaHit::operator=(const TrackerGammaHit& right)
{
  trackID   = right.trackID;
  ptrackID   = right.ptrackID;
  particleID= right.particleID;
  sliceNbi  = right.sliceNbi;
  quartNbi  = right.quartNbi;
  sliceNbf  = right.sliceNbf;
  quartNbf  = right.quartNbf;
  edep      = right.edep;
  pos       = right.pos;
  return *this;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4int TrackerGammaHit::operator==(const TrackerGammaHit& right) const
{
  return (this==&right) ? 1 : 0;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void TrackerGammaHit::Draw()
{
  G4VVisManager* pVVisManager = G4VVisManager::GetConcreteInstance();
  if(pVVisManager)
  {
    G4Circle circle(pos);
    circle.SetScreenSize(4);
    circle.SetFillStyle(G4Circle::filled);
    G4Colour colour(1.,1.,0.);
    G4VisAttributes attribs(colour);
    circle.SetVisAttributes(attribs);
    pVVisManager->Draw(circle);
  }
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void TrackerGammaHit::Print()
{
  G4cout << "  trackID: " << trackID << "  particle: "<< particleID 
			<< "  Par. trackID: "<< ptrackID << G4endl;
  G4cout << " \t\t  ringID:  " << ringID << "  det_Numb:" << detNumb
         << "  slice_i: " << sliceNbi
	 << "  quarter_i: " << quartNbi
         << "  slice_f: " << sliceNbf
	 << "  quarter_f: " << quartNbf
         << "  energy deposit: " << G4BestUnit(edep,"Energy")
	 << "  position: " << G4BestUnit(pos,"Length") << G4endl;
  
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

