#ifndef PrimaryGeneratorAction_Messenger_h
#define PrimaryGeneratorAction_Messenger_h 1

#include "PrimaryGeneratorAction.hh"
#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithAnInteger.hh"


class PrimaryGeneratorAction_Messenger: public G4UImessenger
{
public:
  PrimaryGeneratorAction_Messenger(PrimaryGeneratorAction*);
  ~PrimaryGeneratorAction_Messenger();
    
  void SetNewValue(G4UIcommand*, G4String);
    
private:
  PrimaryGeneratorAction*    PGA;    
  G4UIdirectory*             PGADir;
  G4UIdirectory*             SrcDir;
  G4UIdirectory*             RctDir;
  G4UIcmdWithADoubleAndUnit*   SrcXCmd;
  G4UIcmdWithADoubleAndUnit*   SrcYCmd;
  G4UIcmdWithADoubleAndUnit*   SrcZCmd;
  G4UIcmdWithADoubleAndUnit*   PGASCmd;
  G4UIcmdWithoutParameter*   PGASEUCmd;
  G4UIcmdWithoutParameter*   PGABCmd;
  G4UIcmdWithoutParameter*   SrcTFCmd;
  G4UIcmdWithoutParameter*   SrcTBCmd;
  G4UIcmdWithoutParameter*   SrcDFCmd;
  G4UIcmdWithoutParameter*   SrcDBCmd;
  G4UIcmdWithoutParameter*   SrcSFCmd;
  G4UIcmdWithoutParameter*   SrcSBCmd;        
  G4UIcmdWithoutParameter*   SrcRCmd;
  G4UIcmdWithoutParameter*   ROnCmd;
  G4UIcmdWithoutParameter*   ROfCmd;
  G4UIcmdWithADouble*        SFrCmd;
  //AR New in v4.3 -> To reproduce unusual DTA distributions if needed
  G4UIcmdWithADouble*        DTASlopeCmd;
  G4UIcmdWithADouble*        DTAOffsetCmd;
  G4UIcmdWithADouble*        DTASigmaCmd;
  G4UIcmdWithADouble*        DTAMeanCmd;
  
};


#endif

