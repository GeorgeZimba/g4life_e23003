#ifndef EventAction_h
#define EventAction_h 1

#include "G4UserEventAction.hh"
#include "G4Event.hh"
#include "G4TrajectoryContainer.hh"
#include "G4Trajectory.hh"
#include "G4ios.hh"
#include "globals.hh"
#include "G4UnitsTable.hh"
#include "Analysis.hh"


class EventAction : public G4UserEventAction
{
  public:
  EventAction(Analysis*);
   ~EventAction();

    void BeginOfEventAction(const G4Event*);
    void EndOfEventAction(const G4Event*);

  private:
  Analysis* Ana;
  
};

#endif //EVENTACTION_H

    
