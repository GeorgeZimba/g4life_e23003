#include "RunAction.hh"
 
RunAction::RunAction(DetectorConstruction* detector, Outgoing_Beam* BO,Analysis* A): myDetector(detector), BeamOut(BO),Ana(A)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  
  
}


RunAction::~RunAction()
{

}

void RunAction::BeginOfRunAction(const G4Run* aRun)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  // Setup Analysis
  Ana->BeginOfRun(aRun);
  
#ifdef DEBUG
  G4cout<<" Beginin of run "<<G4endl;
  if(BeamOut->ReactionOn()) 
	 G4cout<<" Simulating scattered ions "<<G4endl;
  else
	 G4cout<<" Simulating unscattered ions "<<G4endl;
#endif  

/*	// New in v4.2. This part is changing randomization. Creates new random number for every simulation run.
	//--- set automatic (time-based) random seeds for each run
	long seeds[2];
	time_t systime = time(NULL);
	seeds[0] = (long) systime;
	seeds[1] = (long) (systime*G4UniformRand());
	CLHEP::HepRandom::setTheSeeds(seeds);
	CLHEP::HepRandom::showEngineStatus(); */

  if(myDetector->IsDefinedSeGA()) myDetector->GetSeGA()->CalcSegCenters(BeamOut->GetPosDopp());
}



void RunAction::EndOfRunAction(const G4Run* aRun)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  // Close Analysis 
  Ana->EndOfRun(aRun);
  
#ifdef DEBUG
  G4cout<<G4endl;
  G4cout<<" End of Run"<<G4endl;
#endif  
  
}

