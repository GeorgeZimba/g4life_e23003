
#ifndef SeGA_Detector_H
#define SeGA_Detector_H 1



#include "G4Material.hh"
#include "G4Tubs.hh"
#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4ThreeVector.hh"
#include "G4PVPlacement.hh"
#include "G4PVReplica.hh"
#include "G4PVDivision.hh"


#include "G4VisAttributes.hh"
#include "G4Colour.hh"
#include "G4SubtractionSolid.hh"

#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"
#include "Randomize.hh"
#include "globals.hh"
#include <iostream>
#include <iomanip>

using namespace std;

class SeGA_Detector 
{
  public:

  G4LogicalVolume *expHall_log;
  

    SeGA_Detector(G4LogicalVolume*);
    ~SeGA_Detector();

  

  G4VPhysicalVolume *Construct(G4int,G4int,G4int,G4double,G4double,G4double,G4double,G4double);
  G4LogicalVolume* GetCellLog(){return detectorcell_log;};
  G4double GetSegCosTheta(G4int i, G4int j){return cosSeg[i][j];}
  G4double FWHM_response(G4double);
  G4double Efficiency(G4double);
  G4bool   Efficiency_response(G4double);
  void    ReportSegments();
  void    SaveSegments(G4String);
  void    setF(G4double x){F=x;};
  void    setG(G4double x){G=x;};
  void    setH(G4double x){H=x;};
  void    CalcSegCenters(G4ThreeVector);
  void    setZShift(G4double z){ZShift.setZ(z);};
  void    PlaceDetector();
  void    setThrCent(G4double z){thr_center=z;}
  void    setThrWidth(G4double z){thr_width=z;}
  void    Report();
  void    setNumber(G4int);
  void    setRingID(G4int);
  void    setID(G4int n){NumberID=n;}
  void    setStat(G4int s){Stat=s;} //LR
  G4int   getStat(){return Stat;}   //LR
  G4double getTheta(){return thetad;} //LR
  G4double getPhi(){return phid;} //LR
  G4int   getNumber(){return Number;}
  G4int   getRingID(){return RingID;} //LR
  G4int   getID(){return NumberID;}
  G4int   getSegID(G4int s,G4int q);
  G4bool  getDoppler(){return dopplerOn;}
  void    DopplerOn(){dopplerOn=true;}
  void    DopplerOff(){dopplerOn=false;}
  G4String SetDetectorName();
  G4ThreeVector GetSegPos(G4int,G4int);
  G4ThreeVector SimulateTrackingResolution(G4ThreeVector,G4double,G4double,G4double);

  private:


  
  // Logical volumes
  //

  G4LogicalVolume* detector_log;
  G4LogicalVolume* detectorphiDivision_log;
  G4LogicalVolume* detectorcell_log; 
  G4LogicalVolume* iCan_log;   //LR
  G4LogicalVolume* oCan_log;   //LR
  //G4LogicalVolume* DL_log;     //LR
  G4LogicalVolume* iDL_log;     //LR
  G4LogicalVolume* oDL_log;     //LR
  G4LogicalVolume* preamp_log; //LR
  G4LogicalVolume* neck_log;   //LR
  G4LogicalVolume* cryo_log;       //LR
  G4LogicalVolume* cryoBase_log;   //LR
  // Physical volumes
  //
 
  G4VPhysicalVolume* detector_phys;
  G4VPhysicalVolume* detectorphiDivisionPhys;
  G4VPhysicalVolume* detectorcellPhys;
  G4VPhysicalVolume* iCan_phys;   //LR
  G4VPhysicalVolume* oCan_phys;   //LR
  //G4VPhysicalVolume* DL_phys;     //LR
  G4VPhysicalVolume* iDL_phys;     //LR
  G4VPhysicalVolume* oDL_phys;     //LR
  G4VPhysicalVolume* preamp_phys; //LR
  G4VPhysicalVolume* neck_phys;   //LR
  G4VPhysicalVolume* cryoBase_phys;   //LR
  G4VPhysicalVolume* cryo_phys;       //LR

  // Materials
  G4Material* HpGe;
  G4Material* Cu;
  G4Material* Al;            //LR
  G4Material* preampMat;     //LR

  // dimensions
  G4double Length;
  G4double innerRadius;
  G4double outerRadius;
  //G4double DLinnerRadius;   //LR
  //G4double DLouterRadius;   //LR
  G4double iDLThickness;      //LR
  G4double iDLinnerRadius;    //LR
  G4double iDLouterRadius;    //LR
  G4double oDLThickness;      //LR
  G4double oDLinnerRadius;    //LR
  G4double oDLouterRadius;    //LR
  G4double fingerRadius;
  G4double CapToCristal;
  G4double iCanThickness;     //LR
  G4double iCanInnerRadius;   //LR
  G4double iCanOuterRadius;   //LR
  G4double iCanLength;        //LR
  G4double oCanThickness;     //LR
  G4double oCanInnerRadius;   //LR
  G4double oCanOuterRadius;   //LR
  G4double oCanLength;        //LR
  G4double oCanOffset;        //LR
  G4double preampRadius;      //LR
  G4double preampLength;      //LR
  G4double neckRadius;        //LR
  G4double neckLength;        //LR
  G4double cryoThickness;     //LR
  G4double cryoOuterRadius;   //LR
  G4double cryoInnerRadius;   //LR
  G4double cryoLength;        //LR
  G4double cryoBaseThickness; //LR

  G4double startAngle;
  G4double spanningAngle;

  // position
  G4double  rd;
  G4double  zd;
  G4double  thetad;
  G4double  phid;
  G4RotationMatrix DetRot;
  G4RotationMatrix cryoRot;  //LR
  G4ThreeVector DetPos;
  G4ThreeVector ZShift;
  G4ThreeVector FingShift;
  G4ThreeVector oCanShift;      //LR
  G4ThreeVector preampShift;    //LR
  G4ThreeVector neckShift;      //LR
  G4ThreeVector neckOffset;     //LR
  G4ThreeVector cryoBaseShift;  //LR
  G4ThreeVector cryoBaseOffset; //LR
  G4ThreeVector cryoShift;      //LR
  G4ThreeVector cryoOffset;     //LR
  G4int     Number;
  G4int     NumberID;
  G4int     RingID;
  G4int     Orientation;
  G4int     Stat;             //LR

  G4Tubs* iCan;   //LR
  G4Tubs* oCanFull;         //LR
  G4Tubs* oCanHollow;       //LR
  G4SubtractionSolid* oCan; //LR
  //G4Tubs* DL;     //LR
  G4Tubs* iDL;     //LR
  G4Tubs* oDL;     //LR
  G4Tubs* preamp; //LR
  G4Tubs* neck;   //LR
  G4Tubs* cryoBase;         //LR
  G4Tubs* cryoFull;         //LR
  G4Tubs* cryoHollow;       //LR
  G4SubtractionSolid* cryo; //LR
  G4Tubs* full;
  G4Tubs* hollow;
  G4SubtractionSolid* detector;
  //segmentation
  G4VSolid* detectorcellTub;
  G4SubtractionSolid* detectorcellSub;
  G4VSolid * detectorphiDivisionTub;
  G4SubtractionSolid* detectorphiDivisionSub;
  G4double  cosSeg[8][4];
  G4double  zdopp;
  G4int i,j;
  G4bool dopplerOn;

  //FWHM
  G4double F;
  G4double G;
  G4double H;

  //efficiency
  G4double thr_center,thr_width;


  G4String detector_name;
  G4int Slice(G4int);
  G4int Quarter(G4int seg);

};

#endif

