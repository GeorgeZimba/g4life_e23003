#include "Outgoing_Beam_Messenger.hh"


Outgoing_Beam_Messenger::Outgoing_Beam_Messenger(Outgoing_Beam* BO)
 :BeamOut(BO)
{ 
 
  BeamOutDir = new G4UIdirectory("/BeamOut/");
  BeamOutDir->SetGuidance("Outgoing beam control.");

  DACmd = new G4UIcmdWithAnInteger("/BeamOut/DA",this);
  DACmd->SetGuidance("Select the mass number change for the outgoing beam.");
  DACmd->SetParameterName("choice",false);
  DACmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DZCmd = new G4UIcmdWithAnInteger("/BeamOut/DZ",this);
  DZCmd->SetGuidance("Select the atomic number change for the outgoing beam.");
  DZCmd->SetParameterName("choice",false);
  DZCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  dpCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/dp",this);
  dpCmd->SetGuidance("Set centroid for the momentum distribution of the knocked-out nucleon.");
  dpCmd->SetParameterName("choice",false);
  dpCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  //TM added 6/25/2018 for version 4.2
  dpRCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/dpR",this);
  dpRCmd->SetGuidance("Set centroid for the momentum distribution of the knocked-out nucleon.");
  dpRCmd->SetParameterName("choice", false);
  //dpRCmd->SetDefaultValue(BeamOut->Getdp());
  //dpRCmd->SetDefaultValue(BeamOut->dp_cent);
  //dpRCmd->SetDefaultUnit("MeV"); 
  dpRCmd->AvailableForStates(G4State_PreInit,G4State_Idle);  


  dpFWHMCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/dpFWHM",this);
  dpFWHMCmd->SetGuidance("Set FWHM for momentum distribution of the knocked-out nucleon.");
  dpFWHMCmd->SetParameterName("choice",false);
  dpFWHMCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  //TM added 6/25/2018 for version 4.2  
  dpFWHMRCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/dpFWHMR",this);
  dpFWHMRCmd->SetGuidance("Set FWHM for momentum distribution of the knocked-out nucleon on degrader.");
  dpFWHMRCmd->SetParameterName("choice", false);
  //dpFWHMRCmd->SetDefaultValue(BeamOut->GetdpFWHM()); 
  //dpFWHMRCmd->SetDefaultValue(BeamOut->dp_sigma); 
  //dpFWHMRCmd->SetDefaultUnit("MeV");   
  dpFWHMRCmd->AvailableForStates(G4State_PreInit,G4State_Idle);  
  
  dpfCmd = new G4UIcmdWithADouble("/BeamOut/dp_frac",this);
  dpfCmd->SetGuidance("Set fraction of the incoming beam velocity to be equal to the outgoing beam velocity.");
  dpfCmd->SetParameterName("choice",false);
  dpfCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  //TM added 6/25/2018 for version 4.2   
  dpfRCmd = new G4UIcmdWithADouble("/BeamOut/dp_fracR",this);
  dpfRCmd->SetGuidance("Set fraction of the incoming beam velocity to be equal to the outgoing beam velocity.");
  dpfRCmd->SetParameterName("choice", false);
  //dpfRCmd->SetDefaultValue(BeamOut->Getdpf());  
  //dpfRCmd->SetDefaultValue(BeamOut->dp_frac);
  dpfRCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  

  TEx1Cmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/TargetExcitation_1",this);
  TEx1Cmd->SetGuidance("Set target excitation energy 1.");
  TEx1Cmd->SetParameterName("choice",false);
  TEx1Cmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  TEx2Cmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/TargetExcitation_2",this);
  TEx2Cmd->SetGuidance("Set target excitation energy 2.");
  TEx2Cmd->SetParameterName("choice",false);
  TEx2Cmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  CExFCmd = new G4UIcmdWithADouble("/BeamOut/Target_E1_to_E2_Fraction",this);
  CExFCmd->SetGuidance("Set fraction of target energy 1 excitations as compared to the target energy 2 excitations.");
  CExFCmd->SetParameterName("choice",false);
  CExFCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  TExFCmd = new G4UIcmdWithADouble("/BeamOut/TargetExcitationFraction",this);
  TExFCmd->SetGuidance("Set fraction of target excitation as compared to the projectile excitation.");
  TExFCmd->SetParameterName("choice",false);
  TExFCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DoppbetaCmd = new G4UIcmdWithADouble("/BeamOut/Doppbeta",this);
  DoppbetaCmd->SetGuidance("Set beta for the outgoing beam.");
  DoppbetaCmd->SetParameterName("choice",false);
  DoppbetaCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DoppZCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/DoppZ",this);
  DoppZCmd->SetGuidance("Set Z position for the outgoing beam Doppler corrections.");
  DoppZCmd->SetParameterName("choice",false);
  DoppZCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DoppYCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/DoppY",this);
  DoppYCmd->SetGuidance("Set Y position for the outgoing beam Doppler corrections.");
  DoppYCmd->SetParameterName("choice",false);
  DoppYCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DoppXCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/DoppX",this);
  DoppXCmd->SetGuidance("Set X position for the outgoing beam Doppler corrections.");
  DoppXCmd->SetParameterName("choice",false);
  DoppXCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  RepCmd = new G4UIcmdWithoutParameter("/BeamOut/Report",this);
  RepCmd->SetGuidance("Report parameters for the outgoing beam.");

  QDir = new G4UIdirectory("/BeamOut/Q/");
  QDir->SetGuidance("Charge state control for the outgoing beam.");

  NQCmd = new G4UIcmdWithAnInteger("/BeamOut/Q/SetNumberOfChargeStates",this);
  NQCmd->SetGuidance("Set number of charge states for the outgoing beam.");
  NQCmd->SetParameterName("choice",false);
  NQCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  SQCmd = new G4UIcmdWithAnInteger("/BeamOut/Q/ChargeStateSelect",this);
  SQCmd->SetGuidance("Select a charge state to be setup.");
  SQCmd->SetParameterName("choice",false);
  SQCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SCCmd = new G4UIcmdWithAnInteger("/BeamOut/Q/Charge",this);
  SCCmd->SetGuidance("Set charge for the charge state to be setup.");
  SCCmd->SetParameterName("choice",false);
  SCCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  QUFCmd = new G4UIcmdWithADouble("/BeamOut/Q/UnReactedFraction",this);
  QUFCmd->SetGuidance("Set a fraction of the selected charge state in the unreacted beam");
  QUFCmd->SetParameterName("choice",false);
  QUFCmd->AvailableForStates(G4State_PreInit,G4State_Idle);  

  QRFCmd = new G4UIcmdWithADouble("/BeamOut/Q/ReactedFraction",this);
  QRFCmd->SetGuidance("Set a fraction of the selected charge state in the reacted beam");
  QRFCmd->SetParameterName("choice",false);
  QRFCmd->AvailableForStates(G4State_PreInit,G4State_Idle);  

  QKECmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/Q/KE",this);
  QKECmd->SetGuidance("Set kinetic energy of the central S800 trajectory for the selected charge state");
  QKECmd->SetParameterName("choice",false);
  QKECmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  QKEuCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/Q/KEu",this);
  QKEuCmd->SetGuidance("Set kinetic energy per nucleon of the central S800 trajectory for the selected charge state");
  QKEuCmd->SetParameterName("choice",false);
  QKEuCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SDir = new G4UIdirectory("/BeamOut/States/");
  SDir->SetGuidance("Excited state control for the outgoing beam.");

  NSCmd = new G4UIcmdWithAnInteger("/BeamOut/States/SetNumberOfEnergyStates",this);
  NSCmd->SetGuidance("Set number of energy states for the outgoing beam.");
  NSCmd->SetParameterName("choice",false);
  NSCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  LSCmd = new G4UIcmdWithAnInteger("/BeamOut/States/EnergyStateSelect",this);
  LSCmd->SetGuidance("Select an energy state to be setup.");
  LSCmd->SetParameterName("choice",false);
  LSCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SExCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/States/Ex",this);
  SExCmd->SetGuidance("Set excitation energy for the selected energy state");
  SExCmd->SetParameterName("choice",false);
  SExCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SEgCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/States/Eg",this);
  SEgCmd->SetGuidance("Set gamma-ray decay energy for the selected energy state");
  SEgCmd->SetParameterName("choice",false);
  SEgCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  STCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/States/tau",this);
  STCmd->SetGuidance("Set gamma-ray decay lifetime for the selected energy state");
  STCmd->SetParameterName("choice",false);
  STCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SFCmd = new G4UIcmdWithADouble("/BeamOut/States/frac",this);
  SFCmd->SetGuidance("Set direct population fraction for the selected energy state");
  SFCmd->SetParameterName("choice",false);
  SFCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  SRCmd = new G4UIcmdWithoutParameter("/BeamOut/States/Report",this);
  SRCmd->SetGuidance("Report parameters for energy states of the outgoing beam.");
  DPCmd = new G4UIcmdWithoutParameter("/BeamOut/SetDecayProperties",this);
  DPCmd->SetGuidance("Set decay for the outgoing beam.");
  
  //background
  SbDir = new G4UIdirectory("/BeamOut/Background/");
  SbDir->SetGuidance("Excited state control for the background.");

  NSbCmd = new G4UIcmdWithAnInteger("/BeamOut/Background/SetNumberOfBackgroundStates",this);
  NSbCmd->SetGuidance("Set number of energy states for the background.");
  NSbCmd->SetParameterName("choice",false);
  NSbCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  LSbCmd = new G4UIcmdWithAnInteger("/BeamOut/Background/BackgroundStateSelect",this);
  LSbCmd->SetGuidance("Select a background state to be setup.");
  LSbCmd->SetParameterName("choice",false);
  LSbCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SExbCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/Background/Exb",this);
  SExbCmd->SetGuidance("Set excitation energy for the selected background state");
  SExbCmd->SetParameterName("choice",false);
  SExbCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SEbCmd = new G4UIcmdWithADoubleAndUnit("/BeamOut/Background/Eb",this);
  SEbCmd->SetGuidance("Set gamma-ray decay energy for the selected background state");
  SEbCmd->SetParameterName("choice",false);
  SEbCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  

  SFbCmd = new G4UIcmdWithADouble("/BeamOut/Background/frac",this);
  SFbCmd->SetGuidance("Set direct population fraction for the selected background state");
  SFbCmd->SetParameterName("choice",false);
  SFbCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  SRbCmd = new G4UIcmdWithoutParameter("/BeamOut/Background/Report",this);
  SRbCmd->SetGuidance("Report parameters for energy states of the background.");

}

Outgoing_Beam_Messenger::~Outgoing_Beam_Messenger()
{
  delete BeamOutDir;
  delete DoppXCmd;
  delete DoppYCmd;
  delete DoppZCmd;
  delete DoppbetaCmd;
  delete TEx1Cmd;
  delete TEx2Cmd;
  delete CExFCmd;
  delete TExFCmd;
  delete RepCmd;
  delete DZCmd;
  delete DACmd;
  delete QDir;
  delete NQCmd;
  delete SQCmd;
  delete SCCmd;
  delete QUFCmd;
  delete QRFCmd;
  delete QKECmd;
  delete QKEuCmd;
  delete dpFWHMCmd;
  delete dpCmd;
  delete dpfCmd;
  delete SDir;
  delete NSCmd;
  delete LSCmd;
  delete SExCmd;
  delete SEgCmd;
  delete STCmd;
  delete SFCmd;
  delete SRCmd;
  delete DPCmd;
  //TM added on 6/25/2018 for version 4.2
  delete dpFWHMRCmd;
  delete dpRCmd;
  delete dpfRCmd;
  
  delete SbDir; 
  delete NSbCmd; 
  delete LSbCmd; 
  delete SExbCmd;
  delete SEbCmd; 
  delete SFbCmd;
  delete SRbCmd; 
}


void Outgoing_Beam_Messenger::SetNewValue(G4UIcommand* command,G4String newValue)
{ 

  if( command == DACmd )
    { BeamOut->setDA(DACmd->GetNewIntValue(newValue));}
  if( command == DZCmd )
    { BeamOut->setDZ(DZCmd->GetNewIntValue(newValue));}
  if( command == dpCmd )
    { BeamOut->Setdp(dpCmd->GetNewDoubleValue(newValue));}
  if( command == dpFWHMCmd )
    { BeamOut->SetdpFWHM(dpFWHMCmd->GetNewDoubleValue(newValue));}
  if( command == dpfCmd )
    { BeamOut->Setdpf(dpfCmd->GetNewDoubleValue(newValue));}
  if( command == TEx1Cmd )
    { BeamOut->setTarEx1(TEx1Cmd->GetNewDoubleValue(newValue));}
  if( command == TEx2Cmd )
    { BeamOut->setTarEx2(TEx2Cmd->GetNewDoubleValue(newValue));}
  if( command == CExFCmd )
    { BeamOut->setCFrac(CExFCmd->GetNewDoubleValue(newValue));}
  if( command == TExFCmd )
    { BeamOut->setTFrac(TExFCmd->GetNewDoubleValue(newValue));}
  if( command == DoppbetaCmd )
    { BeamOut->setDoppbeta(DoppbetaCmd->GetNewDoubleValue(newValue));}
  if( command == DoppZCmd )
    { BeamOut->setDoppZ(DoppZCmd->GetNewDoubleValue(newValue));}
  if( command == DoppYCmd )
    { BeamOut->setDoppY(DoppYCmd->GetNewDoubleValue(newValue));}
  if( command == DoppXCmd )
    { BeamOut->setDoppX(DoppXCmd->GetNewDoubleValue(newValue));}
  if( command == RepCmd )
    { BeamOut->Report();}
  if( command == NQCmd )
    { BeamOut->SetNQ(NQCmd->GetNewIntValue(newValue));}
  if( command == SQCmd )
    { BeamOut->SelectQ(SQCmd->GetNewIntValue(newValue));}
  if( command == SCCmd )
    { BeamOut->SetQCharge(SCCmd->GetNewIntValue(newValue));}
  if( command == QUFCmd )
    { BeamOut->SetQUnReactedFraction(QUFCmd->GetNewDoubleValue(newValue));}
  if( command == QRFCmd )
    { BeamOut->SetQReactedFraction(QRFCmd->GetNewDoubleValue(newValue));}
  if( command == QKECmd )
    { BeamOut->SetQKE(QKECmd->GetNewDoubleValue(newValue));}
  if( command == QKEuCmd )
    { BeamOut->SetQKEu(QKEuCmd->GetNewDoubleValue(newValue));}
  if( command == NSCmd )
    { BeamOut->SetNS(NSCmd->GetNewIntValue(newValue));}
  if( command == LSCmd )
    { BeamOut->SelectState(LSCmd->GetNewIntValue(newValue));}
  if( command == SExCmd )
    { BeamOut->SetStateEx(SExCmd->GetNewDoubleValue(newValue));}
  if( command == SEgCmd )
    { BeamOut->SetStateEg(SEgCmd->GetNewDoubleValue(newValue));}
  if( command == STCmd )
    { BeamOut->SetStateTau(STCmd->GetNewDoubleValue(newValue));}
  if( command == SFCmd )
    { BeamOut->SetStateFrac(SFCmd->GetNewDoubleValue(newValue));}
  if( command == SRCmd )
    { BeamOut->ReportEnergyStates();}
  if( command == DPCmd )
    { BeamOut->setDecayProperties();}
  //TM added on 6/25/2018 for version 4.2    
  if( command == dpRCmd )
    { BeamOut->SetdpR(dpRCmd->GetNewDoubleValue(newValue));} 
  if( command == dpFWHMRCmd )
    { BeamOut->SetdpFWHMR(dpFWHMRCmd->GetNewDoubleValue(newValue));}
  if( command == dpfRCmd )
    { BeamOut->SetdpfR(dpfRCmd->GetNewDoubleValue(newValue)); }  
    
 if( command == NSbCmd )
    { BeamOut->SetNSb(NSbCmd->GetNewIntValue(newValue));}
  if( command == LSbCmd )
    { BeamOut->SelectBackgroundState(LSbCmd->GetNewIntValue(newValue));}
  if( command == SExbCmd )
    { BeamOut->SetBackgroundEx(SExbCmd->GetNewDoubleValue(newValue));}
  if( command == SEbCmd )
    { BeamOut->SetBackgroundEg(SEbCmd->GetNewDoubleValue(newValue));}     
  if( command == SFbCmd )
    { BeamOut->SetBackgroundFrac(SFbCmd->GetNewDoubleValue(newValue));}
  if( command == SRbCmd )
    { BeamOut->ReportBackgroundStates();}
    

    
}

