#ifndef DetectorConstruction_H
#define DetectorConstruction_H 1

#include "G4VUserDetectorConstruction.hh"
#include "Materials.hh"
#include "Experimental_Hall.hh"
#include "Experimental_Hall_Messenger.hh"
#include "Beam_Tube.hh"
#include "Beam_Tube_Messenger.hh"
#include "Plunger.hh"
#include "Plunger_Messenger.hh"

#include "SeGA_Array.hh"
#include "SeGA_Array_Messenger.hh"

#include "Gretina_Array.hh"
#include "Gretina_Array_Messenger.hh"
#include "Gretina_NSCL_Shell.hh"

#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "TrackerIonSD.hh"
#include "TrackerIonSD_Messenger.hh"
#include "TrackerGammaSD.hh"
#include "GretinaSD.hh"
#include "G4SDManager.hh"

class DetectorConstruction : public G4VUserDetectorConstruction
{
public:

  DetectorConstruction();
  ~DetectorConstruction();

  G4VPhysicalVolume*    Construct();
  SeGA_Array*           GetSeGA(){ return the_SeGA_Array;}
  Gretina_Array*        GetGretina(){ return the_Gretina_Array;}
  G4Box*                GetDegrader(){return aPlunger->GetDegrader();}
  G4Box*                GetTarget(){return aPlunger->GetTarget();}
  G4Box*                GetStopper(){ return aPlunger->GetStopper();}
 
  G4VPhysicalVolume*    GetDegraderPlacement(){return aPlunger->GetDegraderPlacement();}
  G4VPhysicalVolume*    GetTargetPlacement(){return aPlunger->GetTargetPlacement();}
  G4VPhysicalVolume*    GetStopperPlacement(){return aPlunger->GetStopperPlacement();}
  G4double              GetRRatio(){return aPlunger->GetRRatio();}
  G4double              GetRRatio2(){return aPlunger->GetRRatio2();}
  void                  setTargetReactionDepth(G4double depth){ aPlunger->setTargetReactionDepth(depth);};
  void                  setDegraderReactionDepth(G4double depth){ aPlunger->setDegraderReactionDepth(depth);};
  void                  setStopperReactionDepth(G4double depth){ aPlunger->setStopperReactionDepth(depth);};



  G4double              GetRatioT(){return aPlunger->GetRatioT();}
  G4double              GetRatioD(){return aPlunger->GetRatioD();}  


  inline G4double	GetTargetThick()	   { return aPlunger->GetTargetThickness(); }
  inline G4double	GetDegraderThick()	   { return aPlunger->GetDegraderThickness(); }
  inline G4double	GetStopperThick()	   { return aPlunger->GetStopperThickness(); }   
  inline G4double	GetTargetScaleDensity()    { return aPlunger->GetTarScaleDensity(); } 
  inline G4double	GetDegraderScaleDensity()  { return aPlunger->GetDegScaleDensity(); } 
  inline G4double	GetStopperScaleDensity()   { return aPlunger->GetStopScaleDensity(); }     
  inline G4double	GetDis1()		   { return aPlunger->GetDistance1(); }   
  inline G4double	GetDis2()		   { return aPlunger->GetDistance2(); }     
  
  /** 
	*  Set Plunger Geometry type
	* @param $n 
	* 0 for a single target
	* 1 for Standard Plunger target+degrader
	* 2 for Differential Plunger target+degrader+stopper
	*/
  void                  SetPlungerType(G4int n){PlungerType = n;};
  //! Return PlungerType
  G4int                 GetPlungerType(){return aPlunger->GetPlungerType();}

  //! Set SeGA Flag
  inline void           SetUseSeGA(G4bool b){UseSeGA = b;};
  //! Return SeGA Flag
  inline G4bool         IsDefinedSeGA(){return UseSeGA;};
  //! Set SeGA Geometry Filename
  void                  SetGeomFileName(G4String name){GeomFileName = name;}

  //! AR New in v4.3 -> Set Gretina Euler Filename 
  void                  SetEulerFileName(G4String name){EulerFileName = name;}
  
  //! Set Gretina Flag
  inline void           SetUseGretina(G4bool b){UseGretina = b;};
  //! Return GRetina Flag
  inline G4bool         IsDefinedGretina(){return UseGretina;};

  G4int GetSegmentNumber( G4int, G4ThreeVector ); //Added by CJL
  
  //! Return Gretina Sensitive Detector
  inline GretinaSD*  GeSD              () { return TrackerGretina;      };
  //! Update Geometry
  void   UpdateGeometry();
  //! Return Hall logical Volume 
  inline G4LogicalVolume* GetHallLog(){return ExpHall_log;};

  inline G4VPhysicalVolume* HallPhys(){return ExpHall_phys;}

  //! Set Gretnina Shell
  inline void SetShellStatus(G4String s){shellStatus = s;}
  
  //! AR new in v4.3 -> To add cylindrical shield
  void SetAddShield(G4bool b){AddShield = b;};
  
private:
  //! ExpHall Logical volumes
  G4LogicalVolume*         ExpHall_log;
  //! ExpHall Physical volumes
  G4VPhysicalVolume*       ExpHall_phys;
  //! ExpHall Messenger
  Experimental_Hall_Messenger* ExperimentalHallMessenger;
  //! BeamTude Object
  Beam_Tube_Messenger*     BeamTubeMessenger;

  //! Plunger Object
  Plunger*                 aPlunger;
  //! Plunger Messenger Object
  Plunger_Messenger*       PlungerMessenger;

  
  //! The SeGA Array object 
  SeGA_Array*              the_SeGA_Array;
  //! The SeGA Array Messenger object 
  SeGA_Array_Messenger*    the_SeGA_Array_Messenger;

  //! The Gretina Array object 
  Gretina_Array*           the_Gretina_Array;
  //! The Gretina Array Messenger object 
  Gretina_Array_Messenger* the_Gretina_Array_Messenger;

  //! Shell Status
  G4String shellStatus;


  TrackerGammaSD*          TrackerGamma;
  TrackerIonSD*            TrackerIon;
  TrackerIonSD_Messenger*  TrackerIonSDMessenger;
  GretinaSD*               TrackerGretina;
  
  //! Plunger type  
  G4int                    PlungerType;
  //! UseSeGA Flag
  G4bool                   UseSeGA;
  //! SeGA Geometry definition file 
  G4String GeomFileName;
  //! AR New in v4.3 -> Gretina Euler definition file
  G4String EulerFileName;
  //! UseGretina Flag
  G4bool                   UseGretina;

  //! AR new in v4.3 -> To add the cylindrical Shield
  G4bool   AddShield;
  



};

#endif

