#ifndef ROOTRecorder_h
#define ROOTRecorder_h 1

#include "Analysis.hh"

#include "globals.hh"
#include <vector>

#include "G4Run.hh"
#include "G4Event.hh"

#include "TROOT.h"
#include "TApplication.h"
#include "TGClient.h"
#include "TCanvas.h"
#include "TSystem.h"
#include "TTree.h"
#include "TBranch.h"
#include "TFile.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TNtuple.h"


class Analysis;
class ROOTRecorder_Messenger;


class ROOTRecorder
{
public:
  ROOTRecorder(Analysis*);
  ~ROOTRecorder();

  void OpenOutputTree();

  void CloseOutputTree();

  void outAttach();

  void AutoSave();

  void GetData();

  void Init();

  void CreateHistograms();
  void WriteHistograms();
  void FillHistograms();

  void FillTree();
  
  //! Display Recorder Setting
  void Report();
  //! End of Run action
  void BeginOfRun();
  //! End of Run action
  void EndOfRun();
  
  ROOTRecorder_Messenger*  Recorder_Messenger;

  /** \brief Ouput File
	*/
  TFile *outTree;

  /** \brief Output Tree
	*/
  TTree *outT;
  TTree *parT;  

  G4String outTreeName;

  Analysis*	Ana;

  /*
	 void RecordBeginOfRun(const G4Run *);
	 void RecordEndOfRun(const G4Run *);
	 void RecordBeginOfEvent(const G4Event *);
	 void RecordEndOfEvent(const G4Event *);
  */
  void SaveOutputTree();

  void SetFileName(const G4String);
  //! Set Histos Flag for SeGA
  void SetFillHistosSeGA(G4bool b);
  //! Set Histos Flag for Gretina
  void SetFillHistosGretina(G4bool b);
  //! Set Histos Flag for SeGA Segments
  void SetFillHistosSeGASeg(G4bool b);
  //! Set Histos Flag for S800
  void SetFillHistosS800(G4bool b);
  //! Set Tree Flag for SeGA
  void SetFillTreeSeGA(G4bool b);
  //! Set Tree Flag for S800
  void SetFillTreeS800(G4bool b);
  //! Set Tree Flag for Gretina
  void SetFillTreeGretina(G4bool b);
  //! AR New in v4.3 Set Fill Histos Flag for Cascade Analysis
  void SetFillHistosCascade(G4bool b);
  

private:

  TH1F   *DetE_R1,*DetE_R2;
  TH1F   *DetEDC_R1,*DetEDC_R2,*DetEDC_R1_M1,*DetEDC_R2_M1;
  TH1F   *S800_DTA,*S800_YTA,*S800_Theta,*S800_Phi,*S800_ATA,*S800_BTA,*S800_Beta;
  TH1F   *CoreEDC[24];
  TH1F   *CoreEDC511[24];
  TH1F   *CoreE[24];
  TH1F   *SegE[24][32];
  TH1F   *SegEDC[24][32];
  TH1F   *SegAng[24][32];

 //TM added in v4.2
  TH1F * DetAddback;
  TH1F * DetAddbackMode1;
  TH1F * DetAddbackMode3;
  TH1F * Background;
  TH1F * BackgroundDC;
  TH1F * DetAddbackModeSphere;
  TH2F * DetAddbackModeSphere_vs_ReactionZ;
  //////
  
  //! Root Histograms for Gretina Energy
  TH1F *DetE_G;
  //! Root Histograms for Gretina Doppler Corrected Energy
  TH1F *DetEDC_G;
 //! Root Histograms for Gretina Doppler Corrected Energy
  TH1F *TotalE_G;

  //TM added in v4.2  
    //! Root Histograms for Gretina Energy against angles
  TH2F *Theta_G_vs_DetE_G;
  TH2F *Theta_G_vs_DetE_Background_G; ///CRL333
  //! Root Histograms for Gretina Doppler Corrected Energy against angles
  TH2F *Theta_G_vs_DetEDC_G;
  TH2F *Theta_G_vs_DetEDC_G_dcut;
  TH2F *Theta_G_vs_DetEDC_Background_G; /// CRL333
  TH2F *Theta_G_vs_DetEDC_GMult1;
  TH2F *Theta_G_vs_Addback;
  TH2F *Theta_G_vs_AddbackMode1;
  TH2F *Theta_G_vs_AddbackModeSphere;
  TH2F *DetAddbackModeSphereVsMult;
  TH2F * DetEDC_vs_Mult;
  TH2F * Detadd_vs_Mult;
  TH2F*  TotalE_G_vs_Theta_G;
  //////
  //AR New in v4.3 -> Depth histograms
  TH2F *Depth_G_vs_DetE_G;
  TH2F *Depth_G_vs_DetEDC_G;
  
  G4bool FillHistosSeGA;
  G4bool FillHistosSeGASeg;
  G4bool FillHistosGretina;
  G4bool	FillHistosS800;
  G4bool	FillTreeSeGA;
  G4bool	FillTreeGretina;
  G4bool	FillTreeS800;
  //AR New in v4.3 -> Cascade Analysis Histos
  G4bool	FillHistosCascade;
  
  //AR New in v4.3 -> Rob's Cascade Analysis Histos
  TH1F *CascadeZ;
  TH1F *CascadeZ_largeRange;
  TH1F *CorrectedE;
  TH2F *DetEDC_G_vs_DetEDC_G;
 
  TH2F *CascadeZ_vs_CorrectedE;
  TH2F *CascadeZ_vs_CorrectedE_mult2;

  TH1F * DetEDC_ABsph;
  TH1F* DetE_ABsph;

  TH1F* CascadeZ_AB;
  TH1F* CascadeZ_AB_largeRange;
  TH1F* CorrectedE_AB;
  TH2F *CascadeZ_vs_CorrectedE_AB;
  TH2F *CascadeZ_vs_CorrectedE_AB_mult2;
  TH2F *DetEDC_AB_vs_DetEDC_AB;
  TH2F *Span_vs_DetE_AB;
  TH2F *ComptAngDiff_vs_DetE_AB;
  
};

#endif
