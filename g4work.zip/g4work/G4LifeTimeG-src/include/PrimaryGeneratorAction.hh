#ifndef PrimaryGeneratorAction_h
#define PrimaryGeneratorAction_h 1

#include "G4VUserPrimaryGeneratorAction.hh"
#include "G4ThreeVector.hh"
#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4ParticleDefinition.hh"
#include "DetectorConstruction.hh"
#include "Incoming_Beam.hh"
#include "Outgoing_Beam.hh"
#include "Randomize.hh"
#include "G4RandomDirection.hh"
#include <vector>
#include "SourceData.hh"

using namespace std;

class PrimaryGeneratorAction : public G4VUserPrimaryGeneratorAction
{
public:
  PrimaryGeneratorAction(DetectorConstruction*,Incoming_Beam*,Outgoing_Beam*);
  ~PrimaryGeneratorAction();
  
public:
  void GeneratePrimaries(G4Event* anEvent);
  void SetSource(){source=true;};
  void SetInBeam(){source=false;};
  void SetSourceX(G4double x){sourcePosition.setX(x);}
  void SetSourceY(G4double y){sourcePosition.setY(y);}
  void SetSourceZ(G4double z){sourcePosition.setZ(z);}
  void SetSourceOnTargetFace();
  void SetSourceOnTargetBack();
  void SetSourceOnDegraderFace();
  void SetSourceOnDegraderBack();
  void SetSourceOnStopperFace();
  void SetSourceOnStopperBack();
  void SourceReport();
  void SetSourceEu152();
  void SetSingleSource(G4double);
  void ReactionOn(){BeamOut->SetReactionOn();fracOn=false;}
  void ReactionOff(){BeamOut->SetReactionOff();fracOn=false;}
  void SetFraction(G4double f){fracOn=true;frac=f;}
  //AR New in v4.3 -> To reproduce unusual DTA distributions
  void SetDTASlope(G4double f){dtaSlopeOn=true;dtaslope=f;}
  void SetDTAOffset(G4double f){dtaOffsetOn=true;dtaoffset=f;}
  void SetDTAMean(G4double f){dtaMeanOn=true;dtamean=f;}
  void SetDTASigma(G4double f){dtaSigmaOn=true;dtasigma=f;}
  G4double GetSourceEnergy();

private:


  G4int n_particle;
  G4ParticleGun* particleGun;
  G4ParticleTable* particleTable;
  G4ParticleDefinition* ion;
  G4ThreeVector  direction;
  G4ThreeVector  position;
  G4double       KE;
  Incoming_Beam* BeamIn;
  Outgoing_Beam* BeamOut;
  DetectorConstruction* myDetector;
  G4double frac;
  G4bool   fracOn;
  //AR New in v4.3 -> In order to reproduce unusual DTA distributions
  G4bool dtaSlopeOn;
  G4bool dtaOffsetOn;
  G4double dtaslope;
  G4double dtaoffset;
  G4bool dtaSigmaOn;
  G4bool dtaMeanOn;
  G4double dtasigma;
  G4double dtamean;
  // source stuff
  G4bool source; 
  G4ThreeVector sourcePosition;
  vector<SourceData*> TheSource;
  G4double sourceBranchingSum;
};


#endif


           
