#ifndef SeGA_Ring_H
#define SeGA_Ring_H 1

#include "G4LogicalVolume.hh"
#include "SeGA_Detector.hh"
#include "SeGA_Detector_Messenger.hh"
#include "TrackerGammaSD.hh"
#include "G4ThreeVector.hh"
#include "globals.hh"
#include <iostream>
#include <vector>
using namespace std;
class SeGA_Ring 
{
  public:
  
  SeGA_Ring(G4LogicalVolume*);
  ~SeGA_Ring();

  void Construct(G4int,G4String);
  void MakeSensitive(TrackerGammaSD*);
  SeGA_Detector* GetDetector(G4int);
  void DopplerOn();
  void DopplerOff();
  void CalcSegCenters(G4ThreeVector);
  void ReportSegments();
  G4int GetRingID(){return RingID;};
private:
  G4int RingID;
  vector<SeGA_Detector*> theRing;
  G4LogicalVolume* expHall_log;
  G4String         GeomFileName;
};

#endif
