#ifndef EnergyBackground_Level_h
#define EnergyBackground_Level_h 1

#include "globals.hh"
#include "G4UnitsTable.hh"

class EnergyBackground_Level
{
public:
  EnergyBackground_Level();
  ~EnergyBackground_Level();
  void  SetExb(G4double x){Exb=x;}
  void  SetEb(G4double x){Eb=x;}
  void  SetFracb(G4double x){fracb=x;}
  void  ReportBackground();
  G4double GetExb(){return Exb;}
  G4double GetEb(){return Eb;}
  G4double GetFracb(){return fracb;}
private:
  G4double Exb;
  G4double Eb;
  G4double fracb;
 
};
#endif


           
