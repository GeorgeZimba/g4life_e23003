//#define DEBUG
#include "DetectorConstruction.hh"

DetectorConstruction::DetectorConstruction()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  PlungerType = 0; // Default only Target
  UseSeGA = 0;
  UseGretina = 0;
  //AR New in v4.3 -> To add cylindrical Shield
  AddShield = FALSE;
  ;}

DetectorConstruction::~DetectorConstruction()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 

  delete ExperimentalHallMessenger;
  delete BeamTubeMessenger;
  delete PlungerMessenger;
  delete TrackerIonSDMessenger;
  if(UseSeGA) delete the_SeGA_Array_Messenger;
  if(UseGretina) delete the_Gretina_Array_Messenger;
}

G4VPhysicalVolume* DetectorConstruction::Construct()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 

  Materials* materials=new Materials();

  //Experimental Hall
  Experimental_Hall* ExperimentalHall = new Experimental_Hall(materials);
  ExpHall_phys=ExperimentalHall->Construct();
  ExpHall_log=ExperimentalHall->GetLogVolume();
  // ExperimentalHall->Report();
  ExperimentalHallMessenger = new Experimental_Hall_Messenger(ExperimentalHall);

  //beam tube

  Beam_Tube* BeamTube = new Beam_Tube(ExpHall_log,materials);
  BeamTube->Construct();
  BeamTubeMessenger = new Beam_Tube_Messenger(BeamTube);

  //Target Or Plunger 
  aPlunger = new Plunger(ExpHall_log,materials,PlungerType,AddShield);
  aPlunger->Construct();
  PlungerMessenger = new Plunger_Messenger(aPlunger);


  //------------------------------------------------ 
  // Sensitive detectors
  //------------------------------------------------ 
  
  G4SDManager* SDman = G4SDManager::GetSDMpointer();
  
  TrackerGamma = new TrackerGammaSD("GammaTracker");
  SDman->AddNewDetector( TrackerGamma );
  
  TrackerGretina = new GretinaSD("","","GretinaTracker",0,0,0);
  SDman->AddNewDetector(TrackerGretina);


  //SeGA array
  if(UseSeGA){
	  the_SeGA_Array=new SeGA_Array(ExpHall_log);
	  the_SeGA_Array->Construct(GeomFileName);
	  the_SeGA_Array_Messenger = new SeGA_Array_Messenger(the_SeGA_Array);  
	  the_SeGA_Array->MakeSensitive(TrackerGamma);
  }
  
  //Gretina Array
  if(UseGretina){
    the_Gretina_Array=new Gretina_Array("./Geometry/Gretina/",EulerFileName); //AR New in v4.3
    the_Gretina_Array_Messenger = new Gretina_Array_Messenger(the_Gretina_Array); 
    the_Gretina_Array->Construct();

    // Construct the shell 
    if( shellStatus == "full"  ||
	shellStatus == "north" ||
	shellStatus == "south"){
      Gretina_NSCL_Shell* Shell = new Gretina_NSCL_Shell();
      Shell->Placement(shellStatus);
    }

    //	 the_Gretina_Array->Report();
  }

  //------------------------------------------------
  // Detectors sensitive for ion tracking
  //------------------------------------------------
  TrackerIon = new TrackerIonSD("IonTracker");
  TrackerIonSDMessenger = new TrackerIonSD_Messenger(TrackerIon);
  SDman->AddNewDetector( TrackerIon );
  aPlunger->GetTargetLog()->SetSensitiveDetector(TrackerIon);

  if(PlungerType == 1){
	 aPlunger->GetDegraderLog()->SetSensitiveDetector(TrackerIon);
  }

  if (PlungerType == 2){
	 aPlunger->GetStopperLog()->SetSensitiveDetector(TrackerIon);
	 aPlunger->GetDegraderLog()->SetSensitiveDetector(TrackerIon);
  }

  ExpHall_log->SetSensitiveDetector(TrackerIon);

  return ExpHall_phys;
}




G4int DetectorConstruction::GetSegmentNumber(G4int nGe, G4ThreeVector position )
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 

  return the_Gretina_Array->GetSegmentNumber( nGe, position);
}
  


void DetectorConstruction::UpdateGeometry()
{
  G4cout << "Presently not implemented" << G4endl;
  
//   if( ExpHall_phys ){
//     delete  ExpHall_log;
//     delete  ExpHall_phys;
//   }
//   Materials* materials=new Materials();

//   Experimental_Hall* ExperimentalHall = new Experimental_Hall(materials);
//   ExpHall_phys=ExperimentalHall->Construct();
//   ExpHall_log=ExperimentalHall->GetLogVolume();
//   // ExperimentalHall->Report();
//   ExperimentalHallMessenger = new Experimental_Hall_Messenger(ExperimentalHall);

//   Beam_Tube* BeamTube = new Beam_Tube(ExpHall_log,materials);
//   BeamTube->Construct();
//   BeamTubeMessenger = new Beam_Tube_Messenger(BeamTube);

//   //Target Or Plunger 
//   aPlunger = new Plunger(ExpHall_log,materials,PlungerType);
//   aPlunger->Construct();
//   PlungerMessenger = new Plunger_Messenger(aPlunger);
//   G4cout << " This functionality is not presently working ... " << G4endl ;
// 	 if(UseGretina){
// 		the_Gretina_Array->Construct();
// 	 }
// 	 G4RunManager* runManager = G4RunManager::GetRunManager();
// 	 runManager->DefineWorldVolume( ExpHall_phys);
	 
}

