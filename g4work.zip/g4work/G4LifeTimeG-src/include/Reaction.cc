#include "Reaction.hh"

//#define DEBUG 1

Reaction::Reaction(Outgoing_Beam* BO, const G4String& aName)
  : G4VProcess(aName), BeamOut(BO)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  if (verboseLevel>1) {
	 G4cout <<GetProcessName() << " is created "<< G4endl;
  }
  BeamOut=BO;
}

Reaction::~Reaction() 
{ 
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif                                    
}                                     

G4VParticleChange* Reaction::PostStepDoIt(
														const G4Track& aTrack,
														const G4Step& 
														)
//
// Stop the current particle, if requested by G4UserLimits 
// 			    			    			    
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  aParticleChange.Initialize(aTrack);

  if(reaction_here)
    {
      reaction_here=false;

      BeamOut->ScanInitialConditions(aTrack);
// 		G4cout << "Energy " << 		BeamOut->ReactionProduct()->GetMomentum().mag() << G4endl;;
      aParticleChange.ProposeTrackStatus(fStopAndKill);


      if(G4UniformRand()<BeamOut->getTFrac())
		  {

			 aParticleChange.SetNumberOfSecondaries(2);	  
			 aParticleChange.AddSecondary(BeamOut->ProjectileGS(),BeamOut->ReactionPosition(),true);
			 aParticleChange.AddSecondary(BeamOut->TargetExcitation(),BeamOut->ReactionPosition(),true);
		  }
      else
		  {

			 
			 aParticleChange.SetNumberOfSecondaries(1);
			 aParticleChange.AddSecondary(BeamOut->ReactionProduct(),BeamOut->ReactionPosition(),true);
		  }

    }


   
  return &aParticleChange;
}

G4double Reaction::PostStepGetPhysicalInteractionLength(
																		  const G4Track& aTrack,
																		  G4double,
																		  G4ForceCondition* condition
																		  )
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif


  reaction_here=false;
  *condition=NotForced;

  if(BeamOut->ReactionOn()){
	 G4String name=aTrack.GetVolume()->GetLogicalVolume()->GetName();
	 G4UserLimits* pUserLimits = aTrack.GetVolume()->GetLogicalVolume()->GetUserLimits();
	 if(name=="target_log"||name=="degrader_log"||name=="stopper_log"){
		G4double ZReaction=pUserLimits->GetUserMinRange(aTrack);
		G4double ZCurrent=aTrack.GetPosition().getZ();
		G4double Z=ZReaction-ZCurrent;
		if(Z<0 ){
#ifdef DEBUG
		  G4cout<<" Past the reaction point"<<G4endl;
		  G4cout<<" Volume "<<name<<G4endl;
		  G4cout<<" Z[mm]: reaction "<<ZReaction/mm<<" current "<<ZCurrent/mm<<" DZ "<<Z/mm<<G4endl;
#endif
		  return DBL_MAX;
		}
		if(Z>eps){
		  G4ThreeVector dir=aTrack.GetDynamicParticle()->GetMomentumDirection();
		  dir*=(ZReaction-ZCurrent);
		  return dir.mag();
		  
#ifdef DEBUG
		  G4cout<<" Before the reaction point"<<G4endl;
		  G4cout<<" Volume "<<name<<G4endl;
		  G4cout<<" Z[mm]: reaction "<<ZReaction/mm<<" current "<<ZCurrent/mm<<" DZ "<<Z/mm<<G4endl;
#endif 
		}
		
		if(Z<=eps){
#ifdef DEBUG
		  G4cout<<" Past the reaction point"<<G4endl;
		  G4cout<<" Volume "<<name<<G4endl;
		  G4cout<<" Z[mm]: reaction "<<ZReaction/mm<<" current "<<ZCurrent/mm<<" DZ "<<Z/mm<<G4endl;
#endif
		  reaction_here=true;
		  return 0.;
		}
	 }
  }
  return DBL_MAX;
}

