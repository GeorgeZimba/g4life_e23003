#include "Materials.hh"

 Materials:: Materials()
{
  // Elements
 
  elementH  = new G4Element("Hydrogen",  "H",  1.,  1.0079*g/mole);
  elementC  = new G4Element("Carbon",    "C",  6.,  12.011*g/mole);
  elementN  = new G4Element("Nitrogen",  "N",  7.,  14.007*g/mole);
  elementO  = new G4Element("Oxygen",    "O",  8., 15.9994*g/mole);
  elementMg = new G4Element("Magnesium", "Mg",12., 24.3050*g/mole);
  elementAl = new G4Element("Aluminium", "Al",13., 26.9815*g/mole);
  elementSi = new G4Element("Silicon",   "Si",14., 28.0855*g/mole);
  elementTi = new G4Element("Titanium",  "Ti",22., 47.90*g/mole);
  elementV  = new G4Element("Vanadium",  "V", 23., 50.9415*g/mole);
  elementFe = new G4Element("Iron",      "Fe",26.,  55.845*g/mole);
  elementMo = new G4Element("Molybdenum","Mo",42.,   95.94*g/mole);
  elementPt = new G4Element("Platinum",  "Pt",78.,  195.08*g/mole);
  elementAu = new G4Element("Gold",      "Au",79.,  196.97*g/mole);
  elementIr = new G4Element("Iridium",   "Ir",77., 192.217*g/mole);
  elementTa = new G4Element("Tantalum",  "Ta",73., 180.948*g/mole);
  elementW =  new G4Element("Tungsten",  "W",74., 183.85*g/mole);
  elementPb = new G4Element("Lead",      "Pb",82., 207.2*g/mole);
  
// Materials

  vacuum = new G4Material("vacuum", 1, 1.00794*g/mole, 
     1.0E-25*g/cm3, kStateGas, 0.1*kelvin, 1.0E-19*pascal);

  Al = new G4Material("Al", 13, 26.98153*g/mole, 2.70*g/cm3);
  C  = new G4Material("C",   6, 12.011*g/mole,   2.15*g/cm3);
  Be = new G4Material("Be", 4, 9.012182*g/mole, 1.84*g/cm3);
  Si = new G4Material("Si", 14, 28.0855*g/mole, 2.33*g/cm3);
  Fe = new G4Material("Fe", 26, 55.845*g/mole, 7.8658*g/cm3);

  Nb = new G4Material("Nb", 41, 92.90638*g/mole, 8.57*g/cm3);
  Au = new G4Material("Au", 79, 196.9*g/mole, 19.32*g/cm3);
  Ir = new G4Material("Ir", 77, 192.217*g/mole, 22.56*g/cm3);
  Ta = new G4Material("Ta", 73, 180.948*g/mole, 16.69*g/cm3);
  W = new G4Material("W", 74, 183.85*g/mole, 19.3*g/cm3);
  Pb = new G4Material("Pb", 82, 207.2*g/mole, 11.344*g/cm3 );
}

 Materials::~ Materials()
{;}
//-----------------------------------------------------------------------------
G4Material*  Materials::FindMaterial(G4String materialName)
{


   // search the material by its name 
  G4Material* pttoMaterial = G4Material::GetMaterial(materialName);  

  return pttoMaterial;
  
}
