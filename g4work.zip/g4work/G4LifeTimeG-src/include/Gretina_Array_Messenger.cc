#include "Gretina_Array_Messenger.hh"

Gretina_Array_Messenger::Gretina_Array_Messenger(Gretina_Array* pTarget)
 :myTarget(pTarget)
{ 

  const char *aLine;
  G4String commandName;
  G4String directoryName;
  
  directoryName ="/Gretina/";

  commandName = directoryName + "solidFile";
  aLine = commandName.c_str();
  SetSolidCmd = new G4UIcmdWithAString(aLine, this);
  SetSolidCmd->SetGuidance("Select file with the detector vertexes.");
  SetSolidCmd->SetGuidance("Required parameters: 1 string.");
  SetSolidCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "clustFile";
  aLine = commandName.c_str();
  SetClustCmd = new G4UIcmdWithAString(aLine, this);
  SetClustCmd->SetGuidance("Select file with the cluster description.");
  SetClustCmd->SetGuidance("Required parameters: 1 string.");
  SetClustCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
    
  commandName = directoryName + "angleFile";
  aLine = commandName.c_str();
  SetAngleCmd = new G4UIcmdWithAString(aLine, this);
  SetAngleCmd->SetGuidance("Select file with the detector angles.");
  SetAngleCmd->SetGuidance("Required parameters: 1 string.");
  SetAngleCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
    
  commandName = directoryName + "wallsFile";
  aLine = commandName.c_str();
  SetWallsCmd = new G4UIcmdWithAString(aLine, this);
  SetWallsCmd->SetGuidance("Select file with the walls vertexes.");
  SetWallsCmd->SetGuidance("Required parameters: 1 string.");
  SetWallsCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "detectorMaterial";
  aLine = commandName.c_str();
  DetMatCmd = new G4UIcmdWithAString(aLine, this);
  DetMatCmd->SetGuidance("Select Material of the detector.");
  DetMatCmd->SetGuidance("Required parameters: 1 string.");
  DetMatCmd->SetParameterName("choice",false);
  DetMatCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "wallsMaterial";
  aLine = commandName.c_str();
  WalMatCmd = new G4UIcmdWithAString(aLine, this);
  WalMatCmd->SetGuidance("Select Material of the walls.");
  WalMatCmd->SetGuidance("Required parameters: 1 string.");
  WalMatCmd->SetParameterName("choice",false);
  WalMatCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "rotateArray";
  aLine = commandName.c_str();
  RotateArrayCmd = new G4UIcmdWithAString(aLine, this);
  RotateArrayCmd->SetGuidance("Select rotation of the array.");
  RotateArrayCmd->SetGuidance("Required parameters: 2 double (rotation angles in degrees).");
  RotateArrayCmd->SetParameterName("choice",false);
  RotateArrayCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "rotatePrisma";
  aLine = commandName.c_str();
  RotatePrismaCmd = new G4UIcmdWithADouble(aLine, this);
  RotatePrismaCmd->SetGuidance("Select rotation of PRISMA.");
  RotatePrismaCmd->SetGuidance("Required parameters: 1 double (rotation angle in degrees).");
  RotatePrismaCmd->SetParameterName("choice",false);
  RotatePrismaCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "translateArray";
  aLine = commandName.c_str();
  TranslateArrayCmd = new G4UIcmdWith3Vector(aLine, this);
  TranslateArrayCmd->SetGuidance("Select traslation of the array.");
  TranslateArrayCmd->SetGuidance("Required parameters: 3 double (x, y, z components in mm).");
  TranslateArrayCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "enableCapsules";
  aLine = commandName.c_str();
  EnableCapsulesCmd = new G4UIcmdWithABool(aLine, this);
  EnableCapsulesCmd->SetGuidance("Generate passive capsules.");
  EnableCapsulesCmd->SetGuidance("Required parameters: none.");
  EnableCapsulesCmd->SetParameterName("makeCapsule",true);
  EnableCapsulesCmd->SetDefaultValue(true);
  EnableCapsulesCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "disableCapsules";
  aLine = commandName.c_str();
  DisableCapsulesCmd = new G4UIcmdWithABool(aLine, this);
  DisableCapsulesCmd->SetGuidance("Do not generate passive capsules.");
  DisableCapsulesCmd->SetGuidance("Required parameters: none.");
  DisableCapsulesCmd->SetParameterName("makeCapsule",true);
  DisableCapsulesCmd->SetDefaultValue(false);
  DisableCapsulesCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  commandName = directoryName + "enableCyl";
  aLine = commandName.c_str();
  EnableCylCmd = new G4UIcmdWithABool(aLine, this);
  EnableCylCmd->SetGuidance("Consider the intersection between a cylinder and a polyhedron.");
  EnableCylCmd->SetGuidance("Required parameters: none.");
  EnableCylCmd->SetParameterName("useCylinder",true);
  EnableCylCmd->SetDefaultValue(true);
  EnableCylCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "disableCyl";
  aLine = commandName.c_str();
  DisableCylCmd = new G4UIcmdWithABool(aLine, this);
  DisableCylCmd->SetGuidance("Do not consider the intersection between a cylinder and a polyhedron.");
  DisableCylCmd->SetGuidance("Required parameters: none.");
  DisableCylCmd->SetParameterName("useCylinder",true);
  DisableCylCmd->SetDefaultValue(false);
  DisableCylCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "enableCryostats";
  aLine = commandName.c_str();
  cryostatCmd = new G4UIcmdWithoutParameter(aLine, this);
  cryostatCmd->SetGuidance("Include cryostats");
  cryostatCmd->SetGuidance("Required parameters: none.");
  cryostatCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "drawReadOut";
  aLine = commandName.c_str();
  DrawReadOutCmd = new G4UIcmdWithABool(aLine, this);
  DrawReadOutCmd->SetGuidance("Generates the read out geometry as the actual geometry.");
  DrawReadOutCmd->SetGuidance("For geometry testing purposes only, DO NOT RUN!");
  DrawReadOutCmd->SetGuidance("Required parameters: none.");
  DrawReadOutCmd->SetParameterName("drawReadOut",true);
  DrawReadOutCmd->SetDefaultValue(true);
  DrawReadOutCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "dontdrawReadOut";
  aLine = commandName.c_str();
  DontDrawReadOutCmd = new G4UIcmdWithABool(aLine, this);
  DontDrawReadOutCmd->SetGuidance("Disables the read out geometry as the actual geometry.");
  DontDrawReadOutCmd->SetGuidance("Required parameters: none.");
  DontDrawReadOutCmd->SetParameterName("drawReadOut",true);
  DontDrawReadOutCmd->SetDefaultValue(false);
  DontDrawReadOutCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  commandName = directoryName + "step";
  aLine = commandName.c_str();
  SetStepCmd = new G4UIcmdWithAnInteger(aLine, this);  
  SetStepCmd->SetGuidance("Define size of the integration step to calculate the segment position.");
  SetStepCmd->SetGuidance("Default step value: 1 mm.");
  SetStepCmd->SetGuidance("Required parameters: 1 integer (step will be divided by the input value).");
  SetStepCmd->AvailableForStates(G4State_PreInit,G4State_Idle);


}




Gretina_Array_Messenger::~Gretina_Array_Messenger()
{
  delete DetMatCmd;
  delete WalMatCmd;
  delete RotateArrayCmd;
  delete RotatePrismaCmd;
  delete TranslateArrayCmd;
  delete SetSolidCmd;
  delete SetAngleCmd;
  delete SetWallsCmd;
  delete SetClustCmd;
  delete EnableCylCmd;
  delete DisableCylCmd;
  delete EnableCapsulesCmd;
  delete DisableCapsulesCmd;
  delete DrawReadOutCmd;
  delete DontDrawReadOutCmd;
  delete SetStepCmd;
  delete cryostatCmd;
}

////////////////////////////////////////////////////////////////////////////////////
//                  Public methods for the messenger                              //
////////////////////////////////////////////////////////////////////////////////////


void Gretina_Array_Messenger::SetNewValue(G4UIcommand* command, G4String newValue) {

  //Note: uncomment these commands when their respective functions have been built (CL)


  if( command == SetSolidCmd ) {
    myTarget->SetSolidFile(newValue);
  } 
  if( command == SetAngleCmd ) {
    myTarget->SetAngleFile(newValue);
  } 
  if( command == SetWallsCmd ) {
    myTarget->SetWallsFile(newValue);
  } 
  if( command == SetClustCmd ) {
    myTarget->SetClustFile(newValue);
  } 
  if( command == DetMatCmd ) {
    myTarget->SetDetMate(newValue);
  }
  if( command == WalMatCmd ) {
    myTarget->SetWallsMate(newValue);
  }
  if( command == RotateArrayCmd ) {
    float e1, e2;
    sscanf( newValue, "%f %f", &e1, &e2);
    myTarget->SetThetaShift( ((G4double)e1)*deg );
    myTarget->SetPhiShift  ( ((G4double)e2)*deg );
  }
  if( command == RotatePrismaCmd ) {
    myTarget->SetThetaPrisma(RotatePrismaCmd->GetNewDoubleValue(newValue)*deg);
  }
  if( command == TranslateArrayCmd ) {
    myTarget->SetPosShift(TranslateArrayCmd->GetNew3VectorValue(newValue));
  }
  if( command == EnableCylCmd ) {
    myTarget->SetUseCylinder( EnableCylCmd->GetNewBoolValue(newValue) );
  }
  if( command == DisableCylCmd ) {
    myTarget->SetUseCylinder( DisableCylCmd->GetNewBoolValue(newValue) );
  }
  if( command == cryostatCmd ) {
    myTarget->SetCryostats();
  }
  if( command == DrawReadOutCmd ) {
    myTarget->SetDrawReadOut( DrawReadOutCmd->GetNewBoolValue(newValue) );
  }
  if( command == DontDrawReadOutCmd ) {
    myTarget->SetDrawReadOut( DontDrawReadOutCmd->GetNewBoolValue(newValue) );
  }
  if( command == EnableCapsulesCmd ) {
    myTarget->SetMakeCapsules( EnableCapsulesCmd->GetNewBoolValue(newValue) );
  }
  if( command == DisableCapsulesCmd ) {
    myTarget->SetMakeCapsules( DisableCapsulesCmd->GetNewBoolValue(newValue) );
  }
  if( command == SetStepCmd ) {
    myTarget->SetStep( SetStepCmd->GetNewIntValue(newValue) );
  }

}

