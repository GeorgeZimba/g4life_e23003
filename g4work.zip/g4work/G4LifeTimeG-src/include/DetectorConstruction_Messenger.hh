#ifndef DetectorConstruction_Messenger_h
#define DetectorConstruction_Messenger_h 1
#include "DetectorConstruction.hh"

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithAnInteger.hh"

class G4UIdirectory;
class G4UIcommand;
class G4UIcmdWithAString;
class DetectorConstruction;

class DetectorConstruction_Messenger: public G4UImessenger
{
public:
  
  DetectorConstruction_Messenger(DetectorConstruction*);
  ~DetectorConstruction_Messenger();
  
  void SetNewValue(G4UIcommand* ,G4String );
  
private:
  DetectorConstruction*   Detector;
  G4UIdirectory*          DetectorDir;   
  
  //  G4UIcmdWithoutParameter* TargetOnlyCmd;
  G4UIcmdWithAnInteger*      PTypeCmd;
  G4UIcmdWithoutParameter*   UseSeGACmd;
  G4UIcmdWithoutParameter*   UseGretinaCmd;
  G4UIcmdWithAString*        ShellCmd;
  G4UIcmdWithoutParameter*   RepCmd;
  G4UIcmdWithAString*        GeomFileCmd;
  G4UIcmdWithAString*        EulerFileCmd; //AR new in v4.3
  G4UIcmdWithoutParameter*   UpdateGeometryCmd;
  G4UIcmdWithoutParameter*   ShAddCmd; //AR new in v4.3

};

#endif



