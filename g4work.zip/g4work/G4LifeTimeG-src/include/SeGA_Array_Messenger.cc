#include "SeGA_Array_Messenger.hh"


SeGA_Array_Messenger::SeGA_Array_Messenger(SeGA_Array* SeGA):the_SeGA_Array(SeGA)
{ 
 
  SeGA_Array_Dir = new G4UIdirectory("/SeGA_Array/");
  SeGA_Array_Dir->SetGuidance("SeGA_Array control.");
  
  RepST = new G4UIcmdWithoutParameter("/SeGA_Array/ReportSegments",this);
  RepST->SetGuidance("Report segment coordinates");  

  RepCmd = new G4UIcmdWithoutParameter("/SeGA_Array/Report",this);
  RepCmd->SetGuidance("Report SeGA parameters");  

}



SeGA_Array_Messenger::~SeGA_Array_Messenger()
{
  
  delete SeGA_Array_Dir;
  delete RepST;
  delete RepCmd;
}


void SeGA_Array_Messenger::SetNewValue(G4UIcommand* command, G4String newValue)
{ 

  if( command == RepST )
   { the_SeGA_Array->ReportSegments();}
  
  if( command == RepCmd )
   { the_SeGA_Array->Report();}
}
