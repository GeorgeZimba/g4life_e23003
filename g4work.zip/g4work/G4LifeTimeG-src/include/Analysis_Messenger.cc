#include  "Analysis_Messenger.hh"
#include <sstream>


Analysis_Messenger::Analysis_Messenger(Analysis* A):Ana(A)
{
 
  AnaDir = new G4UIdirectory("/Analysis/");
  AnaDir->SetGuidance("Analysis control.");

  RepCmd = new G4UIcmdWithoutParameter("/Analysis/Report",this);
  RepCmd->SetGuidance("Report parameters for the Root tree");
  
  //AR Added for v4.3 -> Allowing to disable a Gretina Crystal
  GretDisCrysCmd = new G4UIcmdWithAnInteger("/Analysis/GretDisCrys",this);
  GretDisCrysCmd->SetGuidance("Number of the gretina crystal that was disabled.");
  GretDisCrysCmd->SetParameterName("choice",false);
  GretDisCrysCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  //AR Added for v4.3 -> Parameters in order to simulate Rob's Cascade Analysis
  CascadeAnalysisDir = new G4UIdirectory("/Analysis/CascadeAnalysis/");
  CascadeAnalysisDir->SetGuidance("Rob's Cascade Analysis Controls");
  
  CascadeAnalysisOnCmd = new G4UIcmdWithoutParameter("/Analysis/CascadeAnalysis/CascadeON",this);
  CascadeAnalysisOnCmd->SetGuidance("To use Rob's Cascade analysis method");

  CascadeAnalysisELowCmd = new G4UIcmdWithADouble("/Analysis/CascadeAnalysis/ELow",this);
  CascadeAnalysisELowCmd->SetGuidance("Low-energy limit for Cascade Analysis");
  CascadeAnalysisELowCmd->SetParameterName("choice",false);
  CascadeAnalysisELowCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  CascadeAnalysisEHighCmd = new G4UIcmdWithADouble("/Analysis/CascadeAnalysis/EHigh",this);
  CascadeAnalysisEHighCmd->SetGuidance("High-energy limit for Cascade Analysis");
  CascadeAnalysisEHighCmd->SetParameterName("choice",false);
  CascadeAnalysisEHighCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  CascadeAnalysisETrueCmd = new G4UIcmdWithADouble("/Analysis/CascadeAnalysis/ETrue",this);
  CascadeAnalysisETrueCmd->SetGuidance("True energy of state considered for Cascade Analysis");
  CascadeAnalysisETrueCmd->SetParameterName("choice",false);
  CascadeAnalysisETrueCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  // Acceptance 
  AccDir = new G4UIdirectory("/Analysis/Acceptance/");
  AccDir->SetGuidance("Acceptance control for the outgoing beam.");

  ACConCmd = new G4UIcmdWithoutParameter("/Analysis/Acceptance/ACC_ON",this);
  ACConCmd->SetGuidance("Turn on S800 acceptance response.");  

  AThLCmd = new G4UIcmdWithADoubleAndUnit("/Analysis/Acceptance/ThetaLow",this);
  AThLCmd->SetGuidance("Low theta limit for heavy-ion acceptance.");
  AThLCmd->SetParameterName("choice",false);
  AThLCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  AThHCmd = new G4UIcmdWithADoubleAndUnit("/Analysis/Acceptance/ThetaHigh",this);
  AThHCmd->SetGuidance("High theta limit for heavy-ion acceptance.");
  AThHCmd->SetParameterName("choice",false);
  AThHCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ADLCmd = new G4UIcmdWithADouble("/Analysis/Acceptance/DLow",this);
  ADLCmd->SetGuidance("Low d limit for heavy-ion acceptance.");
  ADLCmd->SetParameterName("choice",false);
  ADLCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ADHCmd = new G4UIcmdWithADouble("/Analysis/Acceptance/DHigh",this);
  ADHCmd->SetGuidance("High d limit for heavy-ion acceptance.");
  ADHCmd->SetParameterName("choice",false);
  ADHCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  // Doppler Correction Commands
  DopDir = new G4UIdirectory("/Results/DopplerC/");
  DopDir->SetGuidance("Root control for Doppler corrections using simulated data.");

  // Ion Axis
  TDUZACmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/ZAxisDirection",this);
  TDUZACmd->SetGuidance("Use the z axis direction for doppler corrections.");

  TDUDACmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/TrueDecayIonDirection",this);
  TDUDACmd->SetGuidance("Use the ion direction at the decay for doppler corrections.");

  TDUBIACmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseIncomingBeamDirection",this);
  TDUBIACmd->SetGuidance("Use the incoming beam direction for doppler corrections.");

  TDUTBACmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseTargetBackIonDirection",this);
  TDUTBACmd->SetGuidance("Use the ion direction at the back of the target for doppler corrections.");

  TDUDBACmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseDegraderBackIonDirection",this);
  TDUDBACmd->SetGuidance("Use the ion direction at the back of the target for doppler corrections.");

  TDUSBACmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseStopperBackIonDirection",this);
  TDUSBACmd->SetGuidance("Use the ion direction at the back of the target for doppler corrections.");

  // Ion Position
  TDUTDCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseTrueDecayPos",this);
  TDUTDCmd->SetGuidance("Use the simulated true decay position for doppler corrections.");

  TDUTCCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseTargetCenterPos",this);
  TDUTCCmd->SetGuidance("Use target center position for doppler corrections.");

  TDUDCCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseDegraderCenterPos",this);
  TDUDCCmd->SetGuidance("Use degrader center position for doppler corrections.");

  TDUSCCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseStopperCenterPos",this);
  TDUSCCmd->SetGuidance("Use stopper center position for doppler corrections.");

  TDUSDCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseSetDopplerPos",this);
  TDUSDCmd->SetGuidance("Use user-set position for doppler corrections.");

  // Gamma Position
  TDUFICmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseTrueFirstInteractionPos",this);
  TDUFICmd->SetGuidance("Use true simulated first interaction position for doppler corrections.");

  TDULSCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseLargestEnergySegmentHit",this);
  TDULSCmd->SetGuidance("Use the center of a segment with the largest energy deposit as a first interaction position for doppler corrections.");

  // Gretina Position
  GrGammaPosCmd = new G4UIcmdWithADoubleAndUnit("/Analysis/DopplerC/GretinaGammaIntPosSigma",this);
  GrGammaPosCmd->SetGuidance("Set average deviation in position reconstruction for Gretina");
  GrGammaPosCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  //new in v4.2 Addback Sphere Distance
  // Addback Sphere Max Distance
  GrGammaAddCmd = new G4UIcmdWithADoubleAndUnit("/Analysis/DopplerC/SphereAddbackMaxDist",this);
  GrGammaAddCmd->SetGuidance("Set the distance between the two points which will allow for summing when using Addback Sphere.");
  GrGammaAddCmd->AvailableForStates(G4State_PreInit,G4State_Idle); 

  // Beta
  TDUTBCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseTrueDecayBeta",this);
  TDUTBCmd->SetGuidance("Use true simulated beta  for doppler corrections.");

  TDUSBCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseUserSetBeta",this);
  TDUSBCmd->SetGuidance("Use user-set beta for doppler corrections.");

  TDUBBCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseTargetBackBeta",this);
  TDUBBCmd->SetGuidance("Use simulated beta at the back of the target  for doppler corrections.");

  TDUDBBCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseDegraderBackBeta",this);
  TDUDBBCmd->SetGuidance("Use simulated beta at the back of the target  for doppler corrections.");

  TDUSBBCmd = new G4UIcmdWithoutParameter("/Analysis/DopplerC/UseStopperBackBeta",this);
  TDUSBBCmd->SetGuidance("Use simulated beta at the back of the stopper  for doppler corrections.");


  // SeGA FWHM Simulation
  TDFonCmd = new G4UIcmdWithoutParameter("/Analysis/FWHM_ON",this);
  TDFonCmd->SetGuidance("Turn on Gamma detector's FWHM response.");  

  // SeGA Tracking
  STRCmd = new G4UIcmdWithoutParameter("/Analysis/SeGA_TRACKING_ON",this);
  STRCmd->SetGuidance("Turn on SeGA gamma tracking.");  

  // Gretina Tracking
  GTRCmd = new G4UIcmdWithoutParameter("/Analysis/GRETINA_TRACKING_ON",this);
  GTRCmd->SetGuidance("Turn on Gretina gamma tracking.");  

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

Analysis_Messenger::~Analysis_Messenger()
{
  //AR Added for v4.3 -> Allowing to disable a Gretina Crystal
  delete GretDisCrysCmd;

  //AR Added for v4.3 -> Parameters in order to simulate Rob's Cascade Analysis
  delete CascadeAnalysisOnCmd;
  delete CascadeAnalysisELowCmd;
  delete CascadeAnalysisEHighCmd;
  delete CascadeAnalysisETrueCmd;

  delete RepCmd;
  delete ACConCmd;
  delete AThHCmd;
  delete ADLCmd;
  delete ADHCmd;

  delete TDUZACmd;
  delete TDUDACmd;
  delete TDUBIACmd;

  delete TDUTBACmd;
  delete TDUDBACmd;
  delete TDUSBACmd;

  delete TDUTDCmd;
  delete TDUTCCmd;
  delete TDUDCCmd;
  delete TDUSCCmd;
  delete TDUSDCmd;
  delete TDUFICmd;
  delete TDULSCmd;
  delete TDUTBCmd;
  delete TDUSBCmd;
  delete TDUBBCmd;
  delete TDUDBBCmd;
  delete TDUSBBCmd;

  delete GrGammaPosCmd;
  
  delete GrGammaAddCmd;
    
  delete STRCmd;
  delete GTRCmd;
  
  delete TDFonCmd;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void Analysis_Messenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
  
  if( command == RepCmd )
	 { Ana->Report();}

  //AR Added for v4.3 -> Allowing to disable a Gretina Crystal
  if( command == GretDisCrysCmd)
    { Ana->Set_GretDisCrys(GretDisCrysCmd->GetNewIntValue(newValue));}

  //AR Added for v4.3 -> Parameters in order to simulate Rob's Cascade Analysis
  if( command == CascadeAnalysisOnCmd)
    { Ana->Set_CascadeAnalysisOn(true);}
  if( command == CascadeAnalysisELowCmd)
    { Ana->Set_CascadeAnalysisElow(CascadeAnalysisELowCmd->GetNewDoubleValue(newValue));}
  if( command == CascadeAnalysisEHighCmd)
    { Ana->Set_CascadeAnalysisEHigh(CascadeAnalysisEHighCmd->GetNewDoubleValue(newValue));}
  if( command == CascadeAnalysisETrueCmd)
    { Ana->Set_CascadeAnalysisETrue(CascadeAnalysisETrueCmd->GetNewDoubleValue(newValue));}
  
  // S800 Acceptance
  if( command == ACConCmd )
    { Ana->Set_S800_Accept(true);}  
  if( command == AThLCmd )
    { Ana->SetAcceptanceThetaLow(AThLCmd->GetNewDoubleValue(newValue));}  
  if( command == AThHCmd )
    { Ana->SetAcceptanceThetaHigh(AThHCmd->GetNewDoubleValue(newValue));}  
  if( command == ADLCmd )
    { Ana->SetAcceptanceDLow(ADLCmd->GetNewDoubleValue(newValue));}  
  if( command == ADHCmd )
    { Ana->SetAcceptanceDHigh(ADHCmd->GetNewDoubleValue(newValue));}

  // Ion Pos for Doppler Correction
  if( command ==  TDUTCCmd)
	 {Ana->Set_DC_IonPos(0);}
  if( command ==  TDUTDCmd)
	 {Ana->Set_DC_IonPos(1);}
  if( command ==  TDUSDCmd)
	 {Ana->Set_DC_IonPos(2);}
  if( command ==  TDUDCCmd)
	 {Ana->Set_DC_IonPos(3);}
  if( command ==  TDUSCCmd)
	 {Ana->Set_DC_IonPos(4);}
  // Ion Axis for Doppler Correction
  if( command ==  TDUZACmd)
	 {Ana->Set_DC_IonAxis(0);}
  if( command ==  TDUBIACmd)
	 {Ana->Set_DC_IonAxis(1);}
  if( command ==  TDUDACmd)
	 {Ana->Set_DC_IonAxis(2);}
  if( command ==  TDUTBACmd)
	 {Ana->Set_DC_IonAxis(3);}
  if( command ==  TDUDBACmd)
	 {Ana->Set_DC_IonAxis(4);}
  if( command ==  TDUSBACmd)
	 {Ana->Set_DC_IonAxis(4);}

  // Beta for Doppler Correction
  if( command ==  TDUSBCmd)
	 {Ana->Set_DC_Beta(0);}
  if( command ==  TDUBBCmd)
	 {Ana->Set_DC_Beta(1);}
  if( command ==  TDUTBCmd)
	 {Ana->Set_DC_Beta(2);}
  if( command ==  TDUDBBCmd)
	 {Ana->Set_DC_Beta(3);}
  if( command ==  TDUSBBCmd)
	 {Ana->Set_DC_Beta(4);}

  // Gamma Position
  if( command ==  TDULSCmd)
	 {Ana->Set_DC_GammaPos(0);}
  if( command ==  TDUFICmd)
	 {
		// Requires Tracking
		Ana->Set_SeGATracking(1);
		Ana->Set_GretinaTracking(1);
		// Then Set the flag
		Ana->Set_DC_GammaPos(1);
	 }
  if( command == GrGammaPosCmd)
	 {
		Ana->Set_GretinaPosSigma(GrGammaPosCmd->GetNewDoubleValue(newValue));
	 }
  if( command == GrGammaAddCmd)
	 {
		Ana->Set_GretinaAddBackSphereDist(GrGammaAddCmd->GetNewDoubleValue(newValue));
	 }	 
	 

  // Tracking
  if( command ==  STRCmd)
	 {Ana->Set_SeGATracking(1);}
  if( command ==  GTRCmd)
	 {Ana->Set_GretinaTracking(1);}
  
  // SeGA Resolution
  if( command ==  TDFonCmd)
	 {Ana->Set_FWHM(true);}

}
