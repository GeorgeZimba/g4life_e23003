#include "DetectorConstruction_Messenger.hh"
#include <sstream>

#include "G4UIdirectory.hh"
#include "G4UIcommand.hh"
#include "G4UIparameter.hh"
#include "G4UIcmdWithAString.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction_Messenger::DetectorConstruction_Messenger(DetectorConstruction* D):Detector(D)
{
 
  DetectorDir = new G4UIdirectory("/Detector/");
  DetectorDir->SetGuidance("histograms control");

  PTypeCmd = new G4UIcmdWithAnInteger("/Detector/PlungerGeometry",this);
  PTypeCmd->SetGuidance("Set the geomtry of the Plunger device");
  PTypeCmd->SetGuidance("0 for target only");
  PTypeCmd->SetGuidance("1 for Standaerd Plunger (Target+Degrader)");
  PTypeCmd->SetGuidance("2 for Diffrential plunger (Target+Degrader+Stopper) ");
  PTypeCmd->SetParameterName("choice",false);
  PTypeCmd->AvailableForStates(G4State_PreInit,G4State_Idle);


  UseSeGACmd  = new G4UIcmdWithoutParameter("/Detector/UseSeGA",this);
  UseSeGACmd->SetGuidance("Use Sega Detector");

  UseGretinaCmd  = new G4UIcmdWithoutParameter("/Detector/UseGretina",this);
  UseGretinaCmd->SetGuidance("Use Gretina Detector");


  ShellCmd = new G4UIcmdWithAString("/Detector/Shell", this);
  ShellCmd->SetGuidance("Construct the GRETINA mounting shell (full/north/south).");
  ShellCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  GeomFileCmd=new G4UIcmdWithAString("/Detector/GeometryFile",this);
  GeomFileCmd->SetGuidance("Set Geometry Filename");
  GeomFileCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  //AR New in v4.3 -> Possibility to use a different aeuler file
  EulerFileCmd=new G4UIcmdWithAString("/Detector/EulerFile",this); 
  EulerFileCmd->SetGuidance("Set Geometry Filename");
  EulerFileCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  UpdateGeometryCmd  = new G4UIcmdWithoutParameter("/Detector/UpdateGeometry",this);
  UpdateGeometryCmd->SetGuidance("Update Geometry");
  UpdateGeometryCmd->AvailableForStates(G4State_Idle);

  //AR New in v4.3 -> To add cylindrical shield
  ShAddCmd  = new G4UIcmdWithoutParameter("/Detector/Shield",this);
  ShAddCmd->SetGuidance("To Add Cylindrical Shield as in Rob's Cascade Analysis");

}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

DetectorConstruction_Messenger::~DetectorConstruction_Messenger()
{
  //  delete TargetOnlyCmd;
  delete PTypeCmd;
  delete UseSeGACmd;
  delete UseGretinaCmd;
  delete ShellCmd;
  delete UpdateGeometryCmd;
 
  delete GeomFileCmd;
  
  //AR New in v4.3 -> Used to give different aeuler file as input
  delete EulerFileCmd;

  //AR New in v4.3 -> To add cylindrical shield
  delete ShAddCmd;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void DetectorConstruction_Messenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
  if (command == PTypeCmd){
	 Detector->SetPlungerType(PTypeCmd->GetNewIntValue(newValue));
  }
  if (command == UseSeGACmd){
	 Detector->SetUseSeGA(true);
  }
  if (command == UseGretinaCmd){
    Detector->SetUseGretina(true);
  }
  if( command == ShellCmd ) {
    Detector->SetShellStatus(newValue);
	} 
  if (command == GeomFileCmd){
    Detector->SetGeomFileName(newValue);
  }
  //AR New in v4.3 -> Used to give different aeuler file as input
  if (command == EulerFileCmd){
    Detector->SetEulerFileName(newValue);
  }  
  if (command == UpdateGeometryCmd){
    Detector->UpdateGeometry();
  }
  //AR New in v4.3 -> To add cylindrical shield
  if (command == ShAddCmd){
    Detector->SetAddShield(true);
  }
}
