#include "SeGA_Detector_Messenger.hh"


SeGA_Detector_Messenger::SeGA_Detector_Messenger(SeGA_Detector* SD)
:SeGADet(SD)
{ 
 
  SeGADir = new G4UIdirectory("/SeGA/");
  SeGADir->SetGuidance("SeGA control.");

  SeGADetDir = new G4UIdirectory("/SeGA/Det/");
  SeGADetDir->SetGuidance("SeGA detector control.");

 //  SeGADetPosDir = new G4UIdirectory("/SeGA/Det/Pos/");
//   SeGADetPosDir->SetGuidance("SeGA detector position control.");

//   ThetaCmd = new G4UIcmdWithADoubleAndUnit("/SeGA/Det/Pos/Theta",this);
//   ThetaCmd->SetGuidance("Select theta angle for the detector");
//   ThetaCmd->SetParameterName("Theta",false);
//   ThetaCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

//   PhiCmd = new G4UIcmdWithADoubleAndUnit("/SeGA/Det/Pos/Phi",this);
//   PhiCmd->SetGuidance("Select phi angle for the detector");
//   PhiCmd->SetParameterName("Phi",false);
//   PhiCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

//   ZCmd = new G4UIcmdWithADoubleAndUnit("/SeGA/Det/Pos/Z",this);
//   ZCmd->SetGuidance("Select Z shift for the detector");
//   ZCmd->SetParameterName("Z",false);
//   ZCmd->AvailableForStates(G4State_PreInit,G4State_Idle);


//   RCmd = new G4UIcmdWithADoubleAndUnit("/SeGA/Det/Pos/R",this);
//   RCmd->SetGuidance("Select R, the distance from the SeGA center for the detector center");
//   RCmd->SetParameterName("R",false);
//   RCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  RepCmd = new G4UIcmdWithoutParameter("/SeGA/Det/Report",this);
  RepCmd->SetGuidance("Report SeGA detector parameters");  

  SeGADetFWHMDir = new G4UIdirectory("/SeGA/Det/FWHM/");
  SeGADetFWHMDir->SetGuidance("SeGA detector FWHM control.");

  FCmd = new G4UIcmdWithADouble("/SeGA/Det/FWHM/F",this);
  FCmd->SetGuidance("Set Radware FWHM F parameter ");
  FCmd->SetParameterName("Radware F",false);
  FCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  GCmd = new G4UIcmdWithADouble("/SeGA/Det/FWHM/G",this);
  GCmd->SetGuidance("Set Radware FWHM G parameter ");
  GCmd->SetParameterName("Radware G",false);
  GCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  HCmd = new G4UIcmdWithADouble("/SeGA/Det/FWHM/H",this);
  HCmd->SetGuidance("Set Radware FWHM H parameter ");
  HCmd->SetParameterName("Radware H",false);
  HCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
}



SeGA_Detector_Messenger::~SeGA_Detector_Messenger()
{
  delete SeGADir;
  delete SeGADetDir;
  delete SeGADetPosDir;
  delete SeGADetFWHMDir;
  delete ThetaCmd;
  delete PhiCmd;
  delete RCmd;
  delete RepCmd;
  delete FCmd;
  delete GCmd;
  delete HCmd;
  delete ZCmd;
}


void SeGA_Detector_Messenger::SetNewValue(G4UIcommand* command,G4String newValue)
{ 
 //  if( command == ThetaCmd )
//    { SeGADet->setTheta(PhiCmd->GetNewDoubleValue(newValue));}
//   if( command == PhiCmd )
//    { SeGADet->setPhi(PhiCmd->GetNewDoubleValue(newValue));}
//   if( command == RCmd )
//    { SeGADet->setR(RCmd->GetNewDoubleValue(newValue));}
  if( command == FCmd )
   { SeGADet->setF(FCmd->GetNewDoubleValue(newValue));}
  if( command == GCmd )
   { SeGADet->setG(GCmd->GetNewDoubleValue(newValue));}
  if( command == HCmd )
   { SeGADet->setH(HCmd->GetNewDoubleValue(newValue));}
//  if( command == ZCmd )
//    { SeGADet->setZ(ZCmd->GetNewDoubleValue(newValue));}
  if( command == RepCmd )
   { SeGADet->Report();}


}

