#include "Plunger_Messenger.hh"


Plunger_Messenger::Plunger_Messenger(Plunger* Plun)
:aPlunger(Plun)
{ 
  PlungerDir = new G4UIdirectory("/Plunger/");
  PlungerDir->SetGuidance("Plunger control.");
 
  DegraderDir = new G4UIdirectory("/Plunger/Degrader/");
  DegraderDir->SetGuidance("Degrader control.");

  TargetDir = new G4UIdirectory("/Plunger/Target/");
  TargetDir->SetGuidance("Target control.");

  StopperDir = new G4UIdirectory("/Plunger/Stopper/");
  StopperDir->SetGuidance("Stopper control.");

  PosCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Z_Shift",this);
  PosCmd->SetGuidance("Set the shift of the plunger along the Z axis");
  PosCmd->SetParameterName("choice",false);
  PosCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SepCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/SeparationTarget",this);
  SepCmd->SetGuidance("Set the target/degrader separation");
  SepCmd->SetParameterName("choice",false);
  SepCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  RatCmd = new G4UIcmdWithADouble("/Plunger/Ratio",this);
  RatCmd->SetGuidance("Set the ratio of target/degrader reactions");
  RatCmd->SetParameterName("choice",false);
  RatCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  Sep2Cmd = new G4UIcmdWithADoubleAndUnit("/Plunger/SeparationStopper",this);
  Sep2Cmd->SetGuidance("Set the stopper/degrader separation");
  Sep2Cmd->SetParameterName("choice",false);
  Sep2Cmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  Rat2Cmd = new G4UIcmdWithADouble("/Plunger/Ratio2",this);
  Rat2Cmd->SetGuidance("Set the ratio of stopper/degrader reactions");
  Rat2Cmd->SetParameterName("choice",false);
  Rat2Cmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  MatDegCmd = new G4UIcmdWithAString("/Plunger/Degrader/Material",this);
  MatDegCmd->SetGuidance("Select material for the degrader.");
  MatDegCmd->SetParameterName("choice",false);
  MatDegCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ScDDegCmd = new G4UIcmdWithADouble("/Plunger/Degrader/ScaleDensity",this);
  ScDDegCmd->SetGuidance("Scale degrader density/stopping powers.");
  ScDDegCmd->SetParameterName("choice",false);
  ScDDegCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  XDegCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Degrader/X_length",this);
  XDegCmd->SetGuidance("Select the X length for the degrader");
  XDegCmd->SetParameterName("choice",false);
  XDegCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  YDegCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Degrader/Y_length",this);
  YDegCmd->SetGuidance("Select the Y length for the degrader");
  YDegCmd->SetParameterName("choice",false);
  YDegCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ZDegCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Degrader/Thickness",this);
  ZDegCmd->SetGuidance("Select the thickness for the degrader");
  ZDegCmd->SetParameterName("choice",false);
  ZDegCmd->AvailableForStates(G4State_PreInit,G4State_Idle);  

  NSDegCmd = new G4UIcmdWithAnInteger("/Plunger/Degrader/NStep",this);
  NSDegCmd->SetGuidance("Select the number of steps in the degrader");
  NSDegCmd->SetParameterName("choice",false);
  NSDegCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  MatTarCmd = new G4UIcmdWithAString("/Plunger/Target/Material",this);
  MatTarCmd->SetGuidance("Select material for the target.");
  MatTarCmd->SetParameterName("choice",false);
  MatTarCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ScDTarCmd = new G4UIcmdWithADouble("/Plunger/Target/ScaleDensity",this);
  ScDTarCmd->SetGuidance("Scale target density/stopping powers.");
  ScDTarCmd->SetParameterName("choice",false);
  ScDTarCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  XTarCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Target/X_length",this);
  XTarCmd->SetGuidance("Select the X length for the target");
  XTarCmd->SetParameterName("choice",false);
  XTarCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  YTarCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Target/Y_length",this);
  YTarCmd->SetGuidance("Select the Y length for the target");
  YTarCmd->SetParameterName("choice",false);
  YTarCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ZTarCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Target/Thickness",this);
  ZTarCmd->SetGuidance("Select the thickness for the target");
  ZTarCmd->SetParameterName("choice",false);
  ZTarCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  NSTarCmd = new G4UIcmdWithAnInteger("/Plunger/Target/NStep",this);
  NSTarCmd->SetGuidance("Select the number of steps in the target");
  NSTarCmd->SetParameterName("choice",false);
  NSTarCmd->AvailableForStates(G4State_PreInit,G4State_Idle);  

  MatStoCmd = new G4UIcmdWithAString("/Plunger/Stopper/Material",this);
  MatStoCmd->SetGuidance("Select material for the stopper.");
  MatStoCmd->SetParameterName("choice",false);
  MatStoCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ScDStoCmd = new G4UIcmdWithADouble("/Plunger/Stopper/ScaleDensity",this);
  ScDStoCmd->SetGuidance("Scale stopper density/stopping powers.");
  ScDStoCmd->SetParameterName("choice",false);
  ScDStoCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
  XStoCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Stopper/X_length",this);
  XStoCmd->SetGuidance("Select the X length for the stopper");
  XStoCmd->SetParameterName("choice",false);
  XStoCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  YStoCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Stopper/Y_length",this);
  YStoCmd->SetGuidance("Select the Y length for the target");
  YStoCmd->SetParameterName("choice",false);
  YStoCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ZStoCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Stopper/Thickness",this);
  ZStoCmd->SetGuidance("Select the thickness for the stopper");
  ZStoCmd->SetParameterName("choice",false);
  ZStoCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  NSStoCmd = new G4UIcmdWithAnInteger("/Plunger/Stopper/NStep",this);
  NSStoCmd->SetGuidance("Select the number of steps in the stopper");
  NSStoCmd->SetParameterName("choice",false);
  NSStoCmd->AvailableForStates(G4State_PreInit,G4State_Idle);  

  RepCmd = new G4UIcmdWithoutParameter("/Plunger/Report",this);
  RepCmd->SetGuidance("Report plunger parameters");

  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  ShieldDir = new G4UIdirectory("/Plunger/Shield/");
  ShieldDir->SetGuidance("Shield control.");
  
  ShMatCmd = new G4UIcmdWithAString("/Plunger/Shield/Material",this);
  ShMatCmd->SetGuidance("Select material for the shield.");
  ShMatCmd->SetParameterName("choice",false);
  ShMatCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ShPosCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Shield/UpstreamPos",this);
  ShPosCmd->SetGuidance("Select the position for the shield (Upstream Face Position)");
  ShPosCmd->SetParameterName("choice",false);
  ShPosCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ShRminCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Shield/Rmin",this);
  ShRminCmd->SetGuidance("Select the inner radius dimension");
  ShRminCmd->SetParameterName("choice",false);
  ShRminCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ShRmaxCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Shield/Rmax",this);
  ShRmaxCmd->SetGuidance("Select the outer radius dimension");
  ShRmaxCmd->SetParameterName("choice",false);
  ShRmaxCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  ShLenCmd = new G4UIcmdWithADoubleAndUnit("/Plunger/Shield/Len",this);
  ShLenCmd->SetGuidance("Select the length of the cylinder");
  ShLenCmd->SetParameterName("choice",false);
  ShLenCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
}



Plunger_Messenger::~Plunger_Messenger()
{
  delete RatCmd;
  delete SepCmd;
  delete Rat2Cmd;
  delete Sep2Cmd;
  delete PosCmd;
  delete XDegCmd;
  delete YDegCmd;
  delete ZDegCmd;
  delete MatDegCmd;
  delete NSDegCmd;
  delete XTarCmd;
  delete YTarCmd;
  delete ZTarCmd;
  delete MatTarCmd;
  delete NSTarCmd;
  delete XStoCmd;
  delete YStoCmd;
  delete ZStoCmd;
  delete MatStoCmd;
  delete NSStoCmd;
  delete ScDTarCmd;
  delete ScDDegCmd;
  delete ScDStoCmd;
  delete TargetDir;
  delete DegraderDir;
  delete StopperDir;
  delete RepCmd;
  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  delete ShMatCmd;
  delete ShPosCmd;
  delete ShRminCmd;
  delete ShRmaxCmd;
  delete ShLenCmd;
}


void Plunger_Messenger::SetNewValue(G4UIcommand* command,G4String newValue)
{
  if( command == RatCmd )
   { aPlunger->SetRatio(RatCmd->GetNewDoubleValue(newValue));} 
  if( command == Rat2Cmd )
   { aPlunger->SetRatio2(Rat2Cmd->GetNewDoubleValue(newValue));} 
  if( command == SepCmd )
   { aPlunger->SetSeparation(SepCmd->GetNewDoubleValue(newValue));} 
  if( command == Sep2Cmd )
   { aPlunger->SetSeparation2(Sep2Cmd->GetNewDoubleValue(newValue));} 
  if( command == PosCmd )
   { aPlunger->SetPosZ(PosCmd->GetNewDoubleValue(newValue));} 
 if( command == ScDDegCmd )
   { aPlunger->ScaleDegDensity(ScDDegCmd->GetNewDoubleValue(newValue));} 
  if( command == MatDegCmd )
   { aPlunger->SetDegMaterial(newValue);} 
  if( command == XDegCmd )
   { aPlunger->SetDegX(XDegCmd->GetNewDoubleValue(newValue));}
  if( command == YDegCmd )
   { aPlunger->SetDegY(YDegCmd->GetNewDoubleValue(newValue));}
  if( command == ZDegCmd )
   { aPlunger->SetDegZ(ZDegCmd->GetNewDoubleValue(newValue));}
  if( command == NSDegCmd )
   { aPlunger->SetNstepDeg(NSDegCmd->GetNewIntValue(newValue));}
 if( command == ScDTarCmd )
   { aPlunger->ScaleTarDensity(ScDTarCmd->GetNewDoubleValue(newValue));} 
  if( command == MatTarCmd )
   { aPlunger->SetTarMaterial(newValue);} 
  if( command == XTarCmd )
   { aPlunger->SetTarX(XTarCmd->GetNewDoubleValue(newValue));}
  if( command == YTarCmd )
   { aPlunger->SetTarY(YTarCmd->GetNewDoubleValue(newValue));}
  if( command == ZTarCmd )
   { aPlunger->SetTarZ(ZTarCmd->GetNewDoubleValue(newValue));}
  if( command == NSTarCmd )
   { aPlunger->SetNstepTar(NSTarCmd->GetNewIntValue(newValue));}
 if( command == ScDStoCmd )
   { aPlunger->ScaleStoDensity(ScDStoCmd->GetNewDoubleValue(newValue));} 
  if( command == MatStoCmd )
   { aPlunger->SetStoMaterial(newValue);} 
  if( command == XStoCmd )
   { aPlunger->SetStoX(XStoCmd->GetNewDoubleValue(newValue));}
  if( command == YStoCmd )
   { aPlunger->SetStoY(YStoCmd->GetNewDoubleValue(newValue));}
  if( command == ZStoCmd )
   { aPlunger->SetStoZ(ZStoCmd->GetNewDoubleValue(newValue));}
  if( command == NSStoCmd )
   { aPlunger->SetNstepSto(NSStoCmd->GetNewIntValue(newValue));}
  if( command == RepCmd )
   { aPlunger->Report();}
  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  if( command == ShMatCmd ){
    aPlunger->SetShMaterial(newValue);
  } 
  if( command == ShPosCmd ){
    aPlunger->SetShPos(ShPosCmd->GetNewDoubleValue(newValue));
  }
  if( command == ShRminCmd ){
    aPlunger->SetShRmin(ShRminCmd->GetNewDoubleValue(newValue));
  }
  if( command == ShRmaxCmd ){
    aPlunger->SetShRmax(ShRmaxCmd->GetNewDoubleValue(newValue));
  }
  if( command == ShLenCmd ){
    aPlunger->SetShLen(ShLenCmd->GetNewDoubleValue(newValue));
  }
}

