#include "SeGA_Detector.hh"

//#define DEBUG
SeGA_Detector::SeGA_Detector(G4LogicalVolume* experimentalHall_log)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif  
  expHall_log=experimentalHall_log;
  HpGe = new G4Material("HpGe", 32., 72.61*g/mole, 5.323*g/cm3);
  //LR Cu =   new G4Material("Cu", 29., 63.546*g/mole, 8.920*g/cm3);
  Al =   new G4Material("Al", 13., 26.982*g/mole, 2.70*g/cm3);   //LR
  preampMat = new G4Material("preampMat", 13., 26.982*g/mole, 1.35*g/cm3);   //LR  (Air, copper, and aluminum?)

  // dead layer thicknesses
  iDLThickness = 0.40*cm;                         //LR
  oDLThickness = 0.030*cm;                        //LR

  // crystal dimensions
  //LR Length=3.6*cm;
  Length=4.025*cm;                          //LR
  innerRadius =0.*cm;
  //LR outerRadius =3.52*cm;                  //LR (Dirk)
  outerRadius = 3.387*cm - oDLThickness;      //LR (Wil)
  //LR outerRadius =3.29*cm;                  //LR (Lew)
  //LR outerRadius =3.355*cm;                 //LR (Lew)
  //LR outerRadius =3.25*cm;                  //LR (Darren)
  fingerRadius=0.5*cm;

  // dead layer dimensions
  iDLinnerRadius = fingerRadius;                 //LR
  //DLouterRadius = DLinnerRadius+0.03*cm;         //LR (Dirk)
  iDLouterRadius = iDLinnerRadius+iDLThickness;  //LR (Lew)
  oDLinnerRadius = outerRadius;                  //LR
  oDLouterRadius = outerRadius+oDLThickness;     //LR

  // can dimensions
  iCanThickness   = 0.05*cm;
  iCanOuterRadius = 3.73*cm;                         //LR
  iCanInnerRadius = iCanOuterRadius-iCanThickness;   //LR
  iCanLength      = Length;                          //LR

  oCanThickness   = 0.1*cm; // 
  oCanOuterRadius = 4.325*cm;                      //LR (Dirk)
  oCanInnerRadius = oCanOuterRadius-oCanThickness; //LR 
  //oCanLength      = 4.375*cm;                    //LR
  oCanLength      = 9.65*cm;                       //LR (approx. from drawing)
  CapToCristal    = 0.7*cm;
  oCanOffset      = oCanLength - Length - CapToCristal-oCanThickness;  //LR (0.7*cm gives overlaps in the 37 degree ring)

  preampRadius = oCanInnerRadius-1*um;            //LR
  preampLength = oCanLength - Length - CapToCristal/2.0*cm; //LR

  neckRadius = 3.33/2.0*cm;   //LR (approx. from drawing)
  neckLength = 14.47/2.0*cm;  //LR (approx. from drawing)
  neckOffset.setX(-1*(oCanOuterRadius + neckLength*sin(45.0*deg) + neckRadius*cos(45.0*deg))); //LR 
  neckOffset.setY(0.0*cm);                                                     //LR
  neckOffset.setZ(9.32*cm + neckLength*cos(45.0*deg));                         //LR (approx. from drawing)

  cryoThickness = 0.4*cm;                                                                           //LR (guess)
  cryoOuterRadius = 23.06/2.0*cm;                                                                   //LR (approx. from drawing)
  cryoInnerRadius = cryoOuterRadius - cryoThickness;                                                //LR (approx. from drawing)
  cryoBaseThickness = 1.5/2.0*cm;                                                                   //LR (guess)
  cryoBaseOffset.setX(neckOffset.x() - neckLength*sin(45.0*deg) - cryoBaseThickness*sin(45.0*deg)); //LR
  cryoBaseOffset.setY(0.0*cm);                                                                      //LR
  cryoBaseOffset.setZ(neckOffset.z() + neckLength*cos(45.0*deg) + cryoBaseThickness*cos(45.0*deg)); //LR

  cryoLength = 34.60/2.0*cm;                                                                        //LR (approx. from drawing)
  cryoOffset.setX(cryoBaseOffset.x() - cryoBaseThickness*sin(45.0*deg) - cryoLength*sin(45.0*deg)); //LR
  cryoOffset.setY(0.0*cm);                                                                          //LR
  cryoOffset.setZ(cryoBaseOffset.z() + cryoBaseThickness*cos(45.0*deg) + cryoLength*cos(45.0*deg)); //LR

  startAngle      = 45.*deg;
  spanningAngle   = 360.*deg;
  Orientation     = 1;

  rd=24*cm;
  thetad=37*deg;
  phid=0*deg;
  
  ZShift.setX(0);
  ZShift.setY(0);
  ZShift.setZ(0);
  F=3.;
  G=2.;
  H=0.;

  thr_center=50*keV;
  thr_width=50*keV;
  DopplerOn();

  // Initialize the physical objects to NULL
  detector_phys = NULL;	 
  iCan_phys = NULL;
  oCan_phys = NULL;
  iDL_phys = NULL;
  oDL_phys = NULL;
  preamp_phys = NULL;
  neck_phys = NULL;
  cryoBase_phys = NULL;
  cryo_phys = NULL;

}


SeGA_Detector::~SeGA_Detector()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif  
}

G4VPhysicalVolume* SeGA_Detector::Construct(G4int num,G4int ring,G4int orient, G4double th,G4double ph,G4double r,G4double z,G4double Cap)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
  cout << " r " << r <<  " theta " << th <<  " phi " << ph << " z " << z << endl;
#endif  
  RingID=ring;
  Number=num;
  Orientation=orient;
  thetad=th;
  phid=ph;
  rd=r;
  zd=z;
  CapToCristal = Cap;
  ZShift.setZ(z+Orientation*(Length+CapToCristal+oCanThickness));
  
  // Should think of a better solution
  preampLength = oCanLength - Length - CapToCristal/2.0; //LR

 // Material surrounding the crystal
  iCan = new G4Tubs("iCan",iCanInnerRadius,iCanOuterRadius,iCanLength,startAngle,spanningAngle); //LR

  iCan_log = new G4LogicalVolume(iCan,Al,"iCan_log",0,0,0);                                      //LR

  //LR oCan = new G4Tubs("oCan",oCanInnerRadius,oCanOuterRadius,oCanLength,startAngle,spanningAngle); //LR
  oCanFull   = new G4Tubs("oCanFull",  0.0,oCanOuterRadius,oCanLength,startAngle,spanningAngle); //LR

  oCanHollow = new G4Tubs("oCanHollow",0.0,oCanInnerRadius,oCanLength,startAngle,spanningAngle); //LR

  oCan = new G4SubtractionSolid("oCan",oCanFull,oCanHollow,G4Transform3D(G4RotationMatrix(),G4ThreeVector(0.*cm, 0.*cm, oCanThickness)));

  oCan_log = new G4LogicalVolume(oCan,Al,"oCan_log",0,0,0);                                      //LR

  //DL = new G4Tubs("DL",DLinnerRadius,DLouterRadius,Length*3.5/4.,startAngle,spanningAngle);      //LR
  iDL = new G4Tubs("iDL",iDLinnerRadius,iDLouterRadius,Length*3.5/4.,startAngle,spanningAngle);  //LR

  //DL_log = new G4LogicalVolume(DL,HpGe,"DL_log",0,0,0);                                          //LR
  iDL_log = new G4LogicalVolume(iDL,HpGe,"iDL_log",0,0,0);                                          //LR

  oDL = new G4Tubs("oDL",oDLinnerRadius+1*um,oDLouterRadius,Length,startAngle,spanningAngle);      //LR

  oDL_log = new G4LogicalVolume(oDL,HpGe,"oDL_log",0,0,0);                                          //LR

  preamp = new G4Tubs("preamp",0.,preampRadius,preampLength,startAngle,spanningAngle);           //LR

  preamp_log = new G4LogicalVolume(preamp,Al,"preamp_log",0,0,0);                                //LR


  // Cryo Commented for simplicity
  neck = new G4Tubs("neck",0.,neckRadius,neckLength,startAngle,spanningAngle);                   //LR
  
  neck_log = new G4LogicalVolume(neck,Al,"neck_log",0,0,0);                                      //LR
	  
  cryoBase = new G4Tubs("cryoBase",0.,cryoOuterRadius,cryoBaseThickness,startAngle,spanningAngle); //LR
  
  cryoBase_log = new G4LogicalVolume(cryoBase,Al,"cryoBase_log",0,0,0);                       //LR
  
  cryoFull   = new G4Tubs("cryoFull",  0.,cryoOuterRadius,cryoLength,startAngle,spanningAngle);                                        //LR
  
  cryoHollow = new G4Tubs("cryoHollow",0.,cryoInnerRadius,cryoLength-cryoThickness,startAngle,spanningAngle);                          //LR
  
  cryo = new G4SubtractionSolid("cryo",cryoFull,cryoHollow,G4Transform3D(G4RotationMatrix(),G4ThreeVector(0.*cm, 0.*cm, 0.*cm))); //LR

  cryo_log = new G4LogicalVolume(cryo,Al,"cryo_log",0,0,0);     


  // crystal

  full = new G4Tubs("full",innerRadius,outerRadius,Length,startAngle,spanningAngle);

  //LR hollow = new G4Tubs("hollow",innerRadius,fingerRadius,Length*3.5/4.,startAngle,spanningAngle);
  hollow = new G4Tubs("hollow",innerRadius,iDLouterRadius+1*um,Length*3.5/4.+1*um,startAngle,spanningAngle); //LR

  //LR This is the volume that is quartered and sliced with G4PVReplicas below. 
  //LR The transformation applies to the second solid (hollow here).
  detector = new G4SubtractionSolid("detector",full,hollow,G4Transform3D(G4RotationMatrix(),G4ThreeVector(0.*cm, 0.*cm, Length/8.)));

  detector_log = new G4LogicalVolume(detector,HpGe,"detector_log",0,0,0);

  PlaceDetector();

 //------------------------------Detector readout division
 //LR G4PVReplica slices the mother volume (3rd argument) into many 
 //identical sub-volumes described by the 2nd argument. 

    //Phi division first: 4 sectors

  detectorphiDivisionTub = new G4Tubs("detectorphiDivision",innerRadius,outerRadius,Length,startAngle,90.*deg);
  detectorphiDivision_log = new G4LogicalVolume(detectorphiDivisionTub,HpGe,"detectorphiDivisionLogical",0,0,0);
  detectorphiDivisionPhys = new G4PVReplica("detectorphiDivisionPhysical",detectorphiDivision_log,detector_phys,kPhi,4,90.*deg);
  
  //now z division: 8 slices
 
  detectorcellTub = new G4Tubs("detectorcell",innerRadius,outerRadius,Length/8,startAngle,90.*deg);
  detectorcell_log = new G4LogicalVolume(detectorcellTub,HpGe,"detectorcell_log",0,0,0); 

  //LR v These are made sensitive in DetectorConstruction.cc
  detectorcellPhys = 
    new G4PVReplica(SetDetectorName(),detectorcell_log,detectorphiDivisionPhys,kZAxis,8,Length/4);

  //Visualization Attributes

  G4Colour dgreen (0.0,0.75, 0.0, 1.0); 
  G4VisAttributes* Vis_5 = new G4VisAttributes(dgreen);
  Vis_5->SetVisibility(true);
  Vis_5->SetForceSolid(false);
  Vis_5->SetForceSolid(true); //LR

  G4Colour red (1.0,0.00, 0.0); 
  G4VisAttributes* Vis_4 = new G4VisAttributes(red);
  Vis_4->SetVisibility(true);
  //LR Vis_4->SetForceSolid(false);
  Vis_4->SetForceSolid(true); //LR
 
  G4Colour purple (1.0,1.00, 0.0); 
  G4VisAttributes* Vis_0 = new G4VisAttributes(purple);
  Vis_0->SetVisibility(true);
  //  Vis_0->SetForceSolid(false);
  Vis_0->SetForceSolid(true); 

  G4Colour transGrey (0.8, 0.8, 0.8, 0.3);                  //LR
  G4VisAttributes* Vis_6 = new G4VisAttributes(transGrey);  //LR
  Vis_6->SetVisibility(true);                               //LR
  Vis_6->SetForceSolid(false);                              //LR
  
  G4Colour white (1., 1., 1.0, 1.0);                  //LR
  G4VisAttributes* Vis_1 = new G4VisAttributes(white);  //LR
  Vis_1->SetVisibility(true);                               //LR
  Vis_1->SetForceSolid(true);                              //LR
  
  G4Colour blue (0., 0.0, 1.0);                  //LR
  G4VisAttributes* Vis_2 = new G4VisAttributes(blue);  //LR
  Vis_2->SetVisibility(true);                               //LR
  Vis_2->SetForceSolid(true);                              //LR


  G4Colour blue2 (0., 0.5, 1.0);                  //LR
  G4VisAttributes* Vis_3 = new G4VisAttributes(blue);  //LR
  Vis_3->SetVisibility(true);                               //LR
  Vis_3->SetForceSolid(false);                              //LR

  detector_log->SetVisAttributes(Vis_5);
  detectorcell_log->SetVisAttributes(Vis_3);
  detectorphiDivision_log->SetVisAttributes(Vis_3);
  
  oCan_log->SetVisAttributes(Vis_6);   //LR
  iCan_log->SetVisAttributes(Vis_0);   //LR
  preamp_log->SetVisAttributes(Vis_6); //LR
  iDL_log->SetVisAttributes(Vis_2); // AL
  oDL_log->SetVisAttributes(Vis_3); // AL

  neck_log->SetVisAttributes(Vis_2);   //LR
  cryoBase_log->SetVisAttributes(Vis_5);   //LR
  cryo_log->SetVisAttributes(Vis_2);   //LR
  
  return detector_phys;
}
//---------------------------------------------------------------------
void SeGA_Detector::CalcSegCenters(G4ThreeVector posDopp)
{
// Segment's centers for Doppler corrections
   G4ThreeVector posSeg;
  
    for(j=0;j<4;j++) 
      {
      for(i=0;i<8;i++)
	{
	  posSeg=GetSegPos(i,j);
	  cosSeg[i][j]=cos((posSeg-posDopp).getTheta());
	  //G4cout<<" s = "<<i<<" q = "<<j<<" Theta = "<<(posSeg+DetPos).getTheta()*180./3.14159<<G4endl;
	}
      }
}

//---------------------------------------------------------------------
void SeGA_Detector::setNumber(G4int num)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif  
Number=num;
  G4cout<<"----> SeGA detector number set to "<<Number<<G4endl;

}
//---------------------------------------------------------------------
void SeGA_Detector::setRingID(G4int num)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif  
  RingID=num;
  G4cout<<"----> Ring ID for SeGA detector number "<<Number<<" set to "<<RingID<<G4endl;

}

//---------------------------------------------------------------------
void SeGA_Detector::Report()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif  
  G4cout<<"----> SeGA detector nr "<< Number <<" in ring " << RingID <<  " -- Experiement DAQNr "<< NumberID <<  G4endl;
  G4cout<<"\t\t - radius set to "<<rd/cm<<" cm."<< G4endl;
  G4cout<<"\t\t - theta angle set to "<<thetad/deg<<" deg."<< G4endl;
  G4cout<<"\t\t - phi angle set to "<<phid/deg<<" deg."<< G4endl;
  G4cout<<"\t\t - Z shift from the target to front cap position set to "<< (zd)/cm<<" cm."<< G4endl;
  G4cout<<"\t\t - Cap to cristal  "<< (CapToCristal)/cm<<" cm."<< G4endl;
  G4cout<<"\t\t - Resolution : F="<< F <<" , G="<< G <<", H=" << H <<  G4endl;
}
//---------------------------------------------------------------------
void SeGA_Detector::PlaceDetector()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif   

  if(Orientation<0) 
    Orientation=-1;
  else
    Orientation=1;
  
  if(detector_phys != NULL) delete detector_phys;
  if(iCan_phys != NULL) delete iCan_phys;          //LR
  if(oCan_phys != NULL) delete oCan_phys;          //LR
  if(iDL_phys != NULL) delete iDL_phys;            //LR
  if(oDL_phys != NULL) delete oDL_phys;            //LR
  if(preamp_phys != NULL) delete preamp_phys;      //LR
  if(neck_phys != NULL) delete neck_phys;          //LR
  if(cryoBase_phys != NULL) delete cryoBase_phys;  //LR
  if(cryo_phys != NULL) delete cryo_phys;          //LR
  
  DetRot=G4RotationMatrix::IDENTITY;
  cryoRot=G4RotationMatrix::IDENTITY; //LR

   DetPos.setX(0);
   DetPos.setY(0);
   DetPos.setZ(1);


//   DetRot.rotateX((Orientation-1)*90.*deg);
//   DetRot.rotateY(90.*deg+thetad);
//   DetRot.rotateZ(phid);


	DetRot.rotateX((Orientation+1)*90*deg);
	DetRot.rotateY(90.*deg+thetad);
	DetRot.rotateZ(phid);
	DetPos.setTheta(thetad);
	DetPos.setPhi(phid);
	DetPos.setR(rd);

//  // Cryo Commented for simplicity
// 	cryoRot.rotateX((Orientation+1)*90.*deg); //LR
//    cryoRot.rotateY(45.*deg+thetad);         //LR
//    cryoRot.rotateZ(phid);                    //LR


// 	neckShift=neckOffset;                      // LR
// 	neckShift.rotateX((Orientation+1)*90.*deg); //LR
// 	neckShift.rotateY(90.*deg+thetad);          //LR
// 	neckShift.rotateZ(phid);                    //LR
	
//  	cryoBaseShift=cryoBaseOffset;                 //  LR
//    cryoBaseShift.rotateX((Orientation+1)*90.*deg); //LR
//    cryoBaseShift.rotateY(90.*deg+thetad);          //LR
//    cryoBaseShift.rotateZ(phid);                    //LR

//   cryoShift=cryoOffset;                     //  LR
//   cryoShift.rotateX((Orientation+1)*90.*deg); //LR
//   cryoShift.rotateY(90.*deg+thetad);          //LR
//   cryoShift.rotateZ(phid);                    //LR

  FingShift.setX(0);
  FingShift.setY(0);
  FingShift.setZ(1);
  FingShift=FingShift.cross(DetPos);
  FingShift=FingShift.cross(DetPos);

  oCanShift   = FingShift; //LR
  preampShift = FingShift; //LR

  FingShift.setMag(-Orientation*(Length/8.));
  oCanShift.setMag(-Orientation*(oCanLength - Length - CapToCristal-oCanThickness));             //LR
  preampShift.setMag(-Orientation*(Length+preampLength));  //LR
  
  DetPos+=ZShift;
  FingShift+=DetPos;
  oCanShift+=DetPos;   //LR
  preampShift+=DetPos; //LR
  
//   // Cryo Commented for simplicity
//   neckShift+=DetPos;   //LR
//   cryoBaseShift+=DetPos;   //LR
//   cryoShift+=DetPos;   //LR
  
  
  detector_phys = new G4PVPlacement(G4Transform3D(DetRot,DetPos),
             detector_log,"detector",expHall_log,false,0); 
 

  iDL_phys   =  new G4PVPlacement(G4Transform3D(DetRot,FingShift),               //LR
											 iDL_log,"iDL",expHall_log,false,0,true);       //LR

  oDL_phys   =  new G4PVPlacement(G4Transform3D(DetRot,DetPos),                  //LR
											 oDL_log,"oDL",expHall_log,false,0,true);       //LR

  iCan_phys = new G4PVPlacement(G4Transform3D(DetRot,DetPos),                    //LR
										  iCan_log,"iCan",expHall_log,false,0,true);       //LR
  
  oCan_phys = new G4PVPlacement(G4Transform3D(DetRot,oCanShift),                 //LR
										  oCan_log,"oCan",expHall_log,false,0,true);       //LR
  
  preamp_phys = new G4PVPlacement(G4Transform3D(DetRot,preampShift),             //LR
											 preamp_log,"preamp",expHall_log,false,0,true); //LR

  // Cryo Commented for simplicity
  
//     neck_phys = new G4PVPlacement(G4Transform3D(cryoRot,neckShift),                //LR
//    										  neck_log,"neck",expHall_log,false,0,true);     //LR
  
//      cryoBase_phys = new G4PVPlacement(G4Transform3D(cryoRot,cryoBaseShift),              //LR
//    												cryoBase_log,"cryoBase",expHall_log,false,0,true); //LR
  
//     cryo_phys = new G4PVPlacement(G4Transform3D(cryoRot,cryoShift),                //LR
//   										  cryo_log,"cryo",expHall_log,false,0,true);     //LR
  
}
//---------------------------------------------------------------------
G4double SeGA_Detector::FWHM_response(G4double e_in)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
  G4double e_out,fwhm,sigma,e;
  
  e=e_in/MeV;

  fwhm=sqrt(F+G*e+H*e*e);
  sigma=fwhm/2.35482;
  e_out=CLHEP::RandGauss::shoot(e_in,sigma);
 
  return e_out;
}
//---------------------------------------------------------------------
G4String SeGA_Detector::SetDetectorName()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif  
  std::ostringstream stream; 
  stream<<RingID*1000+Number;
  detector_name="SeGA_"+stream.str();
  return detector_name;
}
//---------------------------------------------------------------------
 void SeGA_Detector::ReportSegments()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
// q,s segment centers for this detector in the array
  G4ThreeVector posSeg;
  G4int  seg;
  G4double theta=0.,phi=0.;

  G4cout<<" Detector "<<Number<<" : Serial Number "<<NumberID<<G4endl;
  for(seg=1;seg<=32;seg++)
    {
     
      posSeg=GetSegPos(Slice(seg),Quarter(seg));
   
      theta+=posSeg.getTheta();
      phi+=posSeg.getPhi();
      G4cout << "  Segment " << setw(2) << seg
				 << "  Slice "   << setw(2) << Slice(seg)
				 << "  Quarter " << setw(2) << Quarter(seg)
				 << " x: " << setw(10) << setprecision(6) << posSeg.getX()/cm
				 << " y: " << setw(10) << setprecision(6) << posSeg.getY()/cm
				 << " z: " << setw(10) << setprecision(6) << posSeg.getZ()/cm
				 << " r: " << setw(10) << setprecision(6) << posSeg.getR()/cm
				 << " Theta: " << setw(10) << setprecision(6) << posSeg.getTheta()/deg
				 << " Phi: " << setw(10) << setprecision(6) << posSeg.getPhi()/deg << G4endl;
		
    }
 
 theta/=32.;
  phi/=32.;

  G4cout<<"Avg. Phi : " << setw(10) << setprecision(6)<<phi/deg<<" Avg. Theta: "<<theta/deg<<G4endl;

}
//---------------------------------------------------------------------
 void SeGA_Detector::SaveSegments(G4String name)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
// q,s segment centers for this detector in the array
  G4ThreeVector posSeg;
  G4int  seg;
  G4double theta=0.,phi=0.;
  ofstream file;
  file.open(name);


  file<<"Detector "<<Number<<" : Serial Number "<<NumberID<<endl;
  for(seg=1;seg<=32;seg++)
    {
     
      posSeg=GetSegPos(Slice(seg),Quarter(seg));
   
      theta+=posSeg.getTheta();
      phi+=posSeg.getPhi();
      file << "  Segment " << setw(2) << seg
           << " x: " << setw(10) << setprecision(6) << posSeg.getX()/cm
           << " y: " << setw(10) << setprecision(6) << posSeg.getY()/cm
			  << " z: " << setw(10) << setprecision(6) << posSeg.getZ()/cm
			  << " r: " << setw(10) << setprecision(6) << posSeg.getR()/cm
			  << " Theta: " << setw(10) << setprecision(6) << posSeg.getTheta()/deg
           << " Phi: " << setw(10) << setprecision(6) << posSeg.getPhi()/deg << endl;
  
    }
 
 theta/=32.;
  phi/=32.;

  file<<"Avg. Phi : " << setw(10) << setprecision(6)<<phi/deg<<" Avg. Theta: "<<theta/deg<<endl;

  file.close();
}
//---------------------------------------------------------------------
 G4int SeGA_Detector::Quarter(G4int seg)
{
  if(seg<=0&&seg>32) return -1;

switch ((seg-1)/8)
  {
  case 0:
    return 2;
    break;
  case 1:
    return 3;
    break;
  case 2:
    return 0;
    break;
  case 3:
    return 1;
    break;
  default:
    return -1;
    break;
  }
return -1;
}
//---------------------------------------------------------------------
 G4int SeGA_Detector::Slice(G4int seg)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
  if(seg<=0&&seg>32) return -1; 

  switch ((seg-1)%8)
    {
    case 0:
      return 6;
      break;
    case 1:
      return 4;
      break;
    case 2:
      return 2;
      break;
    case 3:
      return 0;
      break;
    case 4:
      return 1;
      break;
    case 5:
      return 3;
      break;
    case 6:
      return 5;
      break;
    case 7:
      return 7;
      break;
    default:
      return -1;
      break;

    }
  return -1;
}
//--------------------------------------------------------------
G4ThreeVector SeGA_Detector::GetSegPos(G4int slice, G4int quarter)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
  G4ThreeVector posSeg;
  posSeg.setX(0.5*outerRadius*cos(45.*deg+quarter*90.*deg));
  posSeg.setY(0.5*outerRadius*sin(45.*deg+quarter*90.*deg));
  posSeg.setZ((-3.5+slice)/4.*Length);
  
  posSeg.rotateX((Orientation+1)*90.*deg);
  posSeg.rotateY(90.*deg+thetad);
  posSeg.rotateZ(phid);
  posSeg+=DetPos;
  return posSeg;

}
//----------------------------------------------------------------
G4ThreeVector SeGA_Detector::SimulateTrackingResolution(G4ThreeVector Hit, G4double dr, G4double dphi, G4double dz)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif

  G4int s,q;
  G4double z,r,phi;
  G4double rmin,rmax,phimax,phimin,zmax,zmin;
  // bring to the initial position detectors are defined in
  //  G4cout<<"         Hit at x= "<<Hit.getX()/cm<<" y= "<<Hit.getY()/cm<<" z= "<<Hit.getZ()/cm<<G4endl;
  Hit-=DetPos;
  Hit.rotateZ(-phid);
  Hit.rotateY(-(90.*deg+thetad));
  Hit.rotateX(-(Orientation-1)*90.*deg);

  if(detector->Inside(Hit)==kInside)
    {
      r=Hit.getR()*sin(Hit.getTheta()); phi=Hit.getPhi(); z=Hit.getZ();
      //      G4cout<<" Transformed to r= "<<r/cm<<" phi = "<<phi/deg<<" z= "<<z/cm<<G4endl;
      // figure out the slice 
      s=(G4int)rint(4.*z/Length+3.5);

      if(phi<0.) phi=360*deg+phi;
	q=(G4int)rint((phi/deg-45.)/90.);
  
	//     G4cout<<" Slice "<<s<<" Quarter "<<q<<G4endl;
      // figure out the limits taking into acount segment boundries 
      
      rmax=min(r+dr,outerRadius);
      if(s==0)
	rmin=max(r-dr,innerRadius);
      else
	rmin=max(r-dr,fingerRadius);

      phimax=min(phi+dphi,(q+1)*90.*deg);
      phimin=max(phi-dphi,q*90.*deg);

      zmax=min(z+dz,(s-3)*Length/4.);
      zmin=max(z-dz,(s-4)*Length/4.);
//       G4cout<<" --------------------------------------------------- "<<G4endl;
//       G4cout<<" outer R "<<outerRadius/cm<<G4endl;
//       G4cout<<"     R= "<<r/cm<<" phi = "<<phi/deg<<" z= "<<z/cm<<G4endl;
//       G4cout<<"Max  R= "<<rmax/cm<<" phi = "<<phimax/deg<<" z= "<<zmax/cm<<G4endl;
//       G4cout<<"Min  R= "<<rmin/cm<<" phi = "<<phimin/deg<<" z= "<<zmin/cm<<G4endl;
      r=sqrt(rmin*rmin+G4UniformRand()*(rmax*rmax-rmin*rmin));
      phi=phimin+G4UniformRand()*(phimax-phimin);
      z=zmin+G4UniformRand()*(zmax-zmin);
      Hit.setX(r*cos(phi)); Hit.setY(r*sin(phi)); Hit.setZ(z);
    }
  else
    G4cout<<" !!!!!!!! First interaction in a different detector "<<G4endl;

  // bring to the original position
  Hit.rotateX((Orientation-1)*90.*deg);
  Hit.rotateY(90.*deg+thetad);
  Hit.rotateZ(phid);
  Hit+=DetPos;
  return Hit;
}
//---------------------------------------------------------------------
G4double SeGA_Detector::Efficiency(G4double e)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif

  return 0.5*(1+tanh((e-thr_center)/thr_width));

}
//---------------------------------------------------------------------
G4bool SeGA_Detector::Efficiency_response(G4double e)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
   G4double r=G4UniformRand();
   G4double ref=0.5*(1+tanh((e-thr_center)/thr_width));

   if(r>ref) 
     return false;
   else
     return true;
}

//---------------------------------------------------------------------
G4int SeGA_Detector::getSegID(G4int s,G4int q)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif
  G4int SegNr = -1;
  
  switch (s)
    {
    case 6:
      SegNr = 0;
      break;
    case 4:
      SegNr = 1;
      break;
    case 2:
      SegNr = 2;
      break;
    case 0:
      SegNr = 3;
      break;
    case 1:
      SegNr = 4;
      break;
    case 3:
      SegNr = 5;
      break;
    case 5:
      SegNr = 6;
      break;
    case 7:
      SegNr = 7;
      break;
    default:
      SegNr = -1;
      break;
		
    }
  
  switch (q)
    {
    case 0:
      SegNr += 16;
      break;
    case 1:
      SegNr += 24;
      break;
    case 2:
      SegNr += 0;
      break;
    case 3:
      SegNr += 8;
      break;
    default:
      SegNr = -1;
      break;
    }

  return SegNr;
}
