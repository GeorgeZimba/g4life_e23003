#include "PrimaryGeneratorAction_Messenger.hh"

PrimaryGeneratorAction_Messenger::PrimaryGeneratorAction_Messenger(PrimaryGeneratorAction* pga):PGA(pga) 
{ 
 
 
  PGADir = new G4UIdirectory("/Experiment/");
  PGADir->SetGuidance("Select the experimental conditions for simulations.");

  SrcDir = new G4UIdirectory("/Experiment/Source/");
  SrcDir->SetGuidance("Select source parameters for simulation.");

  RctDir = new G4UIdirectory("/Experiment/Reaction/");
  RctDir->SetGuidance("Select reaction parameters for simulation.");
  
  PGASCmd = new G4UIcmdWithADoubleAndUnit("/Experiment/RunSource",this);
  PGASCmd->SetGuidance("Select calibration single energy source");
  PGASCmd->SetParameterName("Energy of the transition",false);
  PGASCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  PGASEUCmd = new G4UIcmdWithoutParameter("/Experiment/RunSource152Eu",this);
  PGASEUCmd->SetGuidance("Select 152 Eu source calibration.");

  PGABCmd = new G4UIcmdWithoutParameter("/Experiment/RunBeam",this);
  PGABCmd->SetGuidance("Select in-beam simulations.");

  SrcXCmd = new G4UIcmdWithADoubleAndUnit("/Experiment/Source/setX",this);
  SrcXCmd->SetGuidance("Set X position for the source");
  SrcXCmd->SetParameterName("Source X position",false);
  SrcXCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SrcYCmd = new G4UIcmdWithADoubleAndUnit("/Experiment/Source/setY",this);
  SrcYCmd->SetGuidance("Set Y position for the source");
  SrcYCmd->SetParameterName("Source Y position",false);
  SrcYCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SrcZCmd = new G4UIcmdWithADoubleAndUnit("/Experiment/Source/setZ",this);
  SrcZCmd->SetGuidance("Set Z position for the source");
  SrcZCmd->SetParameterName("Source Z position",false);
  SrcZCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  SrcTFCmd = new G4UIcmdWithoutParameter("/Experiment/Source/OnTargetFace",this);
  SrcTFCmd->SetGuidance("Set source position on target face");
  
  SrcTBCmd = new G4UIcmdWithoutParameter("/Experiment/Source/OnTargetBack",this);
  SrcTBCmd->SetGuidance("Set source position on target back");

  //TM 6/25/2018, new from version 4.2	
  SrcDFCmd = new G4UIcmdWithoutParameter("/Experiment/Source/OnDegraderFace",this);
  SrcDFCmd->SetGuidance("Set source on degrader face");

  SrcDBCmd = new G4UIcmdWithoutParameter("/Experiment/Source/OnDegraderBack",this);
  SrcDBCmd->SetGuidance("Set source on degrader upstream face");

  SrcSFCmd = new G4UIcmdWithoutParameter("/Experiment/Source/OnStopperFace",this);
  SrcSFCmd->SetGuidance("Set source on stopper face");
  
  SrcSBCmd = new G4UIcmdWithoutParameter("/Experiment/Source/OnStopperBack",this);
  SrcSBCmd->SetGuidance("Set source on stopper back");

  SrcRCmd = new G4UIcmdWithoutParameter("/Experiment/Source/Report",this);
  SrcRCmd->SetGuidance("Report source parameters");

  ROfCmd = new G4UIcmdWithoutParameter("/Experiment/Reaction/Off",this);
  ROfCmd->SetGuidance("Simulate only unreacted ions.");

  ROnCmd = new G4UIcmdWithoutParameter("/Experiment/Reaction/On",this);
  ROnCmd->SetGuidance("Simulate only Coulomb scattered ions.");

  SFrCmd = new G4UIcmdWithADouble("/Experiment/Reaction/UnscatteredFraction",this);
  SFrCmd->SetGuidance("Set fraction of Coulomb unscattered ions in the beam ");
  SFrCmd->SetParameterName("fraction",false);
  SFrCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  //AR New in v4.3 -> Parameters to reproduce distorded DTA
  DTASlopeCmd = new G4UIcmdWithADouble("/Experiment/Reaction/DTASlope",this);
  DTASlopeCmd->SetGuidance("Set Slope for tuning of DTA distribution");
  DTASlopeCmd->SetParameterName("DTA distribution slope",false);
  DTASlopeCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DTAOffsetCmd = new G4UIcmdWithADouble("/Experiment/Reaction/DTAOffset",this);
  DTAOffsetCmd->SetGuidance("Set Offset for tuning of DTA distribution");
  DTAOffsetCmd->SetParameterName("DTA distribution offset",false);
  DTAOffsetCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DTASigmaCmd = new G4UIcmdWithADouble("/Experiment/Reaction/DTASigma",this);
  DTASigmaCmd->SetGuidance("Set Sigma for tuning of DTA distribution");
  DTASigmaCmd->SetParameterName("DTA distribution sigma",false);
  DTASigmaCmd->AvailableForStates(G4State_PreInit,G4State_Idle);

  DTAMeanCmd = new G4UIcmdWithADouble("/Experiment/Reaction/DTAMean",this);
  DTAMeanCmd->SetGuidance("Set Mean for tuning of DTA distribution");
  DTAMeanCmd->SetParameterName("DTA distribution mean",false);
  DTAMeanCmd->AvailableForStates(G4State_PreInit,G4State_Idle);
  
}



PrimaryGeneratorAction_Messenger::~PrimaryGeneratorAction_Messenger()
{
  
  delete PGADir;
  delete SrcDir;
  delete RctDir;
  delete PGASCmd;
  delete PGASEUCmd;
  delete PGABCmd;
  delete SrcXCmd;
  delete SrcYCmd;
  delete SrcZCmd;
  delete SrcTFCmd;
  delete SrcTBCmd;
  delete SrcDFCmd;
  delete SrcDBCmd;  
  delete SrcSFCmd;
  delete SrcSBCmd;  
  delete SrcRCmd;
  delete ROnCmd;
  delete ROfCmd;
  delete SFrCmd;
  //AR New in v4.3 -> Parameters to reproduce distorded DTA
  delete DTASlopeCmd;
  delete DTAOffsetCmd;
  delete DTAMeanCmd;
  delete DTASigmaCmd;
}



void PrimaryGeneratorAction_Messenger::SetNewValue(G4UIcommand* command,G4String newValue)
{ 


  if( command == PGASCmd )
    {
		PGA ->SetSource();
		PGA ->SetSingleSource(PGASCmd->GetNewDoubleValue(newValue));
	 }
  if( command == PGASEUCmd )
    {
		PGA ->SetSource();
		PGA ->SetSourceEu152();
	 }

  if( command == PGABCmd )
    {PGA ->SetInBeam();}

  if( command == SrcXCmd )
    {PGA ->SetSourceX(SrcXCmd->GetNewDoubleValue(newValue));}

  if( command == SrcYCmd )
    {PGA ->SetSourceY(SrcYCmd->GetNewDoubleValue(newValue));}

  if( command == SrcZCmd )
    {PGA ->SetSourceZ(SrcZCmd->GetNewDoubleValue(newValue));}

  if( command == SrcTFCmd )
    {PGA ->SetSourceOnTargetFace();}

  if( command == SrcTBCmd )
    {PGA ->SetSourceOnTargetBack();}
    
  if(command== SrcDFCmd)
    {PGA ->SetSourceOnDegraderFace();}    
    
  if(command== SrcDBCmd)
    {PGA ->SetSourceOnDegraderBack();}

  if( command == SrcSFCmd )
    {PGA ->SetSourceOnStopperFace();}    
    
  if( command == SrcSBCmd )
    {PGA ->SetSourceOnStopperBack();}      

  if( command == SrcRCmd )
    {PGA ->SourceReport();}

  if( command == ROnCmd )
    {PGA ->ReactionOn();}

 if( command == ROfCmd )
    {PGA ->ReactionOff();}

 if( command == SFrCmd )
    {PGA ->SetFraction(SFrCmd->GetNewDoubleValue(newValue));}

 //AR New in v4.3 -> Parameters to reproduce distorded DTA
 if( command == DTASlopeCmd )
   {PGA ->SetDTASlope(DTASlopeCmd->GetNewDoubleValue(newValue));}
 
 if( command == DTAOffsetCmd )
   {PGA ->SetDTAOffset(DTAOffsetCmd->GetNewDoubleValue(newValue));}
 
 if( command == DTAMeanCmd )
   {PGA ->SetDTAMean(DTAMeanCmd->GetNewDoubleValue(newValue));}

 if( command == DTASigmaCmd )
   {PGA ->SetDTASigma(DTASigmaCmd->GetNewDoubleValue(newValue));}
 
}

