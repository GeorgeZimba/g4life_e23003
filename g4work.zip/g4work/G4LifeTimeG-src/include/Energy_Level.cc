#include "Energy_Level.hh"


Energy_Level::Energy_Level()
{
  Ex=1111*keV;
  Eg=1111*keV;
  tau=0.00011*ns;
  frac=100;
}


Energy_Level::~Energy_Level()
{
  ;
}

/*--------------------------------------------------------*/
void Energy_Level::Report()
{
  G4cout<<"----> Excitation energy       "<<Ex/keV<<" [keV]"<<G4endl;
  G4cout<<"   => Decay energy            "<<Eg/keV<<" [keV]"<<G4endl;
  G4cout<<"   => Lifetime                "<<(tau/ns)*1000.<<" [ps]"<<G4endl;
  G4cout<<"   => Direct feeding fraction "<<frac<<" [%]"<<G4endl;
}

