#ifndef SeGA_Detector_Messenger_h
#define SeGA_Detector_Messenger_h 1

#include "SeGA_Detector.hh"
#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithoutParameter.hh"


class SeGA_Detector_Messenger: public G4UImessenger
{
  public:
    SeGA_Detector_Messenger(SeGA_Detector*);
   ~SeGA_Detector_Messenger();
    
    void SetNewValue(G4UIcommand*, G4String);
    
  private:
    SeGA_Detector* SeGADet;
   
    G4UIdirectory*             SeGADir;  
    G4UIdirectory*             SeGADetDir;  
    G4UIdirectory*             SeGADetPosDir;  
    G4UIdirectory*             SeGADetFWHMDir;  
    G4UIcmdWithADoubleAndUnit* ThetaCmd;
    G4UIcmdWithADoubleAndUnit* PhiCmd;
    G4UIcmdWithADoubleAndUnit* RCmd;
    G4UIcmdWithADouble*        FCmd;
    G4UIcmdWithADouble*        GCmd;
    G4UIcmdWithADouble*        HCmd;
    G4UIcmdWithADoubleAndUnit* ZCmd;
    G4UIcmdWithoutParameter*   RepCmd;
  

};


#endif

