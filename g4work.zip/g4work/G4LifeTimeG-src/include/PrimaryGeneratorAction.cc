#include "PrimaryGeneratorAction.hh"

PrimaryGeneratorAction::PrimaryGeneratorAction(DetectorConstruction *detector, Incoming_Beam* BI, Outgoing_Beam* BO): BeamIn(BI), BeamOut(BO), myDetector(detector)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  source=false;
  sourcePosition.setX(0);
  sourcePosition.setY(0);
  sourcePosition.setZ(0);
  SetSourceEu152();
  n_particle = 1;
  particleGun = new G4ParticleGun(n_particle);
  fracOn=false;
  frac=0;
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  delete particleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* anEvent)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif

  particleTable = G4ParticleTable::GetParticleTable();
  BeamOut->SetReactionFlag(-1);

#ifdef DEBUG
  G4cout <<" +++++ In Generate Primaries " << G4endl;
#endif
  
  if(source){
    if(myDetector->IsDefinedSeGA()) myDetector->GetSeGA()->DopplerOff();
    if(myDetector->IsDefinedGretina()) myDetector->GetGretina()->SetDopplerOff(1);
#ifdef DEBUG
    G4cout<<" +++++ Shooting Source gammas "<<G4endl;
#endif
    particleGun->SetParticleDefinition(particleTable->FindParticle("gamma"));
	 
    particleGun->SetParticleMomentumDirection(G4RandomDirection());
    particleGun->SetParticlePosition(sourcePosition);
    particleGun->SetParticleEnergy(GetSourceEnergy());
  }
  else{
    
    ion =  particleTable->GetIon(BeamIn->getZ(),BeamIn->getA(),BeamIn->getEx());
    particleGun->SetParticleDefinition(ion);
    
    position=BeamIn->getPosition();
    particleGun->SetParticlePosition(position);
      
    direction=BeamIn->getDirection();
    particleGun->SetParticleMomentumDirection(direction);

    //AR New in v4.3 -> Modifying in order to reproduce unuasual DTA distribution in the data if necessary
    G4double test;
    G4double XX;
    G4double Sig = 0.; //6
    G4double Mean = 0.; //-9
    if(dtaOffsetOn && dtaSlopeOn){
      Mean = dtaoffset;
      Sig = dtaslope;
      G4double A = 6./(BeamIn->getKEu()*BeamIn->getA()-(BeamIn->getKEu()*BeamIn->getA()*(1-0.5*BeamIn->getDpp())));
      G4double B = -A*BeamIn->getKEu()*BeamIn->getA();
      do{	
	KE=BeamIn->getKE(ion);
	test = G4UniformRand();
	XX = A*KE+B;
	//G4cout << XX << "   " << KE << "  " << test << "  "  << (Sig*XX+Mean)/(-7.*Sig+Mean) << "   " << (Sig*XX+Mean) << "   " << (-7.*Sig+Mean) << G4endl;
	//XX = 0.089*KE-334.47;
	//}while(KE<3657.);
      //}while(test>(Sig*XX+Mean));
      }while(test>(Sig*XX+Mean)/(-7.*Sig+Mean));
    }else if(dtaMeanOn && dtaSigmaOn){
      Mean = dtamean;
      Sig = dtasigma;
      G4double A = 6./(BeamIn->getKEu()*BeamIn->getA()-(BeamIn->getKEu()*BeamIn->getA()*(1-0.5*BeamIn->getDpp())));
      G4double B = -A*BeamIn->getKEu()*BeamIn->getA();
      do{
	KE=BeamIn->getKE(ion);
	test = G4UniformRand();
	XX = A*KE+B;
      }while(test>(1.*exp(-0.5*((XX-Mean)/Sig)*((XX-Mean)/Sig))));
	//}while(test>(Sig*XX+Mean)/(-7.*Sig+Mean));
    }else{
      KE=BeamIn->getKE(ion);
    }
    
    particleGun->SetParticleEnergy(KE);

    if(fracOn){
      if(G4UniformRand()<frac) 
	BeamOut->SetReactionOff();
      else   
	BeamOut->SetReactionOn();
    }
    if(BeamOut->ReactionOn()){
      G4double TT;
      G4double TC;
      G4double depth;
			 
      if(myDetector->GetPlungerType()>0){
	G4double r;
	G4double r2;
	r=G4UniformRand();

	if(r<myDetector->GetRRatio()){
	  //Reactions on the target
	  TT=2.*myDetector->GetTarget()->GetZHalfLength();
	  TC=myDetector->GetTargetPlacement()->GetTranslation().getZ();
	  depth=TC+TT*(G4UniformRand()-0.5);
	  // 	      G4cout<< "- Target Thickness is  "<<TT/mm<<" mm"<<G4endl;
	  // 	      G4cout<< "- Target Center is at  "<<TC/mm<<" mm"<<G4endl;
	  // 	      G4cout<< "- Reaction depth   at  "<<depth/mm<<" mm"<<G4endl;
	  myDetector->setTargetReactionDepth(depth);
	}
	else{
	  if(myDetector->GetPlungerType()>1){
	    r2=G4UniformRand();
	    if(r2<myDetector->GetRRatio2()){
	      //Reaqctions on the degrader
	      TT=2.*myDetector->GetDegrader()->GetZHalfLength();
	      TC=myDetector->GetDegraderPlacement()->GetTranslation().getZ();
	      depth=TC+TT*(G4UniformRand()-0.5);
	      // 	      G4cout<< "- Degrader Thickness is  "<<TT/mm<<" mm"<<G4endl;
	      // 	      G4cout<< "- Degrader Center is at  "<<TC/mm<<" mm"<<G4endl;
	      // 	      G4cout<< "- Reaction depth   at  "<<depth/mm<<" mm"<<G4endl;
	      myDetector->setDegraderReactionDepth(depth);
	    }
	    else{
	      //Reactions on the stopper
	      TT=2.*myDetector->GetStopper()->GetZHalfLength();
	      TC=myDetector->GetStopperPlacement()->GetTranslation().getZ();
	      depth=TC+TT*(G4UniformRand()-0.5);
	      // 	      G4cout<< "- Degrader Thickness is  "<<TT/mm<<" mm"<<G4endl;
	      // 	      G4cout<< "- Degrader Center is at  "<<TC/mm<<" mm"<<G4endl;
	      // 	      G4cout<< "- Reaction depth   at  "<<depth/mm<<" mm"<<G4endl;
	      myDetector->setStopperReactionDepth(depth);
	    }
	  }
	  else{
	    TT=2.*myDetector->GetDegrader()->GetZHalfLength();
	    TC=myDetector->GetDegraderPlacement()->GetTranslation().getZ();
	    depth=TC+TT*(G4UniformRand()-0.5);
	    myDetector->setDegraderReactionDepth(depth);				  
	  }
	}
      }
      else{
	TT=2.*myDetector->GetTarget()->GetZHalfLength();
	TC=myDetector->GetTargetPlacement()->GetTranslation().getZ();
	depth=TC+TT*(G4UniformRand()-0.5);
	myDetector->setTargetReactionDepth(depth);
      }
    }
  }
  
#ifdef DEBUG
  G4cout<<" +++++ Generating an event "<<G4endl;
#endif
  particleGun->GeneratePrimaryVertex(anEvent);

}
//---------------------------------------------------------------------
void PrimaryGeneratorAction::SetSourceOnTargetFace()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  sourcePosition.setX(0);
  sourcePosition.setY(0);
  sourcePosition.setZ(-myDetector->GetTarget()->GetZHalfLength()+
							 myDetector->GetTargetPlacement()->GetTranslation().getZ());
  particleGun->SetParticlePosition(sourcePosition);
}

//---------------------------------------------------------------------
void PrimaryGeneratorAction::SetSourceOnTargetBack()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  sourcePosition.setX(0);
  sourcePosition.setY(0);
  sourcePosition.setZ(myDetector->GetTarget()->GetZHalfLength()+
							 myDetector->GetTargetPlacement()->GetTranslation().getZ());
  particleGun->SetParticlePosition(sourcePosition);
}
//---------------------------------------------------------------------
void PrimaryGeneratorAction::SetSourceOnDegraderFace()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  sourcePosition.setX(0);
  sourcePosition.setY(0);
  sourcePosition.setZ(-myDetector->GetDegrader()->GetZHalfLength()+
							 myDetector->GetDegraderPlacement()->GetTranslation().getZ());
  particleGun->SetParticlePosition(sourcePosition);
}

//---------------------------------------------------------------------
void PrimaryGeneratorAction::SetSourceOnDegraderBack()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  sourcePosition.setX(0);
  sourcePosition.setY(0);
  sourcePosition.setZ(myDetector->GetDegrader()->GetZHalfLength()+
							 myDetector->GetDegraderPlacement()->GetTranslation().getZ());
  particleGun->SetParticlePosition(sourcePosition);
}
//---------------------------------------------------------------------
void PrimaryGeneratorAction::SetSourceOnStopperFace()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  sourcePosition.setX(0);
  sourcePosition.setY(0);
  sourcePosition.setZ(-myDetector->GetStopper()->GetZHalfLength()+
							 myDetector->GetStopperPlacement()->GetTranslation().getZ());
  particleGun->SetParticlePosition(sourcePosition);
}

//---------------------------------------------------------------------
void PrimaryGeneratorAction::SetSourceOnStopperBack()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  sourcePosition.setX(0);
  sourcePosition.setY(0);
  sourcePosition.setZ(myDetector->GetStopper()->GetZHalfLength()+
							 myDetector->GetStopperPlacement()->GetTranslation().getZ());
  particleGun->SetParticlePosition(sourcePosition);
}

//---------------------------------------------------------------------
void PrimaryGeneratorAction::SourceReport()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  if(source)
    {
		G4cout<<"----> Source position in X is set to "<<G4BestUnit(sourcePosition.getX(),"Length")<<G4endl;
		G4cout<<"----> Source position in Y is set to "<<G4BestUnit(sourcePosition.getY(),"Length")<<G4endl;
		G4cout<<"----> Source position in Z is set to "<<G4BestUnit(sourcePosition.getZ(),"Length")<<G4endl;
		for (unsigned short i=0; i< TheSource.size(); i++){
		  G4cout << " \t Line " << i << " : " <<  TheSource[i]->e << " keV" <<  G4endl;
		}
    }
  else
    G4cout<<"----> In-beam run selected for simulations"<<G4endl;
}
//-------------------------------------------------------------
void PrimaryGeneratorAction::SetSourceEu152()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  G4double e;
  sourceBranchingSum=0.;
  
  TheSource.clear();

  e=121.7830*keV;sourceBranchingSum+=13620.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 244.6920*keV; sourceBranchingSum+= 3590.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 295.9390*keV; sourceBranchingSum+=  211.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 344.2760*keV; sourceBranchingSum+=12750.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 367.7890*keV; sourceBranchingSum+=  405.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 411.1150*keV; sourceBranchingSum+= 1070.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 443.9760*keV; sourceBranchingSum+= 1480.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 488.6610*keV; sourceBranchingSum+=  195.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 564.0210*keV; sourceBranchingSum+=  236.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 586.2940*keV; sourceBranchingSum+=  220.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 678.5780*keV; sourceBranchingSum+=  221.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 688.6780*keV; sourceBranchingSum+=  400.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 778.9030*keV; sourceBranchingSum+= 6190.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 867.3880*keV; sourceBranchingSum+= 1990.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e= 964.1310*keV; sourceBranchingSum+= 6920.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1005.2790*keV; sourceBranchingSum+=  310.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1085.8360*keV; sourceBranchingSum+= 4859.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1089.7000*keV; sourceBranchingSum+=  820.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1109.1800*keV; sourceBranchingSum+=   88.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1112.1160*keV; sourceBranchingSum+= 6490.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1212.9500*keV; sourceBranchingSum+=  670.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1299.1240*keV; sourceBranchingSum+=  780.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
  e=1408.0110*keV; sourceBranchingSum+=10000.;
  TheSource.push_back(new SourceData(e,sourceBranchingSum));
}
//-------------------------------------------------------------------------
G4double PrimaryGeneratorAction::GetSourceEnergy()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif

  G4double rand;
  rand=G4UniformRand()*sourceBranchingSum;

  vector<SourceData*>::iterator itPos = TheSource.begin();

  for(; itPos < TheSource.end(); itPos++)
    if(rand<(*itPos)->b) return (*itPos)->e;

  return -1*keV;
}

void PrimaryGeneratorAction::SetSingleSource(G4double e)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif
  
  TheSource.clear();
  sourceBranchingSum=100;
  TheSource.push_back(new SourceData(e,100));
}
