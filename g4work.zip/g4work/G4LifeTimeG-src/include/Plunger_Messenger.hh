#ifndef Plunger_Messenger_h
#define Plunger_Messenger_h 1

#include "Plunger.hh"
#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithAnInteger.hh"
class Plunger_Messenger: public G4UImessenger
{
  public:
    Plunger_Messenger(Plunger*);
   ~Plunger_Messenger();
    
    void SetNewValue(G4UIcommand*, G4String);
    
  private:
    Plunger* aPlunger;
    G4UIdirectory*             PlungerDir;
    G4UIdirectory*             DegraderDir;
    G4UIdirectory*             TargetDir;
    G4UIdirectory*             StopperDir;
    G4UIcmdWithADouble*        RatCmd;
    G4UIcmdWithADoubleAndUnit* SepCmd;
    G4UIcmdWithADouble*        Rat2Cmd;
    G4UIcmdWithADoubleAndUnit* Sep2Cmd;
    G4UIcmdWithADoubleAndUnit* PosCmd;
    G4UIcmdWithAString*        MatDegCmd;  
    G4UIcmdWithADoubleAndUnit* XDegCmd;
    G4UIcmdWithADoubleAndUnit* YDegCmd;
    G4UIcmdWithADoubleAndUnit* ZDegCmd;
    G4UIcmdWithAnInteger*      NSDegCmd;
    G4UIcmdWithAString*        MatTarCmd;  
    G4UIcmdWithADouble*        ScDDegCmd;
    G4UIcmdWithADoubleAndUnit* XTarCmd;
    G4UIcmdWithADoubleAndUnit* YTarCmd;
    G4UIcmdWithADoubleAndUnit* ZTarCmd;
    G4UIcmdWithAnInteger*      NSTarCmd;
    G4UIcmdWithADouble*        ScDTarCmd;
    G4UIcmdWithAString*        MatStoCmd;  
    G4UIcmdWithADoubleAndUnit* XStoCmd;
    G4UIcmdWithADoubleAndUnit* YStoCmd;
    G4UIcmdWithADoubleAndUnit* ZStoCmd;
    G4UIcmdWithAnInteger*      NSStoCmd;
    G4UIcmdWithADouble*        ScDStoCmd;
    G4UIcmdWithoutParameter*   RepCmd;
  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  G4UIdirectory*             ShieldDir;
  G4UIcmdWithoutParameter*   ShAddCmd;
  G4UIcmdWithAString* ShMatCmd;
  G4UIcmdWithADoubleAndUnit* ShPosCmd;
  G4UIcmdWithADoubleAndUnit* ShRminCmd;
  G4UIcmdWithADoubleAndUnit* ShRmaxCmd;
  G4UIcmdWithADoubleAndUnit* ShLenCmd;

};


#endif

