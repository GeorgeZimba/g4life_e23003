#ifndef Gretina_Array_H
#define Gretina_Array_H

#include "globals.hh"
#include "G4Point3D.hh"
#include "G4ThreeVector.hh"
#include "G4RotationMatrix.hh"
#include "G4Transform3D.hh"

#include "G4RunManager.hh"

#include "GretinaUtils.hh"
#include "CConvexPolyhedron.hh"

#include "G4VUserDetectorConstruction.hh"
#include "G4SDManager.hh"
#include "G4VisAttributes.hh"

#include "G4Material.hh"

#include "G4AssemblyVolume.hh"
#include "G4Box.hh"
#include "G4Tubs.hh"
#include "G4Polycone.hh"
#include "G4Polyhedra.hh"
#include "G4IntersectionSolid.hh"
#include "G4Plane3D.hh"
#include "G4Normal3D.hh"

#include "G4LogicalVolume.hh"
#include "G4VPhysicalVolume.hh"
#include "G4PVPlacement.hh"

#include "TrackerGammaSD.hh"
#include "GretinaSD.hh"

#include <iostream>
#include <vector>

using namespace std;
using namespace CLHEP;
 
class CConvexPolyhedron;
class G4Tubs;
class G4Box;
class G4Polycone;
class G4IntersectionSolid;
class G4LogicalVolume;
class G4VisAttributes;
class G4VPhysicalVolume;

class CpolyhPoints;
class CclusterAngles;
class CeulerAngles;
class G4AssemblyVolume;

class G4Material;


////////////////////////////////////////////////////////////////////////////////////
//          This class handles the construction of the actual GRETINA Array       //
////////////////////////////////////////////////////////////////////////////////////

class Gretina_Array 
{

public:

  Gretina_Array(G4String,G4String); 
  ~Gretina_Array();
  
  void Construct();



  //////////////////////////////////////////////////////////////
  /// look for the materials starting from the material names
  /////////////////////////////////////////////////////////////

  G4int FindMaterials();
  
  /////////////////////////////////////////////////////////
  /// Construct the various elements composing the arrays
  /////////////////////////////////////////////////////////  
private:
  void      ConstructGeCrystals  ();    
  void      ConstructTheCapsules ();    
  void      ConstructTheClusters ();    
  void      ConstructTheWalls    ();
  
public:
  void      PlaceTheClusters();  


  
private:
  
  
  /////////////////////////////////////////////////
  // Files from which the actual geometry is read//
  /////////////////////////////////////////////////

  G4String                    eulerFile;   //> angles and positions to place the clusters into space
  G4String                    solidFile;   //> shape of the crystals
  G4String                    sliceFile;   //> segmentation
  G4String                    wallsFile;   //> cryostats
  G4String                    clustFile;   //> arrangement of the crystals and cryostats within a cluster

  //////////////////////
 // Initialize Data  // 
//////////////////////


private:
  GretinaSD* GeSD;

public:
  inline GretinaSD*     GetSD(){return GeSD;};


private:

  G4String iniPath;                             //Directory where the files are located
  G4String directoryName;                       //for the command line (?)
  
  
  void InitData(G4String path, G4String eulerfile);
  
  
  /////////////////
  /// some flags 
  //////////////// 
private:
  G4bool                      usePassive;   //> true: passive areas of the crystals will be generated
  G4bool                      drawReadOut;  //> true: segments will be visualized
  G4bool                      useAncillary; //> true: ancillary detectors will be constructed
  G4bool                      makeCapsule;  //> true: encapsulation will be generated
  G4bool                      useCylinder;  //> true: the intersection with the cylinder will be considered
  G4bool                      cryostatStatus;  //> true: include cryostats behind clusters //LR

  
  
  /////////////////////////////////////
  /// materials (pointers and names)
  ///////////////////////////////////// 
private:
  G4Material                  *matCryst;   //> crystals
  G4Material                  *matWalls;   //> cryostats and encapsulation
  G4Material                  *matHole;    //> vacuum within the cryostat
  G4Material                  *matCryo;    //> cryostats
  
  
private:
  G4String                    matCrystName; //> crystals
  G4String                    matWallsName; //> cryostats and encapsulation
  G4String                    matBackWallsName; //> behind the crystals
  G4String                    matHoleName;  //> vacuum within the cryostat
  G4String                    matCryoName;  //> cryostats
 

  //////////////////////////
  /// read the input files
  /////////////////////////
private:
  void      ReadEulerFile();
  void      ReadSolidFile();
  void      ReadWallsFile();
  void      ReadClustFile();

  G4String EulerFileName; // AR New in v4.3 -> To specify euler file in .mac
  
  ///////////////////////////////////////////////////////////////////////
  /// structures needed to store geometry data during the construction  
  ///////////////////////////////////////////////////////////////////////

private:
  std::vector<CeulerAngles>   euler;        //> angles and positions to place the clusters into space
  std::vector<CpolyhPoints>   pgons;        //> shape of the crystals
  std::vector<CpolyhPoints>   walls;        //> cryostats
 
  std::vector<CclusterAngles> clust;        //> arrangement of the crystals and cryostats within a cluster
  std::vector<CpolyhPoints>   capsO;        //> encapsulation (outer size)
  std::vector<CpolyhPoints>   capsI;        //> encapsulation (inner size)
  

private:
  G4int                       nEuler;       //> number of clusters composing the array
  G4int                       nPgons;       //> number of different crystal shapes within the array
  G4int                       nClAng;       //> number of crystals composing a cluster
  G4int                       nWalls;       //> number of cryostat parts within a cluster
  

  G4int                       maxPgons;     //> maximum index of crystal shapes

  std::vector<G4int>          crystType;    //> lookup table detector number --> crystal shape
  std::vector<G4int>          planarLUT;    //> lookup table detector number --> planar or not



private:
  G4int                       nWlTot;       //> total number of cryostat parts within the array
  G4int                       maxSolids;    //> maximum number of solids within a cluster
  

  ////////////////////////////////////////////
  /// size of the equivalent germanium shell
  ////////////////////////////////////////////
private:
  G4double                    arrayRmin;     //> inner radius
  G4double                    arrayRmax;     //> outer radius
  
  ///////////////////////////////////////////
  /// rotation applied to the whole array
  //////////////////////////////////////////
private:
  G4double                    thetaShift;   //> theta
  G4double                    phiShift;     //> phi
  G4double                    thetaPrisma;  //> thetaPrisma
  
  ///////////////////////////////////////////
  /// traslation applied to the whole array
  //////////////////////////////////////////
private:
  G4ThreeVector               posShift; 
  
  ///////////////////////////////////////////                               //LR
  /// Cryostats             
  //////////////////////////////////////////
public:
  void SetCryostats(){cryostatStatus = true;};                            //LR

private:
  G4ThreeVector               cryostatPos0;                               //LR
  G4ThreeVector               cryostatPos;                                //LR
  G4RotationMatrix            cryostatRot;                                //LR
  //G4double                    cryostatRadius;                             //LR
  //G4double                    cryostatLength;                             //LR
  G4double                    cryostatZplanes[7];                         //LR
  G4double                    cryostatRinner[7];                          //LR
  G4double                    cryostatRouter[7];                          //LR
  
  ///////////////////////////////////////////////////////////////////////
  /// Code copied directly from AgataDetectorConstruction.hh 
  ///////////////////////////////////////////////////////////////////////

protected:
  G4int     nDets;    //> number of detectors
  G4int     nClus;    //> number of clusters
  G4int     iGMin;    //> minimum index for detectors
  G4int     iCMin;    //> minimum index for clusters
  G4int     iGMax;    //> maximum index for detectors
  G4int     iCMax;    //> maximum index for clusters
  
protected:
  G4int     maxSec;    //> maximum number of sectors
  G4int     maxSli;    //> maximum number of slices
  
protected:
  G4bool    readOut;  //> true: a segmentation have been defined  
  
public:
  inline G4int  GetNumberOfDetectors()    { return nDets;             };
  inline G4int  GetMinDetectorIndex()     { return iGMin;             };
  inline G4int  GetMaxDetectorIndex()     { return iGMax;             };
  
public:
  inline G4int  GetNumberOfClusters()     { return nClus;             };
    inline G4int  GetMinClusterIndex()      { return iCMin;             };
  inline G4int  GetMaxClusterIndex()      { return iCMax;             };
  
public:
  inline G4int  GetNumberOfSectors ()     { return maxSec;            };
  inline G4int  GetNumberOfSlices  ()     { return maxSli;            };
  
public:
  inline G4bool GetReadOut()              { return readOut;           };
  

private:
  void ConstructSegments();
  G4int CalculateSegments(G4int);

  std::vector<CpolyhPoints>   pgSegLl;      //> segments on lower Left  side of edges
  std::vector<CpolyhPoints>   pgSegLu;      //> segments on upper Left  side of edges
  std::vector<CpolyhPoints>   pgSegRl;      //> segments on lower Right side of edges
  std::vector<CpolyhPoints>   pgSegRu;      //> segments on upper Right side of edges

  G4Point3D XPlaneLine( const G4Plane3D &vv, const G4Point3D &pA,  const G4Point3D &pB );

  void ShowStatus();

  G4int     CheckOverlap             ( G4int, G4int, G4int );

  

  /////////////////////////////////////////////////
  /// structures needed to build the segmentation
  ////////////////////////////////////////////////
   
private:
  std::vector<G4int>          nSegments;
  std::vector<G4int>          tSegments;
  G4int                       totSegments;
  G4int                       nSeg;
  
  std::vector<G4double>       segVolume;    //> the volume of the (composite) segment
  std::vector<G4Point3D>      segCenter;    //> the center of mass of the (composite) segment

public:
  G4int GetSegmentNumber(G4int, G4ThreeVector );  

private: 
  
  G4int     GetCoaxSegmentNumber(G4int, G4ThreeVector);    
  G4int     GetPlanSegmentNumber(G4int, G4ThreeVector); 


private:
  G4int                       stepFactor;    //> integration step for the calculation of segment volume
  G4bool                      stepHasChanged;//> true: integration step was changed and segment volumes
                                               //>       should be recomputed


  ///////////////////////////////////////////
  //////////////// inline "get" methods
  ///////////////////////////////////////////
  
public:
  inline G4String              GetEulerFile       () { return eulerFile;   };
  inline G4String              GetSolidFile       () { return solidFile;   };
  inline G4String              GetSliceFile       () { return sliceFile;   };
  inline G4String              GetWallsFile       () { return wallsFile;   };

 
  //////////////////////////////////////////////////
  ///////////// public methods for the messenger
  ////////////////////////////////////////////////// 

public:       
  void SetSolidFile           ( G4String );
  void SetWallsFile           ( G4String );

  void SetAngleFile           ( G4String );
  void SetClustFile           ( G4String );
  
public:       
  void SetDetMate             ( G4String );
  void SetWallsMate           ( G4String );
  
public:      
  void SetThetaShift          ( G4double );
  void SetPhiShift            ( G4double );
  void SetPosShift            ( G4ThreeVector );
  void SetThetaPrisma         ( G4double );
  
public:      
  void SetMakeCapsules        ( G4bool );
  void SetUseCylinder         ( G4bool );
  void SetUsePassive          ( G4bool );
  void SetDrawReadOut         ( G4bool );
  void SetUseAncillary        ( G4bool );
  void SetWriteSegments       ( G4bool );
  void SetStep(G4int);


  //////////////////////////////////////////////////
  ///////////// Analysis related Methods
  ////////////////////////////////////////////////// 

  
public:
  //! Set Crystal EnergyResolution Parameters 
  void          SetFWHM(G4double, G4double, G4double, G4double, G4bool);

  //! Return FWHM Generic response for Gretina crystals
  G4double      FWHM_Response(G4double);

  //! Swicth off Doppler Correction
  inline void   SetDopplerOff    (G4bool f)          {DOPPLER_FLAG=f;};

  //! Return Doppler Correction flag
  inline G4bool DopplerOff       ()                  {return DOPPLER_FLAG;};

private:
  //! FWHM coefficients a 
  G4double FWHMa;
  //! FWHM Coefficients b
  G4double FWHMb;
 
  //! Doppler Correction Flag
  G4bool DOPPLER_FLAG;
  



  
  
};
#endif


