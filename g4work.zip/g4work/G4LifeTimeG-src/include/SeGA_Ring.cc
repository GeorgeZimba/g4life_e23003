#include "SeGA_Ring.hh"

SeGA_Ring::SeGA_Ring(G4LogicalVolume* experimentalHall_log)
 
{
  expHall_log=experimentalHall_log;
  RingID=1;
  GeomFileName =  "./Geometry/SeGA_Barrel.dat";
}

SeGA_Ring::~SeGA_Ring()
{
}
//-----------------------------------------------------------------------
void SeGA_Ring::Construct(G4int ring,G4String DescriptionFile)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__  << G4endl;
#endif  
  GeomFileName = DescriptionFile;
  FILE *fp;
  char      line[256];
  G4int ndet,DetNr,RingNr,Orientation;
  float R,Theta,Phi,Z,Cap,F,G,H;
  RingID=ring;
  ndet = 0;

  vector<SeGA_Detector*>::iterator itPos = theRing.begin();
  // clear all elements from the array
  for(; itPos < theRing.end(); itPos++)
    delete *itPos;    // free the element from memory
  // finally, clear all elements from the array
  theRing.clear();


  // Read Position from file 
  if( (fp = fopen(GeomFileName, "r")) == NULL) {
    G4cout << "\nError opening data file " << GeomFileName << G4endl;
    exit(-1);
  }

  G4cout << "\nReading description of crystals from file " << GeomFileName << " ..." << G4endl;
  
  while(fgets(line, 255, fp) != NULL) {
	 if(strlen(line) < 2) continue;
    if(line[0] == '#') continue;
	 if(sscanf(line,"%d %d %d %f %f %f %f %f %f %f  %f", &RingNr, &DetNr,&Orientation, &R, &Theta, &Phi, &Z, &Cap, &F, &G, &H) != 11) break;
#ifdef DEBUG
	 cout <<DetNr <<  " " << RingID<<" " << Orientation << " " <<Theta << " " <<Phi << " " << R<< " " << Z<< " " << Cap<< " " << F<< " "<< G << " " << H<< " " <<  endl;
#endif
	 if(RingNr==RingID) {
		theRing.push_back(new SeGA_Detector(expHall_log));     
		theRing[ndet]->Construct(ndet,RingID,Orientation,Theta*deg,Phi*deg,R*cm,Z*cm,Cap*cm);
		theRing[ndet]->setF(F);
		theRing[ndet]->setG(G);
		theRing[ndet]->setH(H);
		theRing[ndet]->setID(DetNr);
		ndet++;		  
	 }
  }
  
  G4cout << ndet << " detector placed in Ring Nr " << RingID  << G4endl;
  fclose(fp);


}
//-----------------------------------------------------------------------

void SeGA_Ring::MakeSensitive(TrackerGammaSD* TrackerGamma)
{

  vector<SeGA_Detector*>::iterator itPos = theRing.begin();

  for(;itPos<theRing.end();itPos++)  
	 (*itPos)->GetCellLog()->SetSensitiveDetector(TrackerGamma);

}
//-----------------------------------------------------------------------

void SeGA_Ring::DopplerOn()
{

  vector<SeGA_Detector*>::iterator itPos = theRing.begin();

  for(;itPos<theRing.end();itPos++)  
	 (*itPos)->DopplerOn();

}
//-----------------------------------------------------------------------

void SeGA_Ring::DopplerOff()
{

  vector<SeGA_Detector*>::iterator itPos = theRing.begin();

  for(;itPos<theRing.end();itPos++)  
	 (*itPos)->DopplerOff();

}
//-----------------------------------------------------------------------

SeGA_Detector* SeGA_Ring::GetDetector(G4int num)
{

  vector<SeGA_Detector*>::iterator itPos = theRing.begin();
  return (*(itPos+num));

}
//--------------------------------------------------------------------
void SeGA_Ring::CalcSegCenters(G4ThreeVector DoppPos)
{

  vector<SeGA_Detector*>::iterator itPos = theRing.begin();

  for(;itPos<theRing.end();itPos++)  
	 (*itPos)->CalcSegCenters(DoppPos);

}
//--------------------------------------------------------------------
void SeGA_Ring::ReportSegments()
{
  vector<SeGA_Detector*>::iterator itPos = theRing.begin();
  for(;itPos<theRing.end();itPos++) 
	 (*itPos)->ReportSegments();
  
}
