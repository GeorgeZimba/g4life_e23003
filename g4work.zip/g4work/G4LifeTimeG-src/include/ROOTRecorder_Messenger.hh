#ifndef ROOTRecorder_Messenger_h
#define ROOTRecorder_Messenger_h 1

#include "ROOTRecorder.hh"

#include "G4UImessenger.hh"
#include "globals.hh"
#include "G4UIcmdWithAnInteger.hh"
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class G4UIdirectory;
class G4UIcommand;
class G4UIcmdWithAString;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

class ROOTRecorder_Messenger: public G4UImessenger
{
public:

  ROOTRecorder_Messenger(ROOTRecorder* );
  ~ROOTRecorder_Messenger();

  void SetNewValue(G4UIcommand* ,G4String );
  
private:
  
  ROOTRecorder* Recorder;
  
  G4UIdirectory*			RecorderDir;   

  G4UIcmdWithAString*		FileCmd;

  //! Save SeGA Gamma ray events to ROOT tree
  G4UIcmdWithoutParameter* STSGCmd;
  //! Save Gretina Gamma ray events to ROOT tree
  G4UIcmdWithoutParameter* STGGCmd;
  //! Save Ions events to ROOT tree
  G4UIcmdWithoutParameter* STICmd;
  //! Create Histrogram for Sega Gamma rays
  G4UIcmdWithoutParameter* SHSGCmd;
  //! Create Histrogram for Sega Segments Gamma rays
  G4UIcmdWithoutParameter* SHGSCmd;
  //! Create Histrogram for Gretina Gamma rays
  G4UIcmdWithoutParameter* SHGGCmd;
  //! Create Histrogram for Heavy Ions
  G4UIcmdWithoutParameter* SHICmd;
  //! Create Histrogram for Cascade Analysis
  G4UIcmdWithoutParameter* CASCCmd;
};

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#endif
