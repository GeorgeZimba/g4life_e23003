
#include "Incoming_Beam.hh"


Incoming_Beam::Incoming_Beam()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  A=20;
  Z=12;
  Ex=0.;
  KEu=100*MeV;
  KE=KEu*A;
  Dpp=0.0;
  fcX=0.;
  fcDX=0.;
  fcY=0.;
  fcDY=0.;
  fcZ=-50.*cm;
  maxAta=0*mrad;
  maxBta=0*mrad;
  ata0=0.*mrad;
  bta0=0.*mrad;
  //AR New in v4.3 -> To use Gaussian distributions for incoming beam direction and position
  DIR_GAUS_FLAG = FALSE;
  POS_GAUS_FLAG = FALSE;
}

Incoming_Beam::~Incoming_Beam()
{;}
//---------------------------------------------------------
void Incoming_Beam::Report()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
 G4cout<<"\033[1m\033[31m-------------------- InBeam Report ------------------  \033[0m" << G4endl;
 
  G4cout<<"\t----> Z of the incoming beam set to  "<<Z<< G4endl;
  G4cout<<"\t----> A of the incoming beam set to  "<<A<< G4endl;
  G4cout<<"\t----> Kin. En. of the incoming beam set to "<<
	 G4BestUnit(KE,"Energy")<<G4endl;
  G4cout<<"\t----> Kin. En. per nucleon of the incoming beam set to "<<
	 G4BestUnit(KEu,"Energy")<<G4endl;
  G4cout<<"\t----> momentum acceptance for the incoming beam set to  "<<Dpp<< G4endl;
  G4cout<<"\t----> focal point X position for the incoming beam set to  "<<G4BestUnit(fcX,"Length")<< G4endl;
  G4cout<<"\t----> focal point DX size for the incoming beam set to  "<<G4BestUnit(fcDX,"Length")<< G4endl;
  G4cout<<"\t----> focal point Y position for the incoming beam set to  "<<G4BestUnit(fcY,"Length")<< G4endl;
  G4cout<<"\t----> focal point DY size for the incoming beam set to  "<<G4BestUnit(fcDY,"Length")<< G4endl;
  G4cout<<"\t----> focal point Z position for the incoming beam set to  "<<G4BestUnit(fcZ,"Length")<< G4endl;
  G4cout<<"\t----> dispersive direction angular divergence for the incoming beam set to  "<<maxAta/mrad<<" mrad = "<<maxAta/deg<<" deg"<< G4endl;
  G4cout<<"\t----> non dispersive direction angular divergence for the incoming beam set to  "<<maxBta/mrad<<" mrad = "<<maxBta/deg<<" deg"<< G4endl;

 G4cout<<"\033[1m\033[31m---------------- End of InBeam Report ---------------  \033[0m" << G4endl<< G4endl;
 

}
//---------------------------------------------------------
void Incoming_Beam::setA(G4int Ain)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  A=Ain;
  G4cout<<"\t----> A of the incoming beam set to  "<<A<< G4endl;
  
}
//---------------------------------------------------------
void Incoming_Beam::setZ(G4int Zin)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  Z=Zin;
  G4cout<<"\t----> Z of the incoming beam set to  "<<Z<< G4endl;
  
}
//---------------------------------------------------------
void Incoming_Beam::setDpp(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  Dpp=d;
  G4cout<<"\t----> momentum acceptance for the incoming beam set to  "<<Dpp<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setfcX(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  fcX=d;
  G4cout<<"\t----> focal point X position for the incoming beam set to  "<<G4BestUnit(fcX,"Length")<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setfcDX(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  fcDX=d;
  G4cout<<"\t----> focal point DX size for the incoming beam set to  "<<G4BestUnit(fcDX,"Length")<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setfcDY(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  fcDY=d;
  G4cout<<"\t----> focal point DY size for the incoming beam set to  "<<G4BestUnit(fcDY,"Length")<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setfcY(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  fcY=d;
  G4cout<<"\t----> focal point Y position for the incoming beam set to  "<<G4BestUnit(fcY,"Length")<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setfcZ(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  fcZ=d;
  G4cout<<"\t----> focal point Z position for the incoming beam set to  "<<G4BestUnit(fcZ,"Length")<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setmaxAta(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  maxAta=d;
  G4cout<<"\t----> dispersive direction angular divergence for the incoming beam set to  "<<maxAta/mrad<<" mrad = "<<maxAta/deg<<" deg"<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setmaxBta(G4double d)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  maxBta=d;
  G4cout<<"\t----> non dispersive direction angular divergence for the incoming beam set to  "<<maxBta/mrad<<" mrad = "<<maxBta/deg<<" deg"<< G4endl;
}
//---------------------------------------------------------
void Incoming_Beam::setKE(G4double KEin)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  KE=KEin;
  KEu=KE/A;
  G4cout<<"\t----> Kin. En. of the incoming beam set to "<<
	 G4BestUnit(KE,"Energy")<<G4endl;
  G4cout<<"\t----> Kin. En. per nucleon of the incoming beam set to "<<
	 G4BestUnit(KEu,"Energy")<<G4endl;
}
//-----------------------------------------------------------------
void Incoming_Beam::setKEu(G4double KEuin)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif

  KEu=KEuin;
  KE=KEu*A;
  G4cout<<"\t----> Kin. En. of the incoming beam set to "<<
	 G4BestUnit(KE,"Energy")<<G4endl;
  G4cout<<"\t----> Kin. En. per nucleon of the incoming beam set to "<<
	 G4BestUnit(KEu,"Energy")<<G4endl; 
}
//---------------------------------------------------------
G4ThreeVector Incoming_Beam::getDirection()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  G4ThreeVector direction;
  G4double x,y,z,a,b,r,phi;

  if(!DIR_GAUS_FLAG){
    phi=G4UniformRand()*8.*atan(1.);
    r=G4UniformRand()+G4UniformRand();
    if(r>=1) r=-(r-2.);

    a=r*cos(phi)*maxAta;
    b=r*sin(phi)*maxBta;
  }else{ //AR New in v4.3 -> Gaussian distributions for incoming beam direction
    //G4cout<<"\t----> Gaussian distribution for incoming beam direction " <<G4endl;
    a=G4RandGauss::shoot(0.,maxAta);
    b=G4RandGauss::shoot(0.,maxBta);
  }
  z=1./sqrt(1.+tan(a)*tan(a)+tan(b)*tan(b));
  y=z*tan(b);
  x=z*tan(a);
  direction.setX(x);
  direction.setY(y);
  direction.setZ(z);
  direction.rotateY(ata0);
  direction.rotateX(-bta0);
  return direction;

}
//---------------------------------------------------------
G4ThreeVector Incoming_Beam::getPosition()
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  
  G4ThreeVector position;
  G4double x,y;
  G4double r,phi;

  if(!POS_GAUS_FLAG){
    phi=G4UniformRand()*8.*atan(1.);
    r=G4UniformRand()+G4UniformRand();
    if(r>=1) r=-(r-2.);

    x=fcX+r*cos(phi)*fcDX/2.;
    y=fcY+r*sin(phi)*fcDY/2.;
  }else{
    //AR New in v4.3 -> Use Gaussian distribution for incoming beam position
    //G4cout<<"\t----> Gaussian distribution for incoming beam position " <<G4endl;
    x=G4RandGauss::shoot(fcX/mm,fcDX*mm);
    y=G4RandGauss::shoot(fcY/mm,fcDY*mm);
  }
  position.setX(x);
  position.setY(y);
  position.setZ(fcZ);
  return position;

}

//---------------------------------------------------------
G4double Incoming_Beam::getKE(G4ParticleDefinition *ion)
{
#ifdef DEBUG
  G4cout << __PRETTY_FUNCTION__ << G4endl;
#endif
  
  G4DynamicParticle dynamic;
  G4ThreeVector momentum_vector;
  G4double momentum;
  G4double rand;
  G4double KinEne;
  momentum_vector.set(0.,0.,1.);
  momentum_vector.setZ(1.);
  dynamic=G4DynamicParticle(ion,momentum_vector,KE);
  momentum=dynamic.GetTotalMomentum();
  rand=G4UniformRand()-0.5;
  momentum*=(1+rand*Dpp);
  momentum_vector.setMag(momentum);
  dynamic.SetMomentum(momentum_vector);
  KinEne=dynamic.GetKineticEnergy();
    
  return KinEne;
  
}
