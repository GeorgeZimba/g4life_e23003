#ifndef SeGA_Array_Messenger_h
#define SeGA_Array_Messenger_h 1

#include "SeGA_Array.hh"
#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithAnInteger.hh"

class SeGA_Array_Messenger: public G4UImessenger
{
public:
  SeGA_Array_Messenger(SeGA_Array*);
  ~SeGA_Array_Messenger();
    
  void SetNewValue(G4UIcommand*, G4String);
    
private:
  SeGA_Array* the_SeGA_Array;
    
  G4UIdirectory*             SeGA_Array_Dir;
  G4UIcmdWithoutParameter*   RepST;
  G4UIcmdWithoutParameter*   RepCmd;
};


#endif

