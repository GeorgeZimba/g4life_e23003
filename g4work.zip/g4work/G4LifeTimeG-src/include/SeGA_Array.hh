#ifndef SeGA_Array_H
#define SeGA_Array_H 1

#include "G4RunManager.hh"
#include "G4LogicalVolume.hh"
#include "SeGA_Ring.hh"
#include "TrackerGammaSD.hh"
#include "G4ThreeVector.hh"
#include "globals.hh"
#include <iostream>
#include <vector>
using namespace std;
class SeGA_Array 
{
  public:

    SeGA_Array(G4LogicalVolume*);
    ~SeGA_Array();

  void Construct(G4String);
  void MakeSensitive(TrackerGammaSD*);
  SeGA_Ring* GetRing(G4int);
  void DopplerOn();
  void DopplerOff();
  void CalcSegCenters(G4ThreeVector);
  void ReportSegments();
  void Report();

 
private:

  vector<SeGA_Ring*> the_Plunger_SeGA;

  G4LogicalVolume* expHall_log;
  G4String GeomFileName;
 
};

#endif

