#ifndef Analysis_Messenger_h
#define Analysis_Messenger_h 1
#include "Analysis.hh"

#include "globals.hh"
#include "G4UImessenger.hh"
#include "G4UIdirectory.hh"
#include "G4UIcmdWithAString.hh"
#include "G4UIcmdWithADoubleAndUnit.hh"
#include "G4UIcmdWithADouble.hh"
#include "G4UIcmdWithoutParameter.hh"
#include "G4UIcmdWithAnInteger.hh"

class G4UIdirectory;
class G4UIcommand;
class G4UIcmdWithAString;
class Analysis;

class Analysis_Messenger: public G4UImessenger
{
  public:

   Analysis_Messenger(Analysis*);
  ~Analysis_Messenger();

   void SetNewValue(G4UIcommand* ,G4String );

  private:
  Analysis* 	Ana;
  G4UIdirectory*          AnaDir;   

  G4UIcmdWithoutParameter*   RepCmd;

  //AR Added for v4.3 -> Disable a Gretine Crystal in the analysis
  G4UIcmdWithAnInteger* GretDisCrysCmd;

  //AR Added for v4.3 -> To use Rob's Cascade algorythm
  G4UIdirectory*          CascadeAnalysisDir;   
  G4UIcmdWithoutParameter* CascadeAnalysisOnCmd;
  G4UIcmdWithADouble* CascadeAnalysisELowCmd;
  G4UIcmdWithADouble* CascadeAnalysisEHighCmd;
  G4UIcmdWithADouble* CascadeAnalysisETrueCmd;
  
  //Acceptance 
  G4UIdirectory*          AccDir;   

  G4UIcmdWithoutParameter* ACConCmd;
  G4UIcmdWithADoubleAndUnit*  AThLCmd;
  G4UIcmdWithADoubleAndUnit* AThHCmd;
  G4UIcmdWithADouble* ADLCmd;
  G4UIcmdWithADouble* ADHCmd;

  // Doppler Correction
  G4UIdirectory*             DopDir;    

  G4UIcmdWithoutParameter* TDUZACmd;
  G4UIcmdWithoutParameter* TDUDACmd;
  G4UIcmdWithoutParameter* TDUBIACmd;
  G4UIcmdWithoutParameter* TDUTBACmd;
  G4UIcmdWithoutParameter* TDUDBACmd;
  G4UIcmdWithoutParameter* TDUSBACmd;
  G4UIcmdWithoutParameter* TDUTDCmd;
  G4UIcmdWithoutParameter* TDUTCCmd;
  G4UIcmdWithoutParameter* TDUDCCmd;
  G4UIcmdWithoutParameter* TDUSCCmd;
  G4UIcmdWithoutParameter* TDUSDCmd;
  G4UIcmdWithoutParameter* TDUFICmd;
  G4UIcmdWithoutParameter* TDULSCmd;
  G4UIcmdWithoutParameter* TDUTBCmd;
  G4UIcmdWithoutParameter* TDUSBCmd;
  G4UIcmdWithoutParameter* TDUBBCmd;
  G4UIcmdWithoutParameter* TDUDBBCmd;
  G4UIcmdWithoutParameter* TDUSBBCmd;

  G4UIcmdWithoutParameter* TDFonCmd;
  G4UIcmdWithoutParameter* STRCmd;
  G4UIcmdWithoutParameter* GTRCmd;
  
  G4UIcmdWithADoubleAndUnit* GrGammaPosCmd;
  G4UIcmdWithADoubleAndUnit* GrGammaAddCmd;

};

#endif
