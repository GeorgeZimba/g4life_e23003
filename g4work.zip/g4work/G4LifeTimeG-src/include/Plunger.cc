#include "Plunger.hh"
Plunger::Plunger(G4LogicalVolume* experimentalHall_log,Materials* mat, G4int pType, G4bool pShield)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  expHall_log=experimentalHall_log;
  materials=mat;
  PlungerType = pType;

  Degrader_side_x=50*mm;
  Degrader_side_y=50*mm;
  //TM changed from 1 mm distance 6/20/2018 
  //Degrader_thickness=1.0*mm;
  Degrader_thickness=0.001*mm;
  Target_side_x=50*mm;
  Target_side_y=50*mm;
  //TM changed from 1 mm distance 6/20/2018 
  //Target_thickness=1.0*mm;
  Target_thickness=0.001*mm;
  Stopper_side_x=50*mm;
  Stopper_side_y=50*mm;
  //TM changed from 1 mm distance 6/20/2018 
  //Stopper_thickness=1.0*mm;
  Stopper_thickness=0.001*mm;
  Pos = new G4ThreeVector();
  Pos->setX(0.00*mm);
  Pos->setY(0.00*mm);
  Pos->setZ(0.00*mm);
  //TM changed from 5 mm distance 6/20/2018 - read in input tree 
  D=0.0001*mm;
  D2=0.0001*mm;
  DegraderMaterial = materials->FindMaterial("Be");
  TargetMaterial = materials->FindMaterial("Be");
  StopperMaterial = materials->FindMaterial("Be");
  //TM   6/20/2018
  //Ratio=1.;
  Ratio=0.0001;
  RR=Ratio/(Ratio+1.);
  //TM 6/20/2018
  //Ratio2=1.;
  Ratio2=0.0001;
  RR2=Ratio2/(Ratio2+1.);
  NstepTar=10;
  NstepDeg=10;
  NstepSto=10;
  
  //TM added  6/20/2018 
  TargetScaleDensity = 0.001;
  DegraderScaleDensity = 0.001;
  StopperScaleDensity = 0.001;

  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  Shield_Flag = pShield;
  Shield_material = materials->FindMaterial("Pb");
  Shield_start = -63.12*cm;
  Shield_rmin = 3.0226*cm;    
  Shield_rmax = 6.0325*cm;
  Shield_len = 19.05*cm;
  Shield_pos = new G4ThreeVector();
  Shield_pos->setX(0.00*mm);
  Shield_pos->setY(0.00*mm);
  Shield_pos->setZ(0.00*mm);
}

Plunger::~Plunger()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
}
//-----------------------------------------------------------------------------
void Plunger::Construct()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  // Colors for Visu
   G4Colour red (1.0,0.0, 0.0); 
	G4VisAttributes* Vis_6 = new G4VisAttributes(red);
	Vis_6->SetVisibility(true);
	Vis_6->SetForceSolid(true);
	
	G4Colour blue (0.0,0.0, 1.0); 
	G4VisAttributes* Vis_8 = new G4VisAttributes(blue);
	Vis_8->SetVisibility(true);
	Vis_8->SetForceSolid(true);

	G4Colour green (0.0,1.0, 0.0);
	G4VisAttributes* Vis = new G4VisAttributes(green);
	Vis->SetVisibility(true);
	Vis->SetForceSolid(true);
	
	// Target 
	aTarget = new G4Box("target",Target_side_x/2.,Target_side_y/2.,Target_thickness/2.);
	
	Target_log = new G4LogicalVolume(aTarget,TargetMaterial,"target_log",0,0,0);
	target_limits= new G4UserLimits();
	target_limits->SetMaxAllowedStep(Target_thickness/NstepTar);
	Target_log->SetUserLimits(target_limits);
	
	if(PlungerType == 0) {
	  Pos->setZ(0.*mm);
	  Target_phys = new G4PVPlacement(G4Transform3D(NoRot,*Pos),Target_log,"target",expHall_log,false,0);
	}
	if(PlungerType == 1 || PlungerType == 2){
	  
	  aDegrader = new G4Box("degrader",Degrader_side_x/2.,Degrader_side_y/2.,Degrader_thickness/2.);
	  
	  Degrader_log = new G4LogicalVolume(aDegrader,DegraderMaterial,"degrader_log",0,0,0);
	  degrader_limits= new G4UserLimits();
	  degrader_limits->SetMaxAllowedStep(Degrader_thickness/NstepDeg); 
	  Degrader_log->SetUserLimits(degrader_limits);
	  
	  Degrader_phys = new G4PVPlacement(G4Transform3D(NoRot,*Pos),Degrader_log,"degrader",expHall_log,false,0);
	  
	  Pos->setZ(-10*D);
	  Target_phys = new G4PVPlacement(G4Transform3D(NoRot,*Pos),Target_log,"target",expHall_log,false,0);
	  Pos->setZ(0.*mm);
	  SetSeparation(D);
	  
	  Degrader_log->SetVisAttributes(Vis_6);
	 
	  if(PlungerType == 2){
		 aStopper = new G4Box("stopper",Stopper_side_x/2.,Stopper_side_y/2.,Stopper_thickness/2.);
		 Stopper_log = new G4LogicalVolume(aStopper,StopperMaterial,"stopper_log",0,0,0);
		 stopper_limits= new G4UserLimits();
		 stopper_limits->SetMaxAllowedStep(Stopper_thickness/NstepSto);
		 Stopper_log->SetUserLimits(stopper_limits);
		 Pos->setZ(+10*D2);
		 Stopper_phys = new G4PVPlacement(G4Transform3D(NoRot,*Pos),Stopper_log,"stopper",expHall_log,false,0);
		 SetSeparation2(D2);
		 
		 Stopper_log->SetVisAttributes(Vis_8);
	  }
	  
	  //			Pos->setZ(0.*mm);
	  
  }
  
  Target_log->SetVisAttributes(Vis);

  //AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
  if(Shield_Flag){
   
    
    G4int NstepShield = 200; 
  
    G4double Shield_cent = Shield_start+0.5*Shield_len;

    aShieldCy = new G4Tubs("ShieldCy",Shield_rmin,Shield_rmax,Shield_len/2.,10.*deg,350.*deg);

    Shield_log = new G4LogicalVolume(aShieldCy,Shield_material,"shield_log",0,0,0);

    G4UserLimits *Shield_limits;
    Shield_limits = new G4UserLimits();
    Shield_limits->SetMaxAllowedStep(Shield_len/NstepShield); 
    Shield_log->SetUserLimits(Shield_limits);

    Shield_pos->setZ(Shield_cent);

    G4RotationMatrix rot1 = G4RotationMatrix();
    rot1.rotateZ(265.*deg);

    Shield_phys = new G4PVPlacement(G4Transform3D(rot1,*Shield_pos),Shield_log,"shield",expHall_log,false,0);
  
    G4Colour gray (0.6,0.6,0.6); 
    G4VisAttributes* Vis_gray = new G4VisAttributes(gray);
    Vis_gray->SetVisibility(true);
    Vis_gray->SetForceSolid(true);
    Shield_log->SetVisAttributes(Vis_gray);
  }

}
//-----------------------------------------------------------------------------
void Plunger::SetSeparation(G4double d)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  if(PlungerType != 0){
	 D=d;
	 G4ThreeVector Sep;
	 Sep.setX(Pos->getX());
	 Sep.setY(Pos->getY());
	 Sep.setZ(Pos->getZ()-(Target_thickness/2.+Degrader_thickness/2+D));
	 Target_phys->SetTranslation(Sep);
	 
	 Sep=Target_phys->GetTranslation();
	 d=-Sep.getZ()+Pos->getZ()-Target_thickness/2.-Degrader_thickness/2;
	 
	 G4RunManager::GetRunManager()->GeometryHasBeenModified();
	 
	 G4cout<<"----> Degrader/Target separation is set to "<<G4BestUnit(d,"Length")<<G4endl;
  }

}
//-----------------------------------------------------------------------------
void Plunger::SetSeparation2(G4double d2)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  D2=d2;
  G4ThreeVector Sep2;
  Sep2.setX(Pos->getX());
  Sep2.setY(Pos->getY());
  Sep2.setZ(Pos->getZ()+(Stopper_thickness/2.+Degrader_thickness/2+D2));
  Stopper_phys->SetTranslation(Sep2);

  Sep2=Stopper_phys->GetTranslation();
  d2= Sep2.getZ()-Pos->getZ()-Stopper_thickness/2.-Degrader_thickness/2;

  G4RunManager::GetRunManager()->GeometryHasBeenModified();

  G4cout<<"----> Degrader/Stopper separation is set to "<<G4BestUnit(d2,"Length")<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetDegX(G4double X)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Degrader_side_x=X;
  aDegrader->SetXHalfLength(Degrader_side_x/2.);
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
  G4cout<<"----> Degrader side X is set to "<<G4BestUnit(2.*aDegrader->GetXHalfLength(),"Length")<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetDegY(G4double Y)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Degrader_side_y=Y;
  aDegrader->SetYHalfLength(Degrader_side_y/2.);
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
  G4cout<<"----> Degrader side Y is set to "<<G4BestUnit(2.*aDegrader->GetYHalfLength(),"Length")<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetDegZ(G4double Z)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Degrader_thickness=Z;
  aDegrader->SetZHalfLength(Degrader_thickness/2.);
  degrader_limits->SetMaxAllowedStep(Degrader_thickness/NstepDeg);
  Degrader_log->SetUserLimits(degrader_limits);
  G4cout<<"----> Degrader thickness is set to "<<G4BestUnit(2.*aDegrader->GetZHalfLength(),"Length")<<G4endl;
  SetSeparation(D);
  if(PlungerType == 2){
	  SetSeparation2(D2);
  }
}
//-----------------------------------------------------------------------------
void Plunger::SetRatio(G4double r)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Ratio=r;
  RR=Ratio/(Ratio+1);
  G4cout<<"----> Ratio of target/degrader reactions set to "<<Ratio<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetRatio2(G4double r2)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Ratio2=r2;
  RR2=Ratio2/(Ratio2+1);
  G4cout<<"----> Ratio2 of stopper/degrader reactions set to "<<Ratio2<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetTarX(G4double X)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Target_side_x=X;
  aTarget->SetXHalfLength(Target_side_x/2.);
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
  G4cout<<"----> Target side X is set to "<<G4BestUnit(2.*aTarget->GetXHalfLength(),"Length")<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetTarY(G4double Y)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Target_side_y=Y;
  aTarget->SetYHalfLength(Target_side_y/2.);
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
  G4cout<<"----> Target side Y is set to "<<G4BestUnit(2.*aTarget->GetYHalfLength(),"Length")<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetTarZ(G4double Z)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Target_thickness=Z;
  aTarget->SetZHalfLength(Target_thickness/2.);
  target_limits->SetMaxAllowedStep(Target_thickness/NstepTar);
  Target_log->SetUserLimits(target_limits);
  G4cout<<"----> Target thickness is set to "<<G4BestUnit(2.*aTarget->GetZHalfLength(),"Length")<<G4endl;
  if(PlungerType != 0) {
	 SetSeparation(D);
  }
}
//-----------------------------------------------------------------------------
void Plunger::SetPosZ(G4double z)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  G4ThreeVector P;
  Pos->setZ(z);
  P.setX(Pos->getX());
  P.setY(Pos->getY());
  P.setZ(Pos->getZ());
  
  if(PlungerType == 0) {
 	 Target_phys->SetTranslation(P);
	 G4cout<<"----> Target Z position set to "<<G4BestUnit(Target_phys->GetTranslation().getZ(),"Length")<<G4endl;
	 
  }
  else{
	 Degrader_phys->SetTranslation(P);
	 G4cout<<"----> Plunger Z position set to "<<G4BestUnit(Degrader_phys->GetTranslation().getZ(),"Length")<<G4endl;
	 SetSeparation(D);
	 if(PlungerType == 2){
		SetSeparation2(D2);
	 }
  }
}
//-----------------------------------------------------------------------------
void Plunger::SetStoX(G4double X)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Stopper_side_x=X;
  aStopper->SetXHalfLength(Stopper_side_x/2.);
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
  G4cout<<"----> Stopper side X is set to "<<G4BestUnit(2.*aStopper->GetXHalfLength(),"Length")<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetStoY(G4double Y)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Stopper_side_y=Y;
  aStopper->SetYHalfLength(Stopper_side_y/2.);
  G4RunManager::GetRunManager()->GeometryHasBeenModified();
  G4cout<<"----> Stopper side Y is set to "<<G4BestUnit(2.*aStopper->GetYHalfLength(),"Length")<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetStoZ(G4double Z)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Stopper_thickness=Z;
  aStopper->SetZHalfLength(Stopper_thickness/2.);
  stopper_limits->SetMaxAllowedStep(Stopper_thickness/NstepSto);
  Stopper_log->SetUserLimits(stopper_limits);
  G4cout<<"----> Stopper thickness is set to "<<G4BestUnit(2.*aStopper->GetZHalfLength(),"Length")<<G4endl;
  SetSeparation2(D2);
}
//---------------------------------------------------------------------
void Plunger::SetDegMaterial(G4String materialName)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  // search the material by its name 
  DegraderMaterial = materials->FindMaterial(materialName);  
  Degrader_log->SetMaterial(DegraderMaterial);
  G4cout<<"----> Degrader material set to     "<<Degrader_log->GetMaterial()->GetName()<< G4endl;                 
}
//---------------------------------------------------------------------
void Plunger::SetTarMaterial(G4String materialName)
{
  // search the material by its name 
  TargetMaterial = materials->FindMaterial(materialName);  
  Target_log->SetMaterial(TargetMaterial);
  G4cout<<"----> Target material set to     "<<Target_log->GetMaterial()->GetName()<< G4endl;                 
}
//---------------------------------------------------------------------
void Plunger::SetStoMaterial(G4String materialName)
{
  // search the material by its name 
  StopperMaterial = materials->FindMaterial(materialName);  
  Stopper_log->SetMaterial(StopperMaterial);
  G4cout<<"----> Stopper material set to     "<<Stopper_log->GetMaterial()->GetName()<< G4endl;                 
}
//---------------------------------------------------------------------
void Plunger::ScaleTarDensity(G4double scale)
{
  // search the material by its name 
  G4String name=TargetMaterial->GetName();
  G4double Z=TargetMaterial->GetZ();
  G4double A=TargetMaterial->GetA();
  G4double density=TargetMaterial->GetDensity();
  density*=scale;
  TargetMaterial=new G4Material(name, Z,A,density);
  Target_log->SetMaterial(TargetMaterial);
  G4cout<<"----> Target material set to     "<<Target_log->GetMaterial()->GetName()<< G4endl;  
  G4cout<<"----> Target Z set to            "<<Target_log->GetMaterial()->GetZ()<< G4endl;  
  G4cout<<"----> Target mole mass set to       "<<Target_log->GetMaterial()->GetA()/g*mole<<" g/mole"<< G4endl;  
  G4cout<<"----> Target density set to         "<<Target_log->GetMaterial()->GetDensity()/g*cm3<<" g/cm3"<< G4endl;     
             
}
//---------------------------------------------------------------------
void Plunger::ScaleDegDensity(G4double scale)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  // search the material by its name 
  G4String name=DegraderMaterial->GetName();
  G4double Z=DegraderMaterial->GetZ();
  G4double A=DegraderMaterial->GetA();
  G4double density=DegraderMaterial->GetDensity();
  density*=scale;
  DegraderMaterial=new G4Material(name, Z,A,density);
  Degrader_log->SetMaterial(DegraderMaterial);
  G4cout<<"----> Degrader material set to     "<<Degrader_log->GetMaterial()->GetName()<< G4endl;  
  G4cout<<"----> Degrader Z set to            "<<Degrader_log->GetMaterial()->GetZ()<< G4endl;  
  G4cout<<"----> Degrader mole mass set to       "<<Degrader_log->GetMaterial()->GetA()/g*mole<<" g/mole"<< G4endl;  
  G4cout<<"----> Degrader density set to         "<<Degrader_log->GetMaterial()->GetDensity()/g*cm3<<" g/cm3"<< G4endl;     
             
}
//---------------------------------------------------------------------
void Plunger::ScaleStoDensity(G4double scale)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  // search the material by its name 
  G4String name=StopperMaterial->GetName();
  G4double Z=StopperMaterial->GetZ();
  G4double A=StopperMaterial->GetA();
  G4double density=StopperMaterial->GetDensity();
  density*=scale;
  StopperMaterial=new G4Material(name, Z,A,density);
  Stopper_log->SetMaterial(StopperMaterial);
  G4cout<<"----> Stopper material set to     "<<Stopper_log->GetMaterial()->GetName()<< G4endl;  
  G4cout<<"----> Stopper Z set to            "<<Stopper_log->GetMaterial()->GetZ()<< G4endl;  
  G4cout<<"----> Stopper mole mass set to    "<<Stopper_log->GetMaterial()->GetA()/g*mole<<" g/mole"<< G4endl;  
  G4cout<<"----> Stopper density set to      "<<Stopper_log->GetMaterial()->GetDensity()/g*cm3<<" g/cm3"<< G4endl;     
             
}
//-------------------------------------------------------------------
void Plunger::setDegraderReactionDepth(G4double depth)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  //  G4cout<<"\n----> The degrader reaction depht is "<<G4BestUnit(depth,"Length")<< G4endl;;
  degrader_limits->SetUserMinRange(depth);
  target_limits->SetUserMinRange(-1.*m);
  if(PlungerType == 2) stopper_limits->SetUserMinRange(-1.*m);
}
//-------------------------------------------------------------------
void Plunger::setTargetReactionDepth(G4double depth)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  //  G4cout<<"\n----> The target reaction depht is "<<G4BestUnit(depth,"Length")<< G4endl;;
  target_limits->SetUserMinRange(depth);
  
  if(PlungerType > 0) {
	 degrader_limits->SetUserMinRange(-1.*m);
	 
	 if(PlungerType == 2) {
	 stopper_limits->SetUserMinRange(-1.*m);
	 }
  }
}
//-------------------------------------------------------------------
void Plunger::setStopperReactionDepth(G4double depth)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  //  G4cout<<"\n----> The target reaction depht is "<<G4BestUnit(depth,"Length")<< G4endl;;
  stopper_limits->SetUserMinRange(depth);
  target_limits->SetUserMinRange(-1.*m);
  degrader_limits->SetUserMinRange(-1.*m);
}
//-----------------------------------------------------------------------------
void Plunger::Report()
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  G4cout<<"\033[1m\033[31m-------------------- Plunger Report ------------------  \033[0m" << G4endl;
  
  switch(PlungerType){
  case 0 : // Target Only
	 G4cout<<"----> Target Only !! "<< G4endl;  
	 break;
  case 1 : // Standard Plunger
	 G4cout<<"----> Standard Plunger !! "<< G4endl;  

	 break;
  case 2 : // Diff Plunger
 	 G4cout<<"----> Differential Plunger !! "<< G4endl;  

	 break;
  }  

 
  G4cout<<"\033[1m\033[33m------------- Target ----------------- \033[0m" << G4endl;
  G4cout<<"\t----> Target material set to        "<<Target_log->GetMaterial()->GetName()<< G4endl;  
  G4cout<<"\t----> Target Z set to               "<<Target_log->GetMaterial()->GetZ()<< G4endl;  
  G4cout<<"\t----> Target mole mass set to       "<<Target_log->GetMaterial()->GetA()/g*mole<<" g/mole"<< G4endl;  
  G4cout<<"\t----> Target density set to         "<<Target_log->GetMaterial()->GetDensity()/g*cm3<<" g/cm3"<< G4endl;          
  G4cout<<"\t----> Target side X is set to       "<<G4BestUnit(2.*aTarget->GetXHalfLength(),"Length")<<G4endl;
  G4cout<<"\t----> Target side Y is set to       "<<G4BestUnit(2.*aTarget->GetYHalfLength(),"Length")<<G4endl;  
  G4cout<<"\t----> Target thickness is set to    "<<G4BestUnit(2.*aTarget->GetZHalfLength(),"Length")<<G4endl;
  G4cout<<"\t----> Target Z position is set to   "<<G4BestUnit(Target_phys->GetTranslation().getZ(),"Length")<<G4endl;

  if(PlungerType == 1 || PlungerType == 2) {
	 G4cout<<"\033[1m\033[33m------------- Degrader ----------------- \033[0m" << G4endl;
	 G4cout<<"\t----> Degrader material set to     "<<Degrader_log->GetMaterial()->GetName()<< G4endl;  
	 G4cout<<"\t----> Degrader Z set to            "<<Degrader_log->GetMaterial()->GetZ()<< G4endl;  
	 G4cout<<"\t----> Degrader mole mass set to       "<<Degrader_log->GetMaterial()->GetA()/g*mole<<" g/mole"<< G4endl;  
	 G4cout<<"\t----> Degrader density set to         "<<Degrader_log->GetMaterial()->GetDensity()/g*cm3<<" g/cm3"<< G4endl;     
	 G4cout<<"\t----> Degrader side X is set to     "<<G4BestUnit(2.*aDegrader->GetXHalfLength(),"Length")<<G4endl;
	 G4cout<<"\t----> Degrader side Y is set to     "<<G4BestUnit(2.*aDegrader->GetYHalfLength(),"Length")<<G4endl;  
	 G4cout<<"\t----> Degrader thickness is set to "<<G4BestUnit(2.*aDegrader->GetZHalfLength(),"Length")<<G4endl;
	 G4cout<<"\t----> Stopper Z position is set to   "<<G4BestUnit(Degrader_phys->GetTranslation().getZ(),"Length")<<G4endl;
	 G4cout<<"\t----> Ratio of target/degrader reactions set to "<<Ratio<<G4endl;
	 
	 
	 if(PlungerType == 2){
		G4cout<<"\033[1m\033[33m------------- Stopper ----------------- \033[0m" << G4endl;
		G4cout<<"\t----> Stopper material set to        "<<Stopper_log->GetMaterial()->GetName()<< G4endl;  
		G4cout<<"\t----> Stopper Z set to               "<<Stopper_log->GetMaterial()->GetZ()<< G4endl;  
		G4cout<<"\t----> Stopper mole mass set to       "<<Stopper_log->GetMaterial()->GetA()/g*mole<<" g/mole"<< G4endl;  
		G4cout<<"\t----> Stopper density set to         "<<Stopper_log->GetMaterial()->GetDensity()/g*cm3<<" g/cm3"<< G4endl;        
		G4cout<<"\t----> Stopper side X is set to       "<<G4BestUnit(2.*aStopper->GetXHalfLength(),"Length")<<G4endl;
		G4cout<<"\t----> Stopper side Y is set to       "<<G4BestUnit(2.*aStopper->GetYHalfLength(),"Length")<<G4endl;  
		G4cout<<"\t----> Stopper thickness is set to   "<<G4BestUnit(2.*aStopper->GetZHalfLength(),"Length")<<G4endl;
		G4cout<<"\t----> Stopper Z position is set to   "<<G4BestUnit(Stopper_phys->GetTranslation().getZ(),"Length")<<G4endl;
		G4cout<<"\t----> Ratio2 of stopper/degrader reactions set to "<<Ratio2<<G4endl;

	 }

	 

	 G4ThreeVector P;
	 P=Degrader_phys->GetTranslation();
	 G4cout<<"\t----> Plunger Z position set to "<<G4BestUnit(P.getZ(),"Length")<<G4endl;
	 G4ThreeVector Sep;
	 G4double d;
	 Sep=Target_phys->GetTranslation();
	 d=-Sep.getZ()+P.getZ()-aTarget->GetZHalfLength()-aDegrader->GetZHalfLength();
	 G4cout<<"\t----> Degrader/Target separation is set to "<<G4BestUnit(d,"Length")<<G4endl;
	 d=Sep.getZ()-aTarget->GetZHalfLength();
	 G4cout<<"\t---->  Target face position at "<<d/mm<<" mm"<<G4endl;
	 d=Sep.getZ()+aTarget->GetZHalfLength();;
	 G4cout<<"\t---->  Target back position at "<<d/mm<<" mm"<<G4endl;
	 d=P.getZ()-aDegrader->GetZHalfLength();
	 G4cout<<"\t----> Degrader back position at "<<d/mm<<" mm"<<G4endl;
	 d=P.getZ()+aDegrader->GetZHalfLength();
	 G4cout<<"\t----> Degrader face position at "<<d/mm<<" mm"<<G4endl;
  }

  if(Shield_Flag){
    G4cout<<"\033[1m\033[33m------------- Shield ----------------- \033[0m" << G4endl;
    G4cout<<"\t----> Shield material set to        "<<Shield_log->GetMaterial()->GetName()<< G4endl;  
    G4cout<<"\t----> Shield Rmin is set to       "<<G4BestUnit(aShieldCy->GetInnerRadius(),"Length")<<G4endl;
    G4cout<<"\t----> Shield Rmax is set to       "<<G4BestUnit(aShieldCy->GetOuterRadius(),"Length")<<G4endl;  
    G4cout<<"\t----> Shield Length is set to   "<<G4BestUnit(2.*aShieldCy->GetZHalfLength(),"Length")<<G4endl;
    G4cout<<"\t----> Shield Z position is set to   "<<G4BestUnit(Shield_phys->GetTranslation().getZ(),"Length")<<G4endl;
  }

  G4cout<<"\033[1m\033[31m---------------- End of Plunger Report ---------------  \033[0m" << G4endl<< G4endl;
  
 


}
//-----------------------------------------------------------------------------
void Plunger::SetNstepTar(G4int n)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  NstepTar=n;
  target_limits->SetMaxAllowedStep(Target_thickness/NstepTar);
  Target_log->SetUserLimits(target_limits);
  G4cout<<"\t----> Number of simulation steps in the target is set to "<<NstepTar<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetNstepDeg(G4int n)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  NstepDeg=n;
  degrader_limits->SetMaxAllowedStep(Degrader_thickness/NstepDeg);
  Degrader_log->SetUserLimits(degrader_limits);
  G4cout<<"\t----> Number of simulation steps in the degrater is set to "<<NstepDeg<<G4endl;
}
//-----------------------------------------------------------------------------
void Plunger::SetNstepSto(G4int n)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  NstepSto=n;
  stopper_limits->SetMaxAllowedStep(Stopper_thickness/NstepSto);
  Stopper_log->SetUserLimits(stopper_limits);
  G4cout<<"\t----> Number of simulation steps in the stopper is set to "<<NstepSto<<G4endl;
}
//AR New in v4.3 -> Possiblility to add a cylindrical Shield (Used in Rob's Cascade Analysis)
//---------------------------------------------------------------------
void Plunger::SetShMaterial(G4String materialName)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  // search the material by its name
  Shield_material = materials->FindMaterial(materialName);  
  Shield_log->SetMaterial(Shield_material);
  G4cout<<"----> Shield material set to     "<<Shield_log->GetMaterial()->GetName()<< G4endl;                 
}
//---------------------------------------------------------------------
void Plunger::SetShPos(G4double X)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Shield_start=X;
  G4ThreeVector Sep;
  Sep.setX(Shield_pos->getX());
  Sep.setY(Shield_pos->getY());
  Sep.setZ(Shield_start+Shield_len/2.);
  Shield_phys->SetTranslation(Sep);
  G4cout<<"----> Shield position is set to "<< X <<G4endl;
}
//---------------------------------------------------------------------
void Plunger::SetShRmin(G4double X)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Shield_rmin=X;
  aShieldCy->SetInnerRadius(Shield_rmin);
  G4cout<<"----> Shield rmin is set to "<< X <<G4endl;
}
//---------------------------------------------------------------------
void Plunger::SetShRmax(G4double X)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Shield_rmax=X;
  aShieldCy->SetOuterRadius(Shield_rmax);
  G4cout<<"----> Shield rmax is set to "<< X <<G4endl;
}
//---------------------------------------------------------------------
void Plunger::SetShLen(G4double X)
{
#ifdef DEBUG
  G4cerr << __PRETTY_FUNCTION__  << G4endl;
#endif 
  Shield_len=X;
  aShieldCy->SetZHalfLength(Shield_len/2.);
  G4cout<<"----> Shield length is set to "<< X <<G4endl;
}
//---------------------------------------------------------------------
