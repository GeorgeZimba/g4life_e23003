#ifndef Materials_H
#define Materials_H 1

#include "G4Material.hh"

class Materials 
{
  public:


  Materials();
  ~Materials();
  
  G4Material* FindMaterial(G4String );
    
    private:
  // Elements
 
  G4Element* elementH;
  G4Element* elementC;
  G4Element* elementN;
  G4Element* elementO;
  G4Element* elementMg;
  G4Element* elementAl;
  G4Element* elementSi;
  G4Element* elementTi;
  G4Element* elementV;
  G4Element* elementFe;
  G4Element* elementMo;
  G4Element* elementPt;
  G4Element* elementAu;
  G4Element* elementPb;
  

/*Ta and Ir added by Phil and Lucia on 1/20/09*/
  G4Element* elementIr;
  G4Element* elementTa;
  G4Element* elementW;



// Materials

  G4Material* vacuum;
  G4Material* Al;
  G4Material* Nb;
  G4Material* C;
  G4Material* Au;
  G4Material* Si;
  G4Material* Be;

  G4Material* Fe;

/*Ta and Ir added by Phil and Lucia on 1/20/09*/
  
  G4Material* Ir;
  G4Material* Ta;
  G4Material* W;

  G4Material* Pb;

};

#endif

