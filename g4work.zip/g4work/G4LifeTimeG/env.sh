#############################################################
####
####   Environment Bash script for G4Lifetime software
####   A. Lemasson - 10 / 04 / 2012
####   lemasson@nscl.msu.edu
####
#############################################################
###
###   Set the variable according to your local configuration
###
#############################################################

#############################################################
#                    ROOT Environment                       #
#############################################################


#export ROOTSYS=/opt/lucid/root/current

source $ROOTSYS/bin/thisroot.sh

#############################################################
#                  GEANT4 Environment                       #
#############################################################

export G4WORKDIR=$HOME/g4work-dev/G4LifeTimeG

export G4BIN=$G4WORKDIR/bin/bin${BITSYSTEM}
if [ ! -d $G4BIN ]; then
    mkdir -p $G4BIN
fi

export G4TMP=$G4WORKDIR/tmp/tmp${BITSYSTEM}
if [ ! -d $G4TMP ]; then
    mkdir -p $G4TMP
fi

export G4LIB=$G4WORKDIR/lib/lib${BITSYSTEM}
if [ ! -d $G4LIB ]; then
    mkdir -p $G4LIB
fi

#export G4INSTALL=/opt/lucid/GEANT4/geant4.9.4.p04

#source $G4INSTALL/env.sh
 
export PATH=${PATH}:${G4BIN}/${G4SYSTEM}

